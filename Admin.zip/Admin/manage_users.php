    <?php
    session_start();
    require 'db.php';
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') { header('Location: ../login.php'); exit; }
    $res = $conn->query('SELECT * FROM users ORDER BY id DESC');
    ?>
    <!doctype html><html lang="en"><head>
    <title>Manage Users</title>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{
  --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
  --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:28px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06);}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none}
@media(max-width:991px){
  .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}
  .sidebar.show{left:0}
  .content{padding:20px;}
  .offcanvas-toggle{display:inline-flex}
}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
</style>
<script>function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('show'); }</script>

    </head><body>
    <header class="topbar"><div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div><div>CARE Admin</div></div><div><button class="offcanvas-toggle d-md-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button><a href="../" class="btn btn-sm">View Site</a> <a href="logout.php" class="btn btn-sm">Logout</a></div></header>
    <div class="layout"><aside id="sidebar" class="sidebar"><nav class="nav"><a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a><a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a><a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a><a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a><a href="manage_users.php" class="active"><i class="fa fa-users"></i> Users</a><a href="view_reports.php"><i class="fa fa-calendar-check"></i> Appointments</a></nav></aside><main class="content">
    <h2>Users</h2><div class="card-soft"><div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead><tbody>
    <?php while($u=$res->fetch_assoc()): ?>
      <tr><td><?= htmlspecialchars($u['id']) ?></td><td><?= htmlspecialchars($u['name']) ?></td><td><?= htmlspecialchars($u['email']) ?></td><td><?= htmlspecialchars($u['role']) ?></td><td><a href="edit_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a> <a href="delete_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete user?')">Delete</a></td></tr>
    <?php endwhile; ?>
    </tbody></table></div></div></main></div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script></body></html>
