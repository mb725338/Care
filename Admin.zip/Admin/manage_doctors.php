<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Add Doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_doctor') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $spec = trim($_POST['specialization'] ?? '');

    if ($name && $email && $password && $spec) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,"doctor")');
        $stmt->bind_param('sss', $name, $email, $hash);
        $stmt->execute();
        $uid = $stmt->insert_id;
        $stmt->close();

        $stmt2 = $conn->prepare('INSERT INTO doctors (user_id,specialization) VALUES (?,?)');
        $stmt2->bind_param('is', $uid, $spec);
        $stmt2->execute();
        $stmt2->close();

        header('Location: manage_doctors.php');
        exit;
    }
}

// Fetch Doctors
$res = $conn->query('SELECT d.*,u.email,u.name as uname FROM doctors d 
    JOIN users u ON u.id=d.user_id ORDER BY d.id DESC');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Manage Doctors</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{
  --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
  --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:28px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none}
@media(max-width:991px){
  .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}
  .sidebar.show{left:0}
  .content{padding:20px;}
  .offcanvas-toggle{display:inline-flex}
}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
</style>
<script>
function toggleSidebar(){ 
  document.getElementById('sidebar').classList.toggle('show'); 
}
function fillEditModal(id, name, email, specialization){
  document.getElementById('edit_id').value = id;
  document.getElementById('edit_name').value = name;
  document.getElementById('edit_email').value = email;
  document.getElementById('edit_specialization').value = specialization;
}
</script>
</head>
<body>
<header class="topbar">
  <div class="brand">
    <div class="logo"><i class="fa fa-heartbeat"></i></div>
    <div>CARE Admin</div>
  </div>
  <div>
    <button class="offcanvas-toggle d-md-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <aside id="sidebar" class="sidebar">
    <nav class="nav">
      <a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
      <a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a>
      <a href="manage_doctors.php" class="active"><i class="fa fa-user-md"></i> Doctors</a>
      <a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a>
      <a href="manage_users.php"><i class="fa fa-users"></i> Users</a>
      <a href="view_reports.php"><i class="fa fa-calendar-check"></i> Appointments</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2>Doctors</h2>
      <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addDoctorModal"><i class="fa fa-plus"></i> Add Doctor</button>
    </div>

    <div class="card-soft">
      <div class="table-responsive">
        <table class="table">
          <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Specialization</th><th>Actions</th></tr></thead>
          <tbody>
          <?php while($d=$res->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($d['id']) ?></td>
              <td><?= htmlspecialchars($d['uname']) ?></td>
              <td><?= htmlspecialchars($d['email']) ?></td>
              <td><?= htmlspecialchars($d['specialization']) ?></td>
              <td>
                <button class="btn btn-sm btn-outline-secondary" 
                  data-bs-toggle="modal" data-bs-target="#editDoctorModal"
                  onclick="fillEditModal('<?= $d['id'] ?>','<?= htmlspecialchars($d['uname']) ?>','<?= htmlspecialchars($d['email']) ?>','<?= htmlspecialchars($d['specialization']) ?>')">
                  Edit
                </button>
                <a href="delete_doctor.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete doctor?')">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<!-- Add Doctor Modal -->
<div class="modal fade" id="addDoctorModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <input type="hidden" name="action" value="add_doctor">
        <div class="modal-header">
          <h5 class="modal-title">Add Doctor</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-2"><input name="name" class="form-control" placeholder="Full name" required></div>
          <div class="mb-2"><input name="email" type="email" class="form-control" placeholder="Email" required></div>
          <div class="mb-2"><input name="password" type="password" class="form-control" placeholder="Password" required></div>
          <div class="mb-2"><input name="specialization" class="form-control" placeholder="Specialization" required></div>
        </div>
        <div class="modal-footer"><button class="btn btn-brand">Create Doctor</button></div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Doctor Modal -->
<div class="modal fade" id="editDoctorModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="edit_doctor.php">
        <div class="modal-header">
          <h5 class="modal-title">Edit Doctor</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="edit_id">
          <div class="mb-2"><input name="name" id="edit_name" class="form-control" required></div>
          <div class="mb-2"><input name="email" id="edit_email" type="email" class="form-control" required></div>
          <div class="mb-2"><input name="specialization" id="edit_specialization" class="form-control" required></div>
        </div>
        <div class="modal-footer"><button class="btn btn-brand">Save Changes</button></div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
