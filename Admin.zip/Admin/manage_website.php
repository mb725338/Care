<?php
session_start();
require "../db.php";

// Role check
if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? "") !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Fetch existing settings
$settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clinic_name = trim($_POST['clinic_name']);
    $clinic_email = trim($_POST['clinic_email']);
    $clinic_phone = trim($_POST['clinic_phone']);

    if ($settings) {
        // Update existing settings
        $stmt = $conn->prepare("UPDATE settings SET clinic_name=?, clinic_email=?, clinic_phone=? WHERE id=?");
        $stmt->bind_param("sssi", $clinic_name, $clinic_email, $clinic_phone, $settings['id']);
    } else {
        // Insert new settings
        $stmt = $conn->prepare("INSERT INTO settings (clinic_name, clinic_email, clinic_phone) VALUES (?,?,?)");
        $stmt->bind_param("sss", $clinic_name, $clinic_email, $clinic_phone);
    }

    $ok = $stmt->execute();
    $stmt->close();

    $_SESSION['msg'] = $ok ? "Website information updated successfully!" : "Error updating information.";
    header("Location: manage_website.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Website</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { display:flex; font-family:Arial,sans-serif; margin:0; background:#f4f6f9;}
.sidebar{width:250px; background:linear-gradient(180deg,#2E8B57,#1E90FF); color:#fff; height:100vh; padding:20px; position:fixed;}
.sidebar h2{text-align:center;margin-bottom:30px;}
.sidebar a{display:block;padding:12px;margin:8px 0;color:#fff;text-decoration:none;border-radius:6px;}
.sidebar a:hover{background:rgba(255,255,255,0.2);}
.content{margin-left:270px;padding:30px;flex-grow:1;}
.alert{padding:12px;border-radius:6px;margin-bottom:20px;font-size:14px;}
.success{background:#d4edda;color:#155724;}
.error{background:#f8d7da;color:#721c24;}
input[type="text"], input[type="email"], input[type="tel"], textarea{width:90%;padding:8px;border:1px solid #ccc;border-radius:4px;margin-bottom:12px;}
.btn-save{background:#28a745;color:#fff;padding:8px 16px;border:none;border-radius:4px;cursor:pointer;}
.btn-save:hover{opacity:0.9;}
h1{margin-bottom:20px;}
</style>
</head>
<body>

<div class="sidebar">
<h2>Admin Panel</h2>
<a href="admin_dashboard.php">Dashboard</a>
<a href="manage_cities.php">Manage Cities</a>
<a href="manage_doctors.php">Manage Doctors</a>
<a href="manage_patients.php">Manage Patients</a>
<a href="manage_users.php">Manage Users</a>
<a href="manage_website.php" class="active">Website Info</a>
<a href="../logout.php">Logout</a>
</div>

<div class="content">
<h1>Website Information</h1>

<?php if(isset($_SESSION['msg'])): ?>
<div class="alert <?= strpos($_SESSION['msg'],'successfully')!==false?'success':'error' ?>">
<?= $_SESSION['msg']; unset($_SESSION['msg']); ?>
</div>
<?php endif; ?>

<form method="POST">
<label>Clinic Name:</label><br>
<input type="text" name="clinic_name" value="<?= htmlspecialchars($settings['clinic_name'] ?? '') ?>" required><br>

<label>Clinic Email:</label><br>
<input type="email" name="clinic_email" value="<?= htmlspecialchars($settings['clinic_email'] ?? '') ?>" required><br>

<label>Clinic Phone:</label><br>
<input type="tel" name="clinic_phone" value="<?= htmlspecialchars($settings['clinic_phone'] ?? '') ?>" required><br>

<button type="submit" class="btn-save">Save Changes</button>
</form>
</div>

</body>
</html>
