<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') { 
    header('Location: ../login.php'); 
    exit; 
}

$user_id = $_SESSION['user_id'];
$userRes = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id LIMIT 1");
if ($userRes && $userRes->num_rows > 0) {
    $udata = $userRes->fetch_assoc();
    $pname = $udata['name'];
    $pic = !empty($udata['profile_pic']) ? $udata['profile_pic'] : '../assets/img/default-avatar.png';
} else {
    $pname = "Admin";
    $pic = "../assets/img/default-avatar.png";
}

// counts
$cities = $conn->query("SELECT COUNT(*) AS cnt FROM cities")->fetch_assoc()['cnt'] ?? 0;
$doctors = $conn->query("SELECT COUNT(*) AS cnt FROM doctors")->fetch_assoc()['cnt'] ?? 0;
$patients = $conn->query("SELECT COUNT(*) AS cnt FROM patients")->fetch_assoc()['cnt'] ?? 0;
$users = $conn->query("SELECT COUNT(*) AS cnt FROM users")->fetch_assoc()['cnt'] ?? 0;
$appointments = $conn->query("SELECT COUNT(*) AS cnt FROM appointments")->fetch_assoc()['cnt'] ?? 0;
?>

<!doctype html><html lang="en"><head><title>Admin Dashboard</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
*{box-sizing:border-box}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:24px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px}
.stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06)}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none}
.profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08)}
@media(max-width:991px){.sidebar{position:fixed;left:-320px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000;width:280px}.sidebar.show{left:0}.content{padding:16px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
.offcanvas-toggle {
  display: none;
  border-radius: 8px;
  border: none;
  padding: 8px 12px;
  background: var(--surface);
  box-shadow: var(--shadow);
}

/* Show toggle button only on mobile */
@media (max-width: 991px) {
  .offcanvas-toggle {
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
  }
}
.overlay {
  display: none;
  position: fixed;
  top: 64px; /* same as topbar */
  left: 0;
  width: 100%;
  height: calc(100% - 64px);
  background: rgba(0,0,0,0.4);
  z-index: 1500;
}

.sidebar.show ~ .overlay {
  display: block;
}

</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>
</head><body>
<header class="topbar">
  <div class="brand">
    <div class="logo"><i class="fa fa-heartbeat"></i></div>
    <div>CARE Admin</div>
  </div>
  <div class="d-flex align-items-center gap-2">
    <!-- Mobile toggle (always visible on small screens) -->
    <button class="offcanvas-toggle d-md-none" onclick="toggleSidebar()">
      <i class="fa fa-bars"></i>
    </button>

    <!-- Links (desktop only) -->
    <a href="../index.php" class="btn btn-sm btn-outline-secondary d-none d-md-inline">View Site</a>
    <a href="logout.php" class="btn btn-sm btn-outline-secondary d-none d-md-inline">Logout</a>

    <!-- Profile dropdown -->
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-decoration-none" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="<?= htmlspecialchars($pic) ?>" alt="profile" class="profile-pic me-2">
        <span class="d-none d-md-inline"><?= htmlspecialchars($pname) ?></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
        <li><a class="dropdown-item" href="profile.php"><i class="fa fa-user me-2"></i> Profile</a></li>
        <li><a class="dropdown-item" href="manage_website_info.php"><i class="fa fa-globe me-2"></i> Website Info</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa fa-sign-out-alt me-2"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</header>

<div class="layout">
  <aside id="sidebar" class="sidebar"><nav class="nav"><a href="admin_dashboard.php" class="active"><i class="fa fa-tachometer-alt"></i> Dashboard</a><a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a><a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a><a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a><a href="manage_users.php"><i class="fa fa-users"></i> Users</a><a href="view_reports.php"><i class="fa fa-calendar-check"></i> Reports</a><a href="manage_website_info.php"><i class="fa fa-globe"></i> Website Info</a><a href="profile.php"><i class="fa fa-id-card"></i> Profile</a><a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></nav></aside><div id="overlay" class="overlay" onclick="toggleSidebar()"></div>

<main class="content">
<div class="d-flex justify-content-between align-items-center mb-3"><h2>Dashboard</h2><div class="d-flex gap-2"><button class="btn btn-sm btn-outline-secondary d-none d-md-inline" onclick="toggleSidebar()"><i class="fa fa-bars me-1"></i> Menu</button></div></div>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Cities</small><div class="h3 mt-2"><?php echo $cities; ?></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Doctors</small><div class="h3 mt-2"><?php echo $doctors; ?></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Patients</small><div class="h3 mt-2"><?php echo $patients; ?></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Users</small><div class="h3 mt-2"><?php echo $users; ?></div></div></div>
</div>
<div class="card-soft mb-4"><h5 class="mb-2">Website Info</h5><?php $info = $conn->query('SELECT * FROM settings WHERE id=1')->fetch_assoc() ?? []; ?><div class="row"><div class="col-md-8"><p><strong>Site title:</strong> <?php echo htmlspecialchars($info['site_title'] ?? 'CARE - Your Health'); ?></p><p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($info['site_description'] ?? '')); ?></p></div><div class="col-md-4 text-md-end"><button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#editSiteModal"><i class="fa fa-edit me-1"></i> Edit Website Info</button></div></div></div>
<div class="card-soft"><h5 class="mb-3">Recent Appointments</h5><div class="table-responsive"><table class="table table-striped"><thead><tr><th>#</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php $res = $conn->query("SELECT a.id,a.appointment_date,a.status,u1.name as patient_name,u2.name as doctor_name FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id JOIN users u1 ON u1.id=p.user_id JOIN users u2 ON u2.id=d.user_id ORDER BY a.appointment_date DESC LIMIT 8"); if ($res) { while($r=$res->fetch_assoc()){ echo '<tr><td>'.htmlspecialchars($r['id']).'</td><td>'.htmlspecialchars($r['patient_name']).'</td><td>'.htmlspecialchars($r['doctor_name']).'</td><td>'.htmlspecialchars($r['appointment_date']).'</td><td>'.htmlspecialchars($r['status']).'</td></tr>'; } } ?>
</tbody></table></div></div>
</main></div>

<!-- Edit site modal -->
<div class="modal fade" id="editSiteModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" action="manage_website_info.php"><input type="hidden" name="action" value="save_settings"><div class="modal-header"><h5 class="modal-title">Edit Website Info</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><?php $s = $info; ?><div class="mb-2"><label>Site title</label><input name="site_title" class="form-control" value="<?php echo htmlspecialchars($s['site_title'] ?? ''); ?>"></div><div class="mb-2"><label>Site description</label><textarea name="site_description" class="form-control"><?php echo htmlspecialchars($s['site_description'] ?? ''); ?></textarea></div><div class="mb-2"><label>Clinic name</label><input name="clinic_name" class="form-control" value="<?php echo htmlspecialchars($s['clinic_name'] ?? ''); ?>"></div><div class="mb-2"><label>Clinic email</label><input name="clinic_email" class="form-control" value="<?php echo htmlspecialchars($s['clinic_email'] ?? ''); ?>"></div><div class="mb-2"><label>Clinic phone</label><input name="clinic_phone" class="form-control" value="<?php echo htmlspecialchars($s['clinic_phone'] ?? ''); ?>"></div></div><div class="modal-footer"><button class="btn btn-brand">Save</button></div></form></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
  document.getElementById('overlay').classList.toggle('d-block');
}

</script>
</body></html>