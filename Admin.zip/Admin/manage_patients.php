<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php'); 
    exit;
}

// Fetch patients
$res = $conn->query('SELECT p.*, u.email, u.name as uname FROM patients p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC');
if(!$res){
    die("Query failed: " . $conn->error);
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Manage Patients</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root{
            --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
            --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
        }
        body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
        .topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
        .brand{display:flex;align-items:center;gap:10px;font-weight:700}
        .brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
        .layout{display:flex;min-height:calc(100vh - 64px);}
        .sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
        .sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
        .sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
        .content{flex:1;padding:28px;}
        .card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
        .btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
        .stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06);}
        .table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none}
        @media(max-width:991px){
            .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}
            .sidebar.show{left:0}
            .content{padding:20px;}
            .offcanvas-toggle{display:inline-flex}
        }
        .offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
    </style>
    <script>
        function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('show'); }
        function fillEditModal(id, name, email, phone, city_id) {
            document.getElementById('editPatientId').value = id;
            document.getElementById('editPatientName').value = name;
            document.getElementById('editPatientEmail').value = email;
            document.getElementById('editPatientPhone').value = phone;
            document.getElementById('editPatientCity').value = city_id;
        }
    </script>
</head>
<body>
<header class="topbar">
    <div class="brand">
        <div class="logo"><i class="fa fa-heartbeat"></i></div>
        <div>CARE Admin</div>
    </div>
    <div>
        <button class="offcanvas-toggle d-md-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
        <a href="../" class="btn btn-sm">View Site</a>
        <a href="logout.php" class="btn btn-sm">Logout</a>
    </div>
</header>
<div class="layout">
    <aside id="sidebar" class="sidebar">
        <nav class="nav">
            <a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
            <a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a>
            <a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a>
            <a href="manage_patients.php" class="active"><i class="fa fa-user"></i> Patients</a>
            <a href="manage_users.php"><i class="fa fa-users"></i> Users</a>
            <a href="view_reports.php"><i class="fa fa-calendar-check"></i> Appointments</a>
        </nav>
    </aside>
    <main class="content">
        <h2>Patients</h2>
        <div class="card-soft">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($p = $res->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['id']) ?></td>
                            <td><?= htmlspecialchars($p['uname']) ?></td>
                            <td><?= htmlspecialchars($p['email']) ?></td>
                            <td><?= htmlspecialchars($p['phone']) ?></td>
                            <td><?= htmlspecialchars($p['city_id']) ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-secondary" 
                                    data-bs-toggle="modal" data-bs-target="#editModal"
                                    onclick="fillEditModal('<?= $p['id'] ?>','<?= htmlspecialchars($p['uname'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['email'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['phone'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['city_id'], ENT_QUOTES) ?>')">
                                    Edit
                                </button>
                                <a href="delete_patient.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php if(isset($_SESSION['message'])): ?>
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1100">
  <div id="liveToast" class="toast align-items-center text-bg-success border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        <?= $_SESSION['message'] ?>
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  </div>
</div>
<?php unset($_SESSION['message']); endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
    var toastEl = document.getElementById('liveToast');
    if(toastEl){
        var toast = new bootstrap.Toast(toastEl, { delay: 3000 });
        toast.show();
    }
});
</script>

<!-- Edit Patient Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form action="update_patient.php" method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Patient</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="editPatientId">
          <div class="mb-3">
              <label>Name</label>
              <input type="text" name="name" id="editPatientName" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Email</label>
              <input type="email" name="email" id="editPatientEmail" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Phone</label>
              <input type="text" name="phone" id="editPatientPhone" class="form-control">
          </div>
          <div class="mb-3">
              <label>City ID</label>
              <input type="text" name="city_id" id="editPatientCity" class="form-control">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="update_patient" class="btn btn-primary">Save changes</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
