<?php session_start(); require 'db.php'; if (!isset($_SESSION['user_id'])){header('Location: ../login.php');exit;} $uid=intval($_SESSION['user_id']); if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='save_profile'){ $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $password=$_POST['password']??''; if (!empty($_FILES['profile_pic']['name'])){ $uploaddir=__DIR__.'/assets/uploads/'; if(!is_dir($uploaddir)) mkdir($uploaddir,0755,true); $ext=pathinfo($_FILES['profile_pic']['name'],PATHINFO_EXTENSION); $fn='user_'.$uid.'_'.time().'.'. $ext; $target=$uploaddir.$fn; if(move_uploaded_file($_FILES['profile_pic']['tmp_name'],$target)){ $picpath='assets/uploads/'.$fn; $stmt=$conn->prepare('UPDATE users SET profile_pic=? WHERE id=?'); $stmt->bind_param('si',$picpath,$uid); $stmt->execute(); $stmt->close(); } } if($password){ $hash=password_hash($password,PASSWORD_DEFAULT); $stmt=$conn->prepare('UPDATE users SET name=?,email=?,password=? WHERE id=?'); $stmt->bind_param('sssi',$name,$email,$hash,$uid); } else { $stmt=$conn->prepare('UPDATE users SET name=?,email=? WHERE id=?'); $stmt->bind_param('ssi',$name,$email,$uid); } $stmt->execute(); $stmt->close(); header('Location: profile.php'); exit; } $u=$conn->query('SELECT * FROM users WHERE id='.$uid)->fetch_assoc() ?? []; ?>
<!doctype html><html lang="en"><head><title>Profile</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
*{box-sizing:border-box}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:24px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px}
.stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06)}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none}
.profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08)}
@media(max-width:991px){.sidebar{position:fixed;left:-320px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000;width:280px}.sidebar.show{left:0}.content{padding:16px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>

</head><body>
<header class="topbar">
  <div class="brand">
    <div class="logo"><i class="fa fa-heartbeat"></i></div>
    <div>CARE Admin</div>
  </div>
  <div class="d-flex align-items-center gap-2">
    <button class="offcanvas-toggle d-md-none btn btn-light" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm btn-outline-secondary d-none d-md-inline">View Site</a>
    <a href="logout.php" class="btn btn-sm btn-outline-secondary d-none d-md-inline">Logout</a>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-decoration-none" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        <?php
          $pic = 'assets/default-avatar.svg';
          $pname = 'Admin';
          $uid = $_SESSION['user_id'] ?? 0;
          if ($uid) {
            $r = $conn->query("SELECT profile_pic,name FROM users WHERE id=".intval($uid));
            if ($r && $row = $r->fetch_assoc()) {
              if (!empty($row['profile_pic']) && file_exists(__DIR__.'/'. $row['profile_pic'])) $pic = $row['profile_pic'];
              $pname = $row['name'] ?? 'Admin';
            }
          }
        ?>
        <img src="<?= htmlspecialchars($pic) ?>" alt="profile" class="profile-pic me-2">
        <span class="d-none d-md-inline"><?= htmlspecialchars($pname) ?></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
        <li><a class="dropdown-item" href="profile.php"><i class="fa fa-user me-2"></i> Profile</a></li>
        <li><a class="dropdown-item" href="manage_website_info.php"><i class="fa fa-globe me-2"></i> Website Info</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa fa-sign-out-alt me-2"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</header>

<div class="layout"><aside id="sidebar" class="sidebar"><nav class="nav"><a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a><a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a><a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a><a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a><a href="manage_users.php"><i class="fa fa-users"></i> Users</a><a href="view_reports.php"><i class="fa fa-calendar-check"></i> Reports</a><a href="manage_website_info.php"><i class="fa fa-globe"></i> Website Info</a><a href="profile.php" class="active"><i class="fa fa-id-card"></i> Profile</a></nav></aside><main class="content">
<h2>Profile</h2>
<div class="card-soft mb-3"><div class="row align-items-center"><div class="col-md-3 text-center"><?php $pic=$u['profile_pic']??'assets/default-avatar.svg'; if(!file_exists(__DIR__.'/'.$pic)) $pic='assets/default-avatar.svg'; ?><img src="<?= htmlspecialchars($pic) ?>" class="img-fluid rounded-circle mb-2" style="width:120px;height:120px;object-fit:cover;border:6px solid #fff;box-shadow:0 8px 20px rgba(2,8,23,0.06)"><div><?=htmlspecialchars($u['name']??'')?></div><div class="text-muted small"><?=htmlspecialchars($u['email']??'')?></div></div><div class="col-md-9"><p><strong>Role:</strong> <?=htmlspecialchars($u['role']??'')?></p><button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#editProfileModal"><i class="fa fa-edit me-1"></i> Edit Profile</button></div></div></div>
<div class="modal fade" id="editProfileModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post" enctype="multipart/form-data"><input type="hidden" name="action" value="save_profile"><div class="modal-header"><h5 class="modal-title">Edit Profile</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="mb-2"><label>Name</label><input class="form-control" name="name" value="<?= htmlspecialchars($u['name']??'') ?>" required></div><div class="mb-2"><label>Email</label><input class="form-control" name="email" value="<?= htmlspecialchars($u['email']??'') ?>" type="email" required></div><div class="mb-2"><label>New Password (leave blank to keep)</label><input class="form-control" name="password" type="password"></div><div class="mb-2"><label>Profile picture (optional)</label><input class="form-control" type="file" name="profile_pic" accept="image/*"></div></div><div class="modal-footer"><button class="btn btn-brand">Save</button></div></form></div></div></div>
</main></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
