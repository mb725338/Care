<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') { 
    header('Location: ../login.php'); 
    exit; 
}

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='add'){ 
    $name=trim($_POST['name'] ?? ''); 
    if($name!==''){ 
        $stmt=$conn->prepare('INSERT INTO cities (name) VALUES (?)'); 
        $stmt->bind_param('s',$name); 
        $stmt->execute(); 
        $stmt->close(); 
        header('Location: manage_cities.php'); 
        exit; 
    } 
}

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='edit'){ 
    $id=intval($_POST['id']); 
    $name=trim($_POST['name'] ?? ''); 
    if($name!==''){ 
        $stmt=$conn->prepare('UPDATE cities SET name=? WHERE id=?'); 
        $stmt->bind_param('si',$name,$id); 
        $stmt->execute(); 
        $stmt->close(); 
        header('Location: manage_cities.php'); 
        exit; 
    } 
}

if (isset($_GET['delete'])){ 
    $id=intval($_GET['delete']); 
    $stmt=$conn->prepare('DELETE FROM cities WHERE id=?'); 
    $stmt->bind_param('i',$id); 
    $stmt->execute(); 
    $stmt->close(); 
    header('Location: manage_cities.php'); 
    exit; 
}

$cities = $conn->query('SELECT * FROM cities ORDER BY name ASC');
?>
<!doctype html>
<html lang="en">
<head>
<title>Manage Cities</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{
  --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
  --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:28px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none}

/* Responsive Sidebar */
@media(max-width:991px){
  .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .3s ease;z-index:2000}
  .sidebar.show{left:0}
  .content{padding:20px;}
  .offcanvas-toggle{display:inline-flex !important;}
}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
</style>
</head>
<body>
<header class="topbar">
  <div class="brand">
    <div class="logo"><i class="fa fa-heartbeat"></i></div>
    <div>CARE Admin</div>
  </div>
  <div>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm">View Site</a> 
    <a href="logout.php" class="btn btn-sm">Logout</a>
  </div>
</header>

<div class="layout">
  <aside id="sidebar" class="sidebar">
    <nav class="nav">
      <a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
      <a href="manage_cities.php" class="active"><i class="fa fa-city"></i> Cities</a>
      <a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a>
      <a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a>
      <a href="manage_users.php"><i class="fa fa-users"></i> Users</a>
      <a href="view_reports.php"><i class="fa fa-calendar-check"></i> Appointments</a>
    </nav>
  </aside>
  <main class="content">
    <h2>Manage Cities</h2>
    <div class="card-soft mb-3">
      <form method="post" class="row g-2 align-items-center">
        <input type="hidden" name="action" value="add">
        <div class="col-md-8"><input type="text" name="name" class="form-control" placeholder="City name" required></div>
        <div class="col-md-4"><button class="btn btn-brand w-100">Add City</button></div>
      </form>
    </div>

    <div class="card-soft">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>ID</th><th>Name</th><th>Actions</th></tr></thead>
          <tbody>
          <?php while($c=$cities->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($c['id']) ?></td>
            <td><?= htmlspecialchars($c['name']) ?></td>
            <td>
              <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editModal<?= $c['id'] ?>"><i class="fa fa-edit"></i></button>
              <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete city?')"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
          <div class="modal fade" id="editModal<?= $c['id'] ?>" tabindex="-1">
            <div class="modal-dialog">
              <div class="modal-content">
                <form method="post">
                  <input type="hidden" name="action" value="edit">
                  <input type="hidden" name="id" value="<?= $c['id'] ?>">
                  <div class="modal-header">
                    <h5 class="modal-title">Edit City</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($c['name']) ?>" required>
                  </div>
                  <div class="modal-footer"><button class="btn btn-brand">Save changes</button></div>
                </form>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<script>
function toggleSidebar(){
  document.getElementById('sidebar').classList.toggle('show');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
