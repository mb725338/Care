<?php session_start(); require 'db.php'; if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='admin'){header('Location: ../login.php');exit;} if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action']==='update_status'){ $id=intval($_POST['id']); $status=$_POST['status']??'pending'; $stmt=$conn->prepare('UPDATE appointments SET status=? WHERE id=?'); $stmt->bind_param('si',$status,$id); $stmt->execute(); $stmt->close(); header('Location: view_reports.php'); exit; } $res=$conn->query("SELECT a.*, u1.name as patient_name, u2.name as doctor_name FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id JOIN users u1 ON u1.id=p.user_id JOIN users u2 ON u2.id=d.user_id ORDER BY a.appointment_date DESC"); ?>
<!doctype html><html lang="en"><head><title>Reports</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
*{box-sizing:border-box}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:24px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px}
.stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06)}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none}
.profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08)}
@media(max-width:991px){.sidebar{position:fixed;left:-320px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000;width:280px}.sidebar.show{left:0}.content{padding:16px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>

</head><body>
<header class="topbar">
  <div class="brand">
    <div class="logo"><i class="fa fa-heartbeat"></i></div>
    <div>CARE Admin</div>
  </div>
  <div class="d-flex align-items-center gap-2">
    <button class="offcanvas-toggle d-md-none btn btn-light" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm btn-outline-secondary d-none d-md-inline">View Site</a>
    <a href="logout.php" class="btn btn-sm btn-outline-secondary d-none d-md-inline">Logout</a>
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-decoration-none" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        <?php
          $pic = 'assets/default-avatar.svg';
          $pname = 'Admin';
          $uid = $_SESSION['user_id'] ?? 0;
          if ($uid) {
            $r = $conn->query("SELECT profile_pic,name FROM users WHERE id=".intval($uid));
            if ($r && $row = $r->fetch_assoc()) {
              if (!empty($row['profile_pic']) && file_exists(__DIR__.'/'. $row['profile_pic'])) $pic = $row['profile_pic'];
              $pname = $row['name'] ?? 'Admin';
            }
          }
        ?>
        <img src="<?= htmlspecialchars($pic) ?>" alt="profile" class="profile-pic me-2">
        <span class="d-none d-md-inline"><?= htmlspecialchars($pname) ?></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
        <li><a class="dropdown-item" href="profile.php"><i class="fa fa-user me-2"></i> Profile</a></li>
        <li><a class="dropdown-item" href="manage_website_info.php"><i class="fa fa-globe me-2"></i> Website Info</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa fa-sign-out-alt me-2"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</header>

<div class="layout"><aside id="sidebar" class="sidebar"><nav class="nav"><a href="admin_dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a><a href="manage_cities.php"><i class="fa fa-city"></i> Cities</a><a href="manage_doctors.php"><i class="fa fa-user-md"></i> Doctors</a><a href="manage_patients.php"><i class="fa fa-user"></i> Patients</a><a href="manage_users.php"><i class="fa fa-users"></i> Users</a><a href="view_reports.php" class="active"><i class="fa fa-calendar-check"></i> Reports</a><a href="manage_website_info.php"><i class="fa fa-globe"></i> Website Info</a></nav></aside><main class="content">
<h2>Appointments / Reports</h2>
<div class="card-soft"><div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php while($r=$res->fetch_assoc()): ?>
  <tr><td><?=htmlspecialchars($r['id'])?></td><td><?=htmlspecialchars($r['patient_name'])?></td><td><?=htmlspecialchars($r['doctor_name'])?></td><td><?=htmlspecialchars($r['appointment_date'])?></td><td><?=htmlspecialchars($r['status'])?></td>
  <td><button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#statusModal<?= $r['id'] ?>">Update</button></td></tr>
  <div class="modal fade" id="statusModal<?= $r['id'] ?>" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <form method="post"><input type="hidden" name="action" value="update_status"><input type="hidden" name="id" value="<?= $r['id'] ?>">
    <div class="modal-header"><h5 class="modal-title">Update Status - #<?= $r['id'] ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <select name="status" class="form-select">
        <option value="pending" <?= $r['status']=='pending' ? 'selected' : '' ?>>Pending</option>
        <option value="confirmed" <?= $r['status']=='confirmed' ? 'selected' : '' ?>>Confirmed</option>
        <option value="completed" <?= $r['status']=='completed' ? 'selected' : '' ?>>Completed</option>
        <option value="cancelled" <?= $r['status']=='cancelled' ? 'selected' : '' ?>>Cancelled</option>
      </select>
    </div>
    <div class="modal-footer"><button class="btn btn-brand">Save</button></div></form>
  </div></div></div>
<?php endwhile; ?>
</tbody></table></div></div></main></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
