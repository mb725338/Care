<?php
session_start();
// Adjust path to db.php (project root)
require __DIR__ . '/../db.php';

// Auth check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header('Location: ../login.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

$upload_err = '';
$upload_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_pic') {
    if (!isset($_FILES['profile_pic'])) {
        $upload_err = 'No file uploaded.';
    } else {
        $file = $_FILES['profile_pic'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $upload_err = 'Upload error (code: ' . $file['error'] . ').';
        } else if ($file['size'] > 2 * 1024 * 1024) {
            $upload_err = 'File too large. Max 2MB.';
        } else {
            if (!@getimagesize($file['tmp_name'])) {
                $upload_err = 'Uploaded file is not a valid image.';
            } else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
                $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
                if (!array_key_exists($mime, $allowed)) {
                    $upload_err = 'Only JPG, PNG or WEBP images are allowed.';
                } else {
                    $ext = $allowed[$mime];
                    $upload_dir = __DIR__ . '/../assets/uploads/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    $filename = 'user_' . $user_id . '_' . uniqid() . '.' . $ext;
                    $dest = $upload_dir . $filename;
                    if (!move_uploaded_file($file['tmp_name'], $dest)) {
                        $upload_err = 'Could not move uploaded file.';
                    } else {
                        // Store path relative to patient/ folder
                        $db_path = '../assets/uploads/' . $filename;
                        $upd = $conn->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
                        if (!$upd) {
                            $upload_err = 'DB prepare error: ' . $conn->error;
                            @unlink($dest);
                        } else {
                            $upd->bind_param('si', $db_path, $user_id);
                            if ($upd->execute()) {
                                $upload_success = 'Profile picture updated successfully.';
                            } else {
                                $upload_err = 'DB update failed: ' . $upd->error;
                                @unlink($dest);
                            }
                            $upd->close();
                        }
                    }
                }
            }
        }
    }
}

// Fetch patient + user info
$sql = "SELECT u.id AS uid, u.name, u.email, u.profile_pic, p.id AS patient_id, p.age, p.dob, p.gender, p.phone, p.address
        FROM users u JOIN patients p ON p.user_id = u.id WHERE u.id = ? LIMIT 1";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error (prepare fetch): ' . $conn->error);
}
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();
$patient = $res->fetch_assoc() ?: [];
$stmt->close();

if (!empty($upload_success) && isset($db_path)) {
    $patient['profile_pic'] = $db_path;
}

// unread messages count
$msgCount = 0;
$q = $conn->prepare("SELECT COUNT(*) AS c FROM messages WHERE receiver_id = ? AND status = 'unread'");
if ($q) {
    $q->bind_param('i', $user_id);
    $q->execute();
    $r = $q->get_result()->fetch_assoc();
    $msgCount = (int)($r['c'] ?? 0);
    $q->close();
}

// compute display path for profile image (fallback if missing)
if (!empty($patient['profile_pic'])) {
    $profilePic = htmlspecialchars($patient['profile_pic']);
} else {
    $profilePic = '../assets/default-avatar.png';
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Patient Dashboard — CARE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .sidebar { min-height: 100vh; padding: 1.25rem; background: linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03)); }
    .sidebar a { color: var(--ink); display:block; padding:0.5rem 0.25rem; border-radius:8px; }
    .sidebar a:hover { background: rgba(16,185,129,0.06); color: var(--brand-dark); text-decoration:none; }
    .avatar-sm { width:44px; height:44px; border-radius:50%; object-fit:cover; border:2px solid #fff; box-shadow:var(--shadow); }
    .profile-pic-lg { width:120px; height:120px; border-radius:50%; object-fit:cover; border:6px solid var(--brand); }
    .card-quiet { border-radius:var(--radius-lg); padding:1.25rem; background:var(--surface); box-shadow:var(--shadow); }
    footer.site-footer { background:#f8f9fa; padding:1.25rem; margin-top:2rem; border-top:1px solid rgba(2,8,23,0.08); }
    footer.site-footer a { text-decoration:none; color:#6c757d; margin:0 0.5rem; }
    footer.site-footer a:hover { color:var(--brand-dark); }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
        <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i>
        <span style="color:var(--ink);font-weight:800;">CARE</span>
      </a>
      <div class="d-flex align-items-center ms-auto gap-3">
        <a href="messages.php" class="position-relative me-2">
          <i class="bi bi-chat-dots" style="font-size:1.25rem;"></i>
          <?php if ($msgCount > 0): ?>
            <span class="badge rounded-pill bg-danger position-absolute" style="transform:translate(6px,-10px);"><?php echo $msgCount; ?></span>
          <?php endif; ?>
        </a>
        <div class="dropdown">
          <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <img src="<?php echo $profilePic; ?>" alt="avatar" class="avatar-sm me-2">
            <strong class="d-none d-md-inline"><?php echo htmlspecialchars($patient['name'] ?? 'Patient'); ?></strong>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#uploadModal"><i class="bi bi-image me-2"></i>Change avatar</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
  <div class="container-fluid">
    <div class="row g-0">
      <aside class="col-12 col-md-4 col-lg-3 sidebar">
        <div class="text-center mb-4">
          <img src="<?php echo $profilePic; ?>" alt="profile" class="profile-pic-lg mb-3">
          <h4><?php echo htmlspecialchars($patient['name'] ?? 'Patient'); ?></h4>
          <div class="text-muted"><?php echo htmlspecialchars($patient['email'] ?? ''); ?></div>
          <div class="mt-2">
            <a href="profile.php" class="btn btn-outline-primary btn-sm me-1">Edit Profile</a>
            <a href="#" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">Change Photo</a>
          </div>
        </div>
        <nav>
          <a href="patient_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
          <a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
          <a href="records.php" class="mb-2 d-block"><i class="bi bi-folder2-open me-2"></i>Medical Records</a>
          <a href="disease.php" class="mb-2 d-block"><i class="bi bi-heart-pulse me-2"></i>Disease Info</a>
          <a href="news.php" class="mb-2 d-block"><i class="bi bi-newspaper me-2"></i>News Articles</a>
          <a href="find_doctor.php" class="mb-2 d-block"><i class="bi bi-person-badge me-2"></i>Find Doctor</a>
          <a href="messages.php" class="mb-2 d-block"><i class="bi bi-chat-left-text me-2"></i>
            Messages <?php if($msgCount>0) echo "<span class='badge bg-danger ms-2'>$msgCount</span>"; ?></a>
          <a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
        </nav>
      </aside>
      <main class="col-12 col-md-8 col-lg-9 p-4">
        <?php if ($upload_err): ?>
          <div class="alert alert-danger"><?php echo htmlspecialchars($upload_err); ?></div>
        <?php elseif ($upload_success): ?>
          <div class="alert alert-success"><?php echo htmlspecialchars($upload_success); ?></div>
        <?php endif; ?>

        <h2 class="mb-2">Welcome back, <?php echo htmlspecialchars($patient['name'] ?? 'Patient'); ?> 👋</h2>
        <p class="sub mb-4">Manage appointments, records and stay updated.</p>

        <div class="row g-4">
          <div class="col-md-6 col-lg-4">
            <div class="card-quiet">
              <div class="d-flex align-items-center">
                <i class="bi bi-calendar-check display-6 me-3" style="color:var(--brand)"></i>
                <div>
                  <h6 class="mb-0">Appointments</h6>
                  <small class="text-muted">View or cancel upcoming appointments</small>
                </div>
              </div>
              <div class="mt-3">
                <a href="appointments.php" class="btn btn-primary btn-sm">Manage</a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card-quiet">
              <div class="d-flex align-items-center">
                <i class="bi bi-folder2-open display-6 me-3" style="color:var(--brand-2)"></i>
                <div>
                  <h6 class="mb-0">Medical Records</h6>
                  <small class="text-muted">Prescriptions & visit history</small>
                </div>
              </div>
              <div class="mt-3">
                <a href="records.php" class="btn btn-primary btn-sm">Open</a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card-quiet">
              <div class="d-flex align-items-center">
                <i class="bi bi-newspaper display-6 me-3" style="color:var(--brand-dark)"></i>
                <div>
                  <h6 class="mb-0">News Articles</h6>
                  <small class="text-muted">Latest health news</small>
                </div>
              </div>
              <div class="mt-3">
                <a href="news.php" class="btn btn-primary btn-sm">Read</a>
              </div>
            </div>
          </div>
        </div>

        <footer class="site-footer mt-4">
          <div class="container d-flex justify-content-between align-items-center">
            <div>&copy; <?php echo date('Y'); ?> CARE</div>
            <div>
              <a href="profile.php">Profile</a>
              <a href="disease.php">Diseases</a>
              <a href="news.php">News</a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  </div>

  <div class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <form class="modal-content glass" method="post" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title">Change Profile Photo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="action" value="upload_pic">
          <div class="mb-3">
            <label class="form-label">Choose image (JPG/PNG/WEBP, max 2MB)</label>
            <input required class="form-control" type="file" name="profile_pic" accept="image/*">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>
      </form>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
