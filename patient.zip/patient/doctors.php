<?php
session_start();
$DB_HOST = '127.0.0.1'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='care_db';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='patient'){ header('Location: ../index.php'); exit; }

$conn = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
if($conn->connect_error) die('DB Error: '.$conn->connect_error);

// handle booking
$booking_msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book'])){
    $doctor_id = (int)$_POST['doctor_id'];
    $patient_uid = (int)$_SESSION['user_id'];
    $r = $conn->query("SELECT id FROM patients WHERE user_id={$patient_uid}");
    $pid = ($r->fetch_assoc()['id'] ?? 0);
    $app_dt = $_POST['appointment_datetime'];
    $notes = trim(substr($_POST['notes'] ?? '', 0, 500));

    if($pid && $doctor_id && $app_dt){
        if(strtotime($app_dt) <= time()){
            $booking_msg = 'Appointment must be in the future.';
        } else {
            $stmt = $conn->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, status, notes) VALUES (?,?,?,?,?)");
            $status='pending';
            $stmt->bind_param('iisss',$pid,$doctor_id,$app_dt,$status,$notes);
            if($stmt->execute()) $booking_msg = 'Appointment requested successfully.';
            else $booking_msg = 'Failed to book: '.$stmt->error;
            $stmt->close();
        }
    } else { 
        $booking_msg = 'Invalid booking data.'; 
    }
}

// search query
$spec = $_GET['specialization'] ?? '';
$city = $_GET['city'] ?? '';

$where = [];
$params = [];
$types = '';

if($spec){
    $where[] = "d.specialization LIKE ?";
    $params[] = "%$spec%";
    $types .= 's';
}
if($city){
    $where[] = "c.name LIKE ?";
    $params[] = "%$city%";
    $types .= 's';
}

$where_sql = count($where) ? 'WHERE '.implode(' AND ', $where) : '';
$stmt = $conn->prepare("SELECT d.*, u.name as doctor_name, c.name as city_name 
                        FROM doctors d
                        JOIN users u ON d.user_id=u.id
                        LEFT JOIN cities c ON d.city_id=c.id
                        {$where_sql} ORDER BY u.name ASC");
if($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Find Doctors</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: #f5f7fa; font-family: 'Segoe UI', sans-serif; }
.navbar { border-bottom: 1px solid #e0e0e0; }
.feature-card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    padding: 20px;
    transition: all 0.25s;
}
.feature-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.12); }
.card-footer { display: flex; gap: 10px; margin-top: 15px; }
#bookModal { display: none; position: fixed; inset:0; background:rgba(0,0,0,0.6); z-index:1000; align-items:center; justify-content:center; }
#bookModal .modal-content { background:#fff; padding:25px; border-radius:12px; width:100%; max-width:500px; transform:scale(0.8); transition: transform 0.3s ease; }
#bookModal.show .modal-content { transform: scale(1); }
.btn-ghost { border: 1px solid #dee2e6; background: transparent; color:#495057; }
.btn-ghost:hover { background: #e9ecef; }
</style>
</head>
<body>

<nav class="navbar navbar-light bg-white shadow-sm mb-4">
  <div class="container d-flex justify-content-between">
    <a class="navbar-brand fw-bold" href="patient_dashboard.php">CARE - Patient</a>
    <a href="patient_dashboard.php" class="btn btn-outline-secondary">Dashboard</a>
  </div>
</nav>

<div class="container py-4">
  <h2 class="mb-4">Find Doctors</h2>

  <?php if($booking_msg): ?>
    <div class="alert alert-info"><?php echo htmlspecialchars($booking_msg); ?></div>
  <?php endif; ?>

  <!-- Search Form -->
  <form class="row g-3 mb-4" method="GET" action="doctors.php">
    <div class="col-md-5"><input name="specialization" value="<?php echo htmlspecialchars($spec); ?>" class="form-control" placeholder="Specialization"></div>
    <div class="col-md-5"><input name="city" value="<?php echo htmlspecialchars($city); ?>" class="form-control" placeholder="City"></div>
    <div class="col-md-2 d-flex gap-2">
      <button class="btn btn-primary w-100">Search</button>
      <a href="doctors.php" class="btn btn-outline-secondary w-100">Reset</a>
    </div>
  </form>

  <!-- Doctor Cards -->
  <div class="row g-4">
    <?php if($res->num_rows === 0): ?>
      <div class="col-12"><div class="alert alert-warning">No doctors found.</div></div>
    <?php endif; ?>
    <?php while($row = $res->fetch_assoc()): ?>
      <div class="col-md-6 col-lg-4">
        <div class="feature-card d-flex flex-column justify-content-between h-100">
          <div>
            <h5 class="fw-bold"><?php echo htmlspecialchars($row['doctor_name']); ?></h5>
            <div class="text-muted mb-1"><?php echo htmlspecialchars($row['specialization']); ?></div>
            <div class="text-muted mb-2"><?php echo htmlspecialchars($row['city_name'] ?? ''); ?></div>
            <p class="small"><?php echo htmlspecialchars($row['bio'] ?? 'No biography available.'); ?></p>
            <div><strong>Phone:</strong> <?php echo htmlspecialchars($row['phone']); ?></div>
          </div>
          <div class="card-footer mt-3">
            <button class="btn btn-primary flex-fill" onclick="openBooking(<?php echo $row['id']; ?>,'<?php echo htmlspecialchars($row['doctor_name']); ?>')">Book</button>
            <a href="tel:<?php echo htmlspecialchars($row['phone']); ?>" class="btn btn-ghost flex-fill">Contact</a>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>

<!-- Booking Modal -->
<div id="bookModal" role="dialog" aria-modal="true">
  <div class="modal-content">
    <h5>Book Appointment with <span id="modalDoctorName"></span></h5>
    <form method="POST" action="doctors.php">
      <input type="hidden" name="doctor_id" id="modalDoctorId">
      <div class="mb-3">
        <label for="appointment_datetime" class="form-label">Appointment Date & Time</label>
        <input type="datetime-local" name="appointment_datetime" id="appointment_datetime" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="notes" class="form-label">Notes (optional)</label>
        <textarea name="notes" id="notes" class="form-control" rows="3"></textarea>
      </div>
      <div class="d-flex gap-2">
        <button name="book" class="btn btn-primary flex-fill">Request</button>
        <button type="button" class="btn btn-outline-secondary flex-fill" onclick="closeBooking()">Close</button>
      </div>
    </form>
  </div>
</div>

<script>
function openBooking(id, name){
  document.getElementById('modalDoctorId').value = id;
  document.getElementById('modalDoctorName').textContent = name;
  const modal = document.getElementById('bookModal');
  modal.classList.add('show');
  modal.style.display = 'flex';
}
function closeBooking(){
  const modal = document.getElementById('bookModal');
  modal.classList.remove('show');
  setTimeout(()=> modal.style.display='none', 300);
}
document.getElementById('bookModal').addEventListener('click', e => {
  if(e.target.id === 'bookModal') closeBooking();
});
</script>

</body>
</html>
<?php $conn->close(); ?>
