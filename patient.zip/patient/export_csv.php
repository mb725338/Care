<?php
session_start();
require '../db.php';

// Ensure only patients can access
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// Fetch patient’s own records
$sql = "SELECT r.id, r.diagnosis, r.treatment, r.date_created, d.specialization, u.name AS doctor_name
        FROM records r
        JOIN doctors d ON r.doctor_id = d.user_id
        JOIN users u ON d.user_id = u.id
        WHERE r.patient_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

// Set headers for download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=my_records.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Doctor', 'Specialization', 'Diagnosis', 'Treatment', 'Date']);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['doctor_name'],
        $row['specialization'],
        $row['diagnosis'],
        $row['treatment'],
        date("d M Y", strtotime($row['date_created']))
    ]);
}
fclose($output);
exit();
