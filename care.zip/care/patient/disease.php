<?php
session_start();
require __DIR__ . '/../db.php';

// Only allow logged-in users
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Get search query
$search = trim($_GET['q'] ?? '');

// Fetch diseases with search filter
if ($search) {
    $stmt = $conn->prepare("SELECT * FROM diseases WHERE name LIKE ? OR description LIKE ? OR symptoms LIKE ? ORDER BY created_at DESC");
    $like = "%$search%";
    $stmt->bind_param("sss", $like, $like, $like);
} else {
    $stmt = $conn->prepare("SELECT * FROM diseases ORDER BY created_at DESC");
}
$stmt->execute();
$diseases = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get user info for header/sidebar
$userInfo = ['name'=>'User','profile_pic'=>null];
$pu = $conn->prepare("SELECT name,profile_pic FROM users WHERE id=?");
$pu->bind_param('i', $_SESSION['user_id']);
$pu->execute();
$r = $pu->get_result()->fetch_assoc();
if($r) $userInfo = $r;
$profilePic = !empty($userInfo['profile_pic']) ? htmlspecialchars($userInfo['profile_pic']) : '../assets/default-avatar.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Diseases — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#f9fafb;--brand:#10b981;--brand-dark:#059669;--ink:#1e293b;--muted:#6b7280;--surface:#fff;--radius-lg:14px;--shadow:0 6px 26px rgba(2,8,23,0.06);}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial;margin:0;}
.navbar{background:#fff;box-shadow:0 1px 8px rgba(2,8,23,0.04);}
.sidebar{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));padding:20px;min-height:100vh;border-right:1px solid rgba(2,8,23,0.04);}
.profile-pic-lg{width:110px;height:110px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);display:block;margin:0 auto 12px;}
.sidebar h5{margin-bottom:4px;text-align:center;}
.sidebar p.small-muted{text-align:center;color:var(--muted);margin-bottom:14px;}
.sidebar nav a{display:block;padding:8px 0;color:var(--ink);font-weight:600;text-decoration:none;}
.sidebar nav a.active,.sidebar nav a:hover{color:var(--brand);text-decoration:none;padding-left:6px;border-radius:6px;}
.container-main{padding:28px;}
.card-disease{border-radius:var(--radius-lg);box-shadow:var(--shadow);overflow:hidden;transition:transform .3s;margin-bottom:20px;background:var(--surface);padding:18px;}
.card-disease:hover{transform:translateY(-5px);}
.card-disease h5{margin-bottom:10px;color:var(--ink);}
.card-disease p{color:var(--muted);}
footer.site-footer{background:#fbfdfe;padding:12px 18px;margin-top:18px;border-top:1px solid rgba(2,8,23,0.04);font-size:.9rem;color:var(--muted);}
@media(max-width:991px){.sidebar{display:none;}.container-main{padding:18px;}}
.btn-primary {
    background: var(--brand);
    border: none;
}
.btn-primary:hover {
    background: var(--brand-dark);
}

</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
      <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i><span>CARE</span>
    </a>
    <div class="d-flex align-items-center ms-auto gap-3">
      <div class="dropdown">
        <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
          <img src="<?= $profilePic ?>" alt="avatar" style="width:44px;height:44px;object-fit:cover;border-radius:50%;border:2px solid #fff;box-shadow:var(--shadow);" class="me-2">
          <strong class="d-none d-md-inline"><?= htmlspecialchars($userInfo['name'] ?? 'User') ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid">
<div class="row g-0">

<aside class="col-12 col-md-4 col-lg-3 sidebar">
  <img src="<?= $profilePic ?>" class="profile-pic-lg">
  <h5><?= htmlspecialchars($userInfo['name']) ?></h5>
  <nav>
    <a href="patient_dashboard.php">Dashboard</a>
    <a href="appointments.php">Appointments</a>
    <a href="records.php">Medical Records</a>
    <a href="news.php">News</a>
    <a href="diseases.php" class="active">Diseases</a>
    <a href="../logout.php" class="text-danger mt-2 d-block">Logout</a>
  </nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 container-main">
<h3 class="mb-3">Diseases Information</h3>

<!-- Search form -->
<form method="GET" class="mb-4">
  <div class="input-group">
    <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-control" placeholder="Search diseases by name, symptoms or description...">
    <button type="submit" class="btn btn-primary">Search</button>
  </div>
</form>

<?php if(empty($diseases)): ?>
  <div class="alert alert-info">No disease information available.</div>
<?php else: ?>
  <?php foreach($diseases as $d): ?>
    <div class="card-disease">
      <h5><?= htmlspecialchars($d['name']) ?></h5>
      <p><strong>Description:</strong> <?= htmlspecialchars($d['description']) ?></p>
      <p><strong>Symptoms:</strong> <?= htmlspecialchars($d['symptoms']) ?></p>
      <p><strong>Prescription:</strong> <?= htmlspecialchars($d['prescription']) ?></p>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<footer class="site-footer mt-4">
  <div class="d-flex justify-content-between">
    <div>© <?= date('Y'); ?> CARE</div>
    <div>
      <a href="profile.php">Profile</a> ·
      <a href="appointments.php">Appointments</a> ·
      <a href="news.php">News</a> ·
      <a href="diseases.php">Diseases</a>
    </div>
  </div>
</footer>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
