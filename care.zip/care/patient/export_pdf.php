<?php
session_start();
require '../db.php';
require '../vendor/autoload.php'; // Dompdf

use Dompdf\Dompdf;

// Ensure only patients can access
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// Fetch patient’s own records
$sql = "SELECT r.id, r.diagnosis, r.treatment, r.date_created, d.specialization, u.name AS doctor_name
        FROM records r
        JOIN doctors d ON r.doctor_id = d.user_id
        JOIN users u ON d.user_id = u.id
        WHERE r.patient_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

// Build HTML for PDF
$html = "<h2 style='text-align:center;'>My Medical Records</h2>";
$html .= "<table border='1' cellspacing='0' cellpadding='8' width='100%'>
            <thead>
              <tr style='background:#007bff; color:white;'>
                <th>#</th>
                <th>Doctor</th>
                <th>Specialization</th>
                <th>Diagnosis</th>
                <th>Treatment</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>";

$i = 1;
while ($row = $result->fetch_assoc()) {
    $html .= "<tr>
                <td>".$i++."</td>
                <td>".htmlspecialchars($row['doctor_name'])."</td>
                <td>".htmlspecialchars($row['specialization'])."</td>
                <td>".htmlspecialchars($row['diagnosis'])."</td>
                <td>".htmlspecialchars($row['treatment'])."</td>
                <td>".date("d M Y", strtotime($row['date_created']))."</td>
              </tr>";
}
$html .= "</tbody></table>";

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("my_records.pdf", ["Attachment" => true]);
exit();
