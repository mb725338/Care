<?php
session_start();
require __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'] ?? 'patient';

// Fetch user info
$userInfo = ['name'=>'','email'=>'','profile_pic'=>null];
$stmt = $conn->prepare("SELECT name,email,profile_pic FROM users WHERE id=? LIMIT 1");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    if ($r) $userInfo = $r;
    $stmt->close();
}

$profilePic = !empty($userInfo['profile_pic']) ? htmlspecialchars($userInfo['profile_pic']) : '../assets/default-avatar.png';
$updateMsg = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    
    // Handle file upload
    if (!empty($_FILES['profile_pic']['name'])) {
        $ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        $newFile = 'uploads/' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], __DIR__ . '/' . $newFile);
        $profilePic = $newFile;
    }

    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, profile_pic=? WHERE id=?");
    if ($stmt) {
        $stmt->bind_param('sssi', $name, $email, $profilePic, $user_id);
        if ($stmt->execute()) {
            $updateMsg = "Profile updated successfully!";
        } else {
            $updateMsg = "Error updating profile: " . $stmt->error;
        }
        $stmt->close();
    }
    $userInfo['name'] = $name;
    $userInfo['email'] = $email;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Profile — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#f9fafb;--brand:#10b981;--ink:#1e293b;--muted:#6b7280;--surface:#fff;--radius-lg:14px;--shadow:0 6px 26px rgba(2,8,23,0.06);}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial;margin:0;}
.navbar{background:#fff;box-shadow:0 1px 8px rgba(2,8,23,0.04);}
.sidebar{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));padding:20px;min-height:100vh;border-right:1px solid rgba(2,8,23,0.04);}
.profile-pic-lg{width:110px;height:110px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);display:block;margin:0 auto 12px;}
.sidebar h5{text-align:center;margin-bottom:4px;}
.sidebar p.small-muted{text-align:center;color:var(--muted);margin-bottom:14px;}
.sidebar nav a{display:block;padding:8px 0;color:var(--ink);font-weight:600;text-decoration:none;}
.sidebar nav a.active,.sidebar nav a:hover{color:var(--brand);text-decoration:none;padding-left:6px;border-radius:6px;}
.container-main{padding:28px;}
.card-quiet{background:var(--surface);border-radius:var(--radius-lg);box-shadow:var(--shadow);padding:18px;}
footer.site-footer{background:#fbfdfe;padding:12px 18px;margin-top:18px;border-top:1px solid rgba(2,8,23,0.04);font-size:.9rem;color:var(--muted);}
@media(max-width:991px){.sidebar{display:none;}.container-main{padding:18px;}}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light sticky-top">
<div class="container-fluid px-3">
  <a class="navbar-brand d-flex align-items-center" href="<?= $user_role=='admin' ? 'admin_dashboard.php' : 'patient_dashboard.php' ?>">
    <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i><span>CARE</span>
  </a>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar">
  <img src="<?= $profilePic ?>" alt="Profile" class="profile-pic-lg">
  <h5><?= htmlspecialchars($userInfo['name']) ?></h5>
  <p class="small-muted"><?= htmlspecialchars($userInfo['email']) ?></p>
  <nav>
    <?php if($user_role=='patient'): ?>
      <a href="patient_dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
      <a href="appointments.php"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
      <a href="records.php"><i class="bi bi-folder2-open me-2"></i>Medical Records</a>
      <a href="news.php"><i class="bi bi-newspaper me-2"></i>News</a>
    <?php else: ?>
      <a href="admin_dashboard.php"><i class="bi bi-tachometer me-2"></i>Dashboard</a>
    <?php endif; ?>
    <a href="profile.php" class="active"><i class="bi bi-person me-2"></i>Profile</a>
    <a href="../logout.php" class="text-danger mt-2 d-block"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
  </nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 container-main">
<h3>My Profile</h3>
<?php if($updateMsg): ?>
<div class="alert alert-info"><?= htmlspecialchars($updateMsg) ?></div>
<?php endif; ?>
<div class="card-quiet">
<form method="post" enctype="multipart/form-data">
  <div class="mb-3">
    <label>Name</label>
    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($userInfo['name']) ?>" required>
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($userInfo['email']) ?>" required>
  </div>
  <div class="mb-3">
    <label>Profile Picture</label>
    <input type="file" name="profile_pic" class="form-control">
  </div>
  <button type="submit" name="update_profile" class="btn btn-success">Save Changes</button>
</form>
</div>

<footer class="site-footer mt-4">
<div class="d-flex justify-content-between">
  <div>© <?= date('Y'); ?> CARE</div>
</div>
</footer>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
