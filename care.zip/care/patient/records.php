<?php
session_start();
require __DIR__ . '/../db.php'; // adjust path if needed

// ---------------------
// Auth check (patient)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header('Location: ../login.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

// ---------------------
// Get patient_id
// ---------------------
$patient_id = null;
$pidSql = "SELECT id FROM patients WHERE user_id = ? LIMIT 1";
$pidStmt = $conn->prepare($pidSql);
if (!$pidStmt) {
    die("DB error (patient lookup): " . htmlspecialchars($conn->error));
}
$pidStmt->bind_param('i', $user_id);
$pidStmt->execute();
$pidStmt->bind_result($patient_id);
$pidStmt->fetch();
$pidStmt->close();

if (!$patient_id) {
    die("Patient record not found for your account. Please complete your profile or contact admin.");
}

// ---------------------
// Fetch medical records
// ---------------------
$records = [];
$recordsErr = '';
$sql = "
    SELECT mr.id,
           mr.diagnosis,
           mr.prescription,
           mr.visit_date,
           mr.notes,
           u.name AS doctor_name,
           d.specialization
    FROM medical_records mr
    LEFT JOIN doctors d ON mr.doctor_id = d.id
    LEFT JOIN users u ON d.user_id = u.id
    WHERE mr.patient_id = ?
    ORDER BY mr.visit_date DESC, mr.id DESC
";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    $recordsErr = "DB error (fetch records): " . $conn->error;
} else {
    $stmt->bind_param('i', $patient_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $records = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// ---------------------
// Fetch patient info (sidebar/header)
// ---------------------
$patientInfo = ['name' => 'Patient', 'email' => '', 'profile_pic' => null];
$pu = $conn->prepare("SELECT name, email, profile_pic FROM users WHERE id = ? LIMIT 1");
if ($pu) {
    $pu->bind_param('i', $user_id);
    $pu->execute();
    $r = $pu->get_result()->fetch_assoc();
    if ($r) $patientInfo = $r;
    $pu->close();
}
$profilePic = !empty($patientInfo['profile_pic']) ? htmlspecialchars($patientInfo['profile_pic']) : '../assets/default-avatar.png';

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Medical Records — CARE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root{
      --bg:#f9fafb;
      --brand:#10b981;
      --brand-dark:#059669;
      --brand-2:#0ea5e9;
      --ink:#1e293b;
      --muted:#6b7280;
      --surface:#ffffff;
      --radius-lg:14px;
      --shadow:0 6px 26px rgba(2,8,23,0.06);
    }
    *{box-sizing:border-box}
    body{ background:var(--bg); color:var(--ink); font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial; margin:0; }
    .navbar{ background:#fff; box-shadow:0 1px 8px rgba(2,8,23,0.04); }
    .navbar-brand span{ font-weight:800; font-family:"Plus Jakarta Sans",Inter,sans-serif; color:var(--ink); }
    .sidebar{ background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03)); padding:20px; min-height:100vh; border-right:1px solid rgba(2,8,23,0.04); }
    .profile-pic-lg{ width:110px; height:110px; border-radius:50%; object-fit:cover; border:6px solid var(--brand); box-shadow:var(--shadow); display:block; margin:0 auto 12px; }
    .sidebar h5{ margin-bottom:4px; text-align:center; }
    .sidebar p.small-muted{ text-align:center; color:var(--muted); margin-bottom:14px; }
    .sidebar nav a{ display:block; padding:8px 0; color:var(--ink); font-weight:600; text-decoration:none; }
    .sidebar nav a.active, .sidebar nav a:hover{ color:var(--brand); text-decoration:none; background:rgba(16,185,129,0.03); padding-left:6px; border-radius:6px; }
    .container-main{ padding:28px; }
    .card-quiet{ background:var(--surface); border-radius:var(--radius-lg); box-shadow:var(--shadow); padding:18px; }
    .table thead th{ background: rgba(16,185,129,0.06); border-bottom: none; }
    .small-muted{ color:var(--muted); }
    .visit-date{ font-weight:600; }
    footer.site-footer{ background:#fbfdfe; padding:12px 18px; margin-top:18px; border-top:1px solid rgba(2,8,23,0.04); font-size:0.9rem; color:var(--muted); }
    @media (max-width:991px){ .sidebar{ display:none; } .container-main{ padding:18px; } }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
      <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i>
      <span>CARE</span>
    </a>

    <div class="d-flex align-items-center ms-auto gap-3">
      <a class="position-relative text-decoration-none" href="messages.php" title="Messages">
        <i class="bi bi-chat-dots" style="font-size:1.25rem; color:var(--brand)"></i>
      </a>

      <div class="dropdown">
        <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
          <img src="<?= $profilePic ?>" alt="avatar" style="width:44px;height:44px;object-fit:cover;border-radius:50%;border:2px solid #fff;box-shadow:var(--shadow);" class="me-2">
          <strong class="d-none d-md-inline"><?php echo htmlspecialchars($patientInfo['name'] ?? 'Patient'); ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row g-0">
    <!-- Sidebar -->
    <aside class="col-12 col-md-4 col-lg-3 sidebar">
      <img src="<?= $profilePic ?>" alt="Profile" class="profile-pic-lg">
      <h5><?php echo htmlspecialchars($patientInfo['name'] ?? 'Patient'); ?></h5>
      <p class="small-muted"><?php echo htmlspecialchars($patientInfo['email'] ?? ''); ?></p>
      <nav>
        <a href="patient_dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="appointments.php"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
        <a href="records.php" class="active"><i class="bi bi-folder2-open me-2"></i>Medical Records</a>
        <a href="news.php"><i class="bi bi-newspaper me-2"></i>News</a>
        <a href="../logout.php" class="text-danger mt-2 d-block"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
      </nav>
    </aside>

    <!-- Main -->
    <main class="col-12 col-md-8 col-lg-9 container-main">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">My Medical Records</h3>
      </div>

      <?php if ($recordsErr): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($recordsErr); ?></div>
      <?php endif; ?>

      <div class="card-quiet">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Date</th>
                <th>Doctor</th>
                <th>Specialization</th>
                <th>Diagnosis</th>
                <th>Prescription</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($records)): ?>
                <tr>
                  <td colspan="6" class="text-center small-muted">No medical records found.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($records as $rec): ?>
                  <tr>
                    <td class="visit-date">
                      <?= htmlspecialchars(isset($rec['visit_date']) ? date('Y-m-d H:i', strtotime($rec['visit_date'])) : (isset($rec['visitDate']) ? htmlspecialchars($rec['visitDate']) : '-')) ?>
                    </td>
                    <td>
                      <?= htmlspecialchars($rec['doctor_name'] ?? '—') ?>
                    </td>
                    <td class="small-muted"><?= htmlspecialchars($rec['specialization'] ?? '-') ?></td>
                    <td style="white-space:pre-wrap; max-width:240px;"><?= htmlspecialchars($rec['diagnosis'] ?? '-') ?></td>
                    <td style="white-space:pre-wrap; max-width:240px;"><?= htmlspecialchars($rec['prescription'] ?? '-') ?></td>
                    <td style="white-space:pre-wrap; max-width:180px;"><?= htmlspecialchars($rec['notes'] ?? '-') ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <footer class="site-footer mt-4">
        <div class="d-flex justify-content-between">
          <div>© <?= date('Y'); ?> CARE</div>
          <div>
            <a href="profile.php">Profile</a> ·
            <a href="appointments.php">Appointments</a> ·
            <a href="news.php">News</a>
          </div>
        </div>
      </footer>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
