<?php
// download_record.php (for patients)
session_start();
require "../db.php";              // go up to access db.php
require "../vendor/autoload.php"; // go up to access vendor

use Dompdf\Dompdf;

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = (int)$_SESSION['user_id'];
$record_id = (int)($_GET['id'] ?? 0);

// Fetch the specific record
$stmt = $conn->prepare("
    SELECT r.diagnosis, r.prescription, r.notes, r.created_at,
           u.name AS doctor_name, d.specialization
    FROM records r
    JOIN doctors d ON r.doctor_id = d.user_id
    JOIN users u ON d.user_id = u.id
    WHERE r.id = ? AND r.patient_id = ?
");
$stmt->bind_param("ii", $record_id, $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Record not found or access denied.");
}

$record = $result->fetch_assoc();

// Build PDF HTML
$html = "
    <h2 style='text-align:center;'>Medical Record</h2>
    <p><strong>Date:</strong> " . date("M d, Y", strtotime($record['created_at'])) . "</p>
    <p><strong>Doctor:</strong> " . htmlspecialchars($record['doctor_name']) . "</p>
    <p><strong>Specialization:</strong> " . htmlspecialchars($record['specialization']) . "</p>
    <hr>
    <p><strong>Diagnosis:</strong><br>" . nl2br(htmlspecialchars($record['diagnosis'])) . "</p>
    <p><strong>Prescription:</strong><br>" . nl2br(htmlspecialchars($record['prescription'])) . "</p>
    <p><strong>Notes:</strong><br>" . nl2br(htmlspecialchars($record['notes'])) . "</p>
";

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper("A4", "portrait");
$dompdf->render();
$dompdf->stream("medical_record.pdf", ["Attachment" => true]);
exit();
