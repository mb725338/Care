<?php
session_start();
require __DIR__ . '/../db.php';

// Auth check (patient)
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header('Location: ../login.php');
    exit;
}

// ---------------------
// Get patient ID
// ---------------------
$patient_id = null;
$pidStmt = $conn->prepare("SELECT id FROM patients WHERE user_id = ? LIMIT 1");
$pidStmt->bind_param('i', $_SESSION['user_id']);
$pidStmt->execute();
$pidStmt->bind_result($patient_id);
$pidStmt->fetch();
$pidStmt->close();

if (!$patient_id) die("Patient record not found.");

// ---------------------
// Handle message submission
// ---------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'], $_POST['doctor_id'])) {
    $doctor_id = (int)$_POST['doctor_id'];
    $message = trim($_POST['message']);
    if ($message) {
        $stmt = $conn->prepare("INSERT INTO messages (patient_id, doctor_id, sender, message, created_at) VALUES (?, ?, 'patient', ?, NOW())");
        $stmt->bind_param('iis', $patient_id, $doctor_id, $message);
        $stmt->execute();
        $stmt->close();
        header("Location: messages.php?doctor_id=$doctor_id");
        exit;
    }
}

// ---------------------
// Get selected doctor
// ---------------------
$selectedDoctor = (int)($_GET['doctor_id'] ?? 0);

// ---------------------
// Fetch doctors for dropdown
// ---------------------
$doctors = $conn->query("SELECT d.id, u.name FROM doctors d JOIN users u ON d.user_id = u.id ORDER BY u.name ASC")->fetch_all(MYSQLI_ASSOC);

// ---------------------
// Fetch messages with selected doctor
// ---------------------
$messages = [];
$doctorName = '';
if ($selectedDoctor) {
    $stmt = $conn->prepare("SELECT message, sender, created_at FROM messages WHERE patient_id=? AND doctor_id=? ORDER BY created_at ASC");
    $stmt->bind_param('ii', $patient_id, $selectedDoctor);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Get doctor name
    $drRes = $conn->prepare("SELECT u.name FROM doctors d JOIN users u ON d.user_id = u.id WHERE d.id=?");
    $drRes->bind_param('i', $selectedDoctor);
    $drRes->execute();
    $doctorName = $drRes->get_result()->fetch_assoc()['name'] ?? '';
    $drRes->close();
}

// ---------------------
// Get patient info
// ---------------------
$patientInfo = ['name'=>'Patient','email'=>'','profile_pic'=>null];
$pu = $conn->prepare("SELECT name,email,profile_pic FROM users WHERE id=?");
$pu->bind_param('i', $_SESSION['user_id']);
$pu->execute();
$r = $pu->get_result()->fetch_assoc();
if($r) $patientInfo = $r;
$pu->close();
$profilePic = !empty($patientInfo['profile_pic']) ? htmlspecialchars($patientInfo['profile_pic']) : '../assets/default-avatar.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Messages — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#f9fafb;--brand:#10b981;--ink:#1e293b;--muted:#6b7280;--surface:#fff;--radius-lg:14px;--shadow:0 6px 26px rgba(2,8,23,0.06);}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial;margin:0;}
.navbar{background:#fff;box-shadow:0 1px 8px rgba(2,8,23,0.04);}
.sidebar{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));padding:20px;min-height:100vh;border-right:1px solid rgba(2,8,23,0.04);}
.profile-pic-lg{width:110px;height:110px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);display:block;margin:0 auto 12px;}
.sidebar h5{margin-bottom:4px;text-align:center;}
.sidebar p.small-muted{text-align:center;color:var(--muted);margin-bottom:14px;}
.sidebar nav a{display:block;padding:8px 0;color:var(--ink);font-weight:600;text-decoration:none;}
.sidebar nav a.active,.sidebar nav a:hover{color:var(--brand);text-decoration:none;padding-left:6px;border-radius:6px;}
.container-main{padding:28px;}
.card-quiet{background:var(--surface);border-radius:var(--radius-lg);box-shadow:var(--shadow);padding:18px;}
.chat-box{border:1px solid #ddd;border-radius:var(--radius-lg);padding:15px;height:400px;overflow-y:auto;margin-bottom:15px;background:#fff;}
.message{margin-bottom:12px;max-width:70%;padding:10px;border-radius:12px;}
.message.patient{background:var(--brand);color:#fff;margin-left:auto;}
.message.doctor{background:#ddd;margin-right:auto;}
.btn-brand{background:var(--brand);color:#fff;border:none;}
.btn-brand:hover{background:#059669;color:#fff;}
footer.site-footer{background:#fbfdfe;padding:12px 18px;margin-top:18px;border-top:1px solid rgba(2,8,23,0.04);font-size:.9rem;color:var(--muted);}
@media(max-width:991px){.sidebar{display:none;}.container-main{padding:18px;}}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
      <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i><span>CARE</span>
    </a>
    <div class="d-flex align-items-center ms-auto gap-3">
      <div class="dropdown">
        <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
          <img src="<?= $profilePic ?>" alt="avatar" style="width:44px;height:44px;object-fit:cover;border-radius:50%;border:2px solid #fff;box-shadow:var(--shadow);" class="me-2">
          <strong class="d-none d-md-inline"><?= htmlspecialchars($patientInfo['name'] ?? 'Patient') ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar">
  <img src="<?= $profilePic ?>" alt="Profile" class="profile-pic-lg">
  <h5><?= htmlspecialchars($patientInfo['name'] ?? 'Patient') ?></h5>
  <p class="small-muted"><?= htmlspecialchars($patientInfo['email'] ?? '') ?></p>
  <nav>
    <a href="patient_dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
    <a href="appointments.php"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
    <a href="records.php"><i class="bi bi-folder2-open me-2"></i>Medical Records</a>
    <a href="news.php"><i class="bi bi-newspaper me-2"></i>News</a>
    <a href="messages.php" class="active"><i class="bi bi-chat-dots me-2"></i>Messages</a>
    <a href="../logout.php" class="text-danger mt-2 d-block"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
  </nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 container-main">
<h3 class="mb-3">Messages</h3>

<form method="get" class="mb-3">
  <label>Select Doctor:</label>
  <select name="doctor_id" class="form-select" onchange="this.form.submit()">
    <option value="">-- Select Doctor --</option>
    <?php foreach($doctors as $d): ?>
      <option value="<?= $d['id'] ?>" <?= $selectedDoctor==$d['id']?'selected':'' ?>><?= htmlspecialchars($d['name']) ?></option>
    <?php endforeach; ?>
  </select>
</form>

<?php if($selectedDoctor): ?>
  <h5>Chat with Dr. <?= htmlspecialchars($doctorName) ?></h5>
  <div class="chat-box" id="chatBox">
    <?php if(empty($messages)): ?>
      <p class="small-muted text-center">No messages yet. Start the conversation!</p>
    <?php else: ?>
      <?php foreach($messages as $m): ?>
        <div class="message <?= $m['sender'] ?>">
          <?= htmlspecialchars($m['message']) ?><br>
          <small class="text-muted"><?= date('Y-m-d H:i', strtotime($m['created_at'])) ?></small>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <form method="post">
    <input type="hidden" name="doctor_id" value="<?= $selectedDoctor ?>">
    <div class="input-group">
      <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
      <button class="btn btn-brand" type="submit">Send</button>
    </div>
  </form>
<?php endif; ?>

<footer class="site-footer mt-4">
  <div class="d-flex justify-content-between">
    <div>© <?= date('Y'); ?> CARE</div>
    <div>
      <a href="profile.php">Profile</a> ·
      <a href="appointments.php">Appointments</a> ·
      <a href="news.php">News</a>
    </div>
  </div>
</footer>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Scroll chat to bottom
  const chatBox = document.getElementById('chatBox');
  if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;
</script>
</body>
</html>
