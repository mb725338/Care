<?php
session_start();
require __DIR__ . '/../db.php';

// =====================
// Auth Check
// =====================
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header('Location: ../login.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

// =====================
// Get Patient ID
// =====================
$patient_id = null;
$pidStmt = $conn->prepare("SELECT id FROM patients WHERE user_id = ? LIMIT 1");
$pidStmt->bind_param("i", $user_id);
$pidStmt->execute();
$pidStmt->bind_result($patient_id);
$pidStmt->fetch();
$pidStmt->close();

if (!$patient_id) die("No patient record found. Please contact admin.");

// =====================
// Book Appointment
// =====================
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $doctor_id = (int)($_POST['doctor_id'] ?? 0);
    $date      = trim($_POST['date'] ?? '');
    $time      = trim($_POST['time'] ?? '');
    $reason    = trim($_POST['reason'] ?? '');

    if (!$doctor_id || !$date || !$time) $error = "Please fill in all required fields.";
    elseif (!strtotime($date) || !preg_match('/^\d{2}:\d{2}$/', $time)) $error = "Invalid date or time format.";
    else {
        $stmt = $conn->prepare("INSERT INTO appointments 
            (patient_id, doctor_id, appointment_date, appointment_time, reason, status) 
            VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("iisss", $patient_id, $doctor_id, $date, $time, $reason);
        $success = $stmt->execute() ? "Appointment booked successfully." : "Error: ".$stmt->error;
        $stmt->close();
    }
}

// =====================
// Cancel Appointment
// =====================
if (isset($_GET['cancel']) && ctype_digit($_GET['cancel'])) {
    $appt_id = (int)$_GET['cancel'];
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id=? AND patient_id=?");
    $stmt->bind_param("ii", $appt_id, $patient_id);
    $stmt->execute();
    $success = "Appointment cancelled.";
    $stmt->close();
}

// =====================
// Fetch Doctors (with fees)
// =====================
$doctors = [];
$dres = $conn->query("SELECT d.id, u.name, d.specialization, d.fees 
                      FROM doctors d 
                      JOIN users u ON d.user_id=u.id 
                      ORDER BY u.name");
while ($row = $dres->fetch_assoc()) $doctors[] = $row;

// =====================
// Fetch Appointments (with fees)
// =====================
$appointments = [];
$stmt = $conn->prepare("
    SELECT a.id, a.appointment_date, a.appointment_time, a.reason, a.status, 
           u.name AS doctor_name, d.specialization, d.fees
    FROM appointments a
    JOIN doctors d ON a.doctor_id=d.id
    JOIN users u ON d.user_id=u.id
    WHERE a.patient_id=?
    ORDER BY a.appointment_date DESC, a.appointment_time DESC
");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) $appointments[] = $row;
$stmt->close();

// =====================
// Patient Info
// =====================
$patientInfo = [];
$pu = $conn->prepare("SELECT name,email,profile_pic FROM users WHERE id=? LIMIT 1");
$pu->bind_param("i",$user_id);
$pu->execute();
$resu = $pu->get_result();
$patientInfo = $resu->fetch_assoc() ?: [];
$pu->close();
$profilePic = !empty($patientInfo['profile_pic']) ? htmlspecialchars($patientInfo['profile_pic']) : '../assets/default-avatar.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Appointments — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#f9fafb;--brand:#10b981;--ink:#1e293b;--muted:#6b7280;--surface:#fff;--radius-lg:14px;--shadow:0 6px 26px rgba(2,8,23,0.06);}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial;margin:0;}
.navbar{background:#fff;box-shadow:0 1px 8px rgba(2,8,23,0.04);}
.sidebar{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));padding:20px;min-height:100vh;border-right:1px solid rgba(2,8,23,0.04);}
.profile-pic-lg{width:110px;height:110px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);display:block;margin:0 auto 12px;}
.sidebar h5{text-align:center;margin-bottom:4px;}
.sidebar p.small-muted{text-align:center;color:var(--muted);margin-bottom:14px;}
.sidebar nav a{display:block;padding:8px 0;color:var(--ink);font-weight:600;text-decoration:none;}
.sidebar nav a.active,.sidebar nav a:hover{color:var(--brand);text-decoration:none;padding-left:6px;border-radius:6px;}
.container-main{padding:28px;}
.card-quiet{background:var(--surface);border-radius:var(--radius-lg);box-shadow:var(--shadow);padding:18px;margin-bottom:20px;}
.appointment-card{border-radius:var(--radius-lg);box-shadow:var(--shadow);padding:15px;margin-bottom:15px;background:var(--surface);}
.badge-pending{background:#f59e0b;color:#fff;padding:3px 7px;border-radius:6px;}
.badge-confirmed{background:#10b981;color:#fff;padding:3px 7px;border-radius:6px;}
.badge-cancelled{background:#ef4444;color:#fff;padding:3px 7px;border-radius:6px;}
.btn-cancel{font-size:.8rem;padding:.25rem .5rem;}
footer.site-footer{background:#fbfdfe;padding:12px 18px;margin-top:18px;border-top:1px solid rgba(2,8,23,0.04);font-size:.9rem;color:var(--muted);}
@media(max-width:991px){.sidebar{display:none;}.container-main{padding:18px;}}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
<div class="container-fluid px-3">
  <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
    <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i><span>CARE</span>
  </a>
  <div class="d-flex align-items-center ms-auto gap-3">
    <img src="<?= $profilePic ?>" width="44" height="44" class="rounded-circle">
    <strong><?= htmlspecialchars($patientInfo['name'] ?? 'Patient') ?></strong>
  </div>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar">
  <img src="<?= $profilePic ?>" class="profile-pic-lg">
  <h5><?= htmlspecialchars($patientInfo['name']) ?></h5>
  <p class="small-muted"><?= htmlspecialchars($patientInfo['email']) ?></p>
  <nav>
    <a href="patient_dashboard.php">Dashboard</a>
    <a href="appointments.php" class="active">Appointments</a>
    <a href="records.php">Medical Records</a>
    <a href="news.php">News</a>
    <a href="../logout.php" class="text-danger mt-2 d-block">Logout</a>
  </nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 container-main">
<h3 class="mb-3">Book Appointment</h3>
<?php if($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

<div class="card-quiet">
<form method="POST">
  <div class="mb-3">
    <label>Doctor</label>
    <select name="doctor_id" class="form-select" required>
      <option value="">Select Doctor</option>
      <?php foreach($doctors as $doc): ?>
        <option value="<?= $doc['id'] ?>">
            <?= htmlspecialchars($doc['name']) ?> (<?= htmlspecialchars($doc['specialization']) ?>) — 
            Fee: PKR <?= number_format($doc['fees'], 2) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="row g-3 mb-3">
    <div class="col-md-6">
      <label>Date</label>
      <input type="date" name="date" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label>Time</label>
      <input type="time" name="time" class="form-control" required>
    </div>
  </div>
  <div class="mb-3">
    <label>Reason</label>
    <textarea name="reason" class="form-control" rows="2"></textarea>
  </div>
  <button type="submit" name="book_appointment" class="btn btn-success">Book Appointment</button>
</form>
</div>

<h3 class="mt-4 mb-3">My Appointments</h3>
<?php if(empty($appointments)): ?>
  <div class="alert alert-info">No appointments booked yet.</div>
<?php else: ?>
  <?php foreach($appointments as $a): ?>
    <div class="appointment-card">
      <div class="d-flex justify-content-between align-items-center mb-1">
        <h5 class="mb-0"><?= htmlspecialchars($a['doctor_name']) ?> (<?= htmlspecialchars($a['specialization']) ?>)</h5>
        <span class="<?= $a['status']=='confirmed' ? 'badge-confirmed' : ($a['status']=='cancelled'?'badge-cancelled':'badge-pending') ?>"><?= ucfirst($a['status']) ?></span>
      </div>
      <div class="small text-muted mb-2">
        <?= htmlspecialchars($a['appointment_date']) ?> at <?= htmlspecialchars($a['appointment_time']) ?> — 
        Fee: PKR <?= number_format($a['fees'], 2) ?>
      </div>
      <div><?= htmlspecialchars($a['reason'] ?? '-') ?></div>
      <?php if($a['status']=='pending'): ?>
        <a href="?cancel=<?= $a['id'] ?>" class="btn btn-outline-danger btn-cancel mt-2" onclick="return confirm('Cancel this appointment?')">Cancel</a>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<footer class="site-footer mt-4">
  <div class="d-flex justify-content-between">
    <div>© <?= date('Y'); ?> CARE</div>
  </div>
</footer>
</main>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
