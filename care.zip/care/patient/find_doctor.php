<?php
session_start();
require __DIR__ . '/../db.php'; // adjust path

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'patient') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user info for sidebar/header
$userInfo = ['name'=>'User','email'=>'','profile_pic'=>null];
$pu = $conn->prepare("SELECT name,email,profile_pic FROM users WHERE id=?");
if($pu){
    $pu->bind_param('i', $user_id);
    $pu->execute();
    $r = $pu->get_result()->fetch_assoc();
    if($r) $userInfo = $r;
    $pu->close();
}
$profilePic = !empty($userInfo['profile_pic']) ? htmlspecialchars($userInfo['profile_pic']) : '../assets/default-avatar.png';

// Handle search/filter
$search = $_GET['search'] ?? '';
$city = $_GET['city'] ?? '';
$specialization = $_GET['specialization'] ?? '';

$query = "SELECT d.id, u.name AS doctor_name, d.specialization, c.name AS city_name, u.profile_pic
          FROM doctors d
          JOIN users u ON d.user_id = u.id
          LEFT JOIN cities c ON d.city_id = c.id
          WHERE 1=1";

$params = [];
$types = '';
if($search){
    $query .= " AND u.name LIKE ?";
    $types .= 's';
    $params[] = "%$search%";
}
if($city){
    $query .= " AND c.id = ?";
    $types .= 'i';
    $params[] = $city;
}
if($specialization){
    $query .= " AND d.specialization LIKE ?";
    $types .= 's';
    $params[] = "%$specialization%";
}

$stmt = $conn->prepare($query);
if($params){
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$doctors = $result->fetch_all(MYSQLI_ASSOC);

// Fetch cities for filter dropdown
$citiesRes = $conn->query("SELECT id, name FROM cities ORDER BY name ASC");
$citiesList = $citiesRes ? $citiesRes->fetch_all(MYSQLI_ASSOC) : [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Find Doctor — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#f9fafb;--brand:#10b981;--brand-dark:#059669;--ink:#1e293b;--muted:#6b7280;--surface:#fff;--radius-lg:14px;--shadow:0 6px 26px rgba(2,8,23,0.06);}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial;margin:0;}
.navbar{background:#fff;box-shadow:0 1px 8px rgba(2,8,23,0.04);}
.sidebar{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));padding:20px;min-height:100vh;border-right:1px solid rgba(2,8,23,0.04);}
.profile-pic-lg{width:110px;height:110px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);display:block;margin:0 auto 12px;}
.sidebar h5{margin-bottom:4px;text-align:center;}
.sidebar p.small-muted{text-align:center;color:var(--muted);margin-bottom:14px;}
.sidebar nav a{display:block;padding:8px 0;color:var(--ink);font-weight:600;text-decoration:none;}
.sidebar nav a.active,.sidebar nav a:hover{color:var(--brand);text-decoration:none;padding-left:6px;border-radius:6px;}
.container-main{padding:28px;}
.card-quiet{background:var(--surface);border-radius:var(--radius-lg);box-shadow:var(--shadow);padding:18px;margin-bottom:20px;}
.doctor-card{display:flex;align-items:center;gap:15px;padding:12px;border-radius:var(--radius-lg);box-shadow:var(--shadow);background:var(--surface);transition:transform .2s;}
.doctor-card:hover{transform:translateY(-3px);}
.doctor-card img{width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid var(--brand);}
.doctor-info h5{margin:0;color:var(--ink);}
.doctor-info p{margin:0;color:var(--muted);}
footer.site-footer{background:#fbfdfe;padding:12px 18px;margin-top:18px;border-top:1px solid rgba(2,8,23,0.04);font-size:.9rem;color:var(--muted);}
@media(max-width:991px){.sidebar{display:none;}.container-main{padding:18px;}}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex align-items-center" href="patient_dashboard.php">
      <i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i><span>CARE</span>
    </a>
    <div class="d-flex align-items-center ms-auto gap-3">
      <div class="dropdown">
        <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
          <img src="<?= $profilePic ?>" alt="avatar" style="width:44px;height:44px;object-fit:cover;border-radius:50%;border:2px solid #fff;" class="me-2">
          <strong class="d-none d-md-inline"><?= htmlspecialchars($userInfo['name'] ?? 'User') ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar">
  <img src="<?= $profilePic ?>" alt="Profile" class="profile-pic-lg">
  <h5><?= htmlspecialchars($userInfo['name'] ?? 'User') ?></h5>
  <p class="small-muted"><?= htmlspecialchars($userInfo['email'] ?? '') ?></p>
  <nav>
    <a href="patient_dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
    <a href="appointments.php"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
    <a href="records.php"><i class="bi bi-folder2-open me-2"></i>Medical Records</a>
    <a href="news.php"><i class="bi bi-newspaper me-2"></i>News</a>
    <a href="find_doctor.php" class="active"><i class="bi bi-search me-2"></i>Find Doctor</a>
    <a href="../logout.php" class="text-danger mt-2 d-block"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
  </nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 container-main">
<h3 class="mb-3">Find a Doctor</h3>

<div class="card-quiet">
  <form method="get" class="row g-3">
    <div class="col-md-4"><input type="text" name="search" class="form-control" placeholder="Doctor name" value="<?= htmlspecialchars($search) ?>"></div>
    <div class="col-md-4">
      <select name="city" class="form-control">
        <option value="">Select city</option>
        <?php foreach($citiesList as $c): ?>
          <option value="<?= $c['id'] ?>" <?= ($c['id']==$city)?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><input type="text" name="specialization" class="form-control" placeholder="Specialization" value="<?= htmlspecialchars($specialization) ?>"></div>
    <div class="col-12"><button type="submit" class="btn btn-brand">Search</button></div>
  </form>
</div>

<?php if(empty($doctors)): ?>
  <div class="alert alert-info mt-3">No doctors found.</div>
<?php else: ?>
  <?php foreach($doctors as $d): ?>
    <div class="doctor-card mt-3">
      <img src="<?= htmlspecialchars($d['profile_pic'] ?: '../assets/default-avatar.png') ?>" alt="<?= htmlspecialchars($d['doctor_name']) ?>">
      <div class="doctor-info">
        <h5><?= htmlspecialchars($d['doctor_name']) ?></h5>
        <p><strong>Specialization:</strong> <?= htmlspecialchars($d['specialization'] ?: '-') ?></p>
        <p><strong>City:</strong> <?= htmlspecialchars($d['city_name'] ?: '-') ?></p>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<footer class="site-footer mt-4">
  <div class="d-flex justify-content-between">
    <div>© <?= date('Y'); ?> CARE</div>
    <div>
      <a href="profile.php">Profile</a> ·
      <a href="appointments.php">Appointments</a> ·
      <a href="news.php">News</a>
    </div>
  </div>
</footer>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
