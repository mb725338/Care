Standalone Patient Panel
Files included:
- patient_dashboard.php
- doctors.php
- appointments.php
- profile.php
- records.php
- logout.php
- assets/style2.css   (provided or copied from your uploaded file)

Important:
- These are standalone PHP pages (no external includes). Each file contains the DB connection string at the top.
- Edit DB credentials if necessary (host, user, pass).
- These pages expect a logged-in patient session:
    $_SESSION['user_id']  (maps to users.id)
    $_SESSION['role'] == 'patient'
  Typically provided by your existing login flow (index.php).
- Place the folder contents in a web-accessible directory and visit patient_dashboard.php as a patient session.

Security notes:
- For production, move DB credentials to a secure include and implement CSRF protection, input sanitization and stronger validation.
