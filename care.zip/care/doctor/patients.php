<?php
session_start();
require __DIR__ . '/../db.php';

// ---------------------
// Auth check (doctor)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ---------------------
// Fetch doctor info
// ---------------------
$stmt = $conn->prepare("
    SELECT d.id AS doctor_id, d.specialization, d.phone, d.address, d.bio,
           u.id AS uid, u.name, u.email, u.profile_pic
    FROM doctors d
    JOIN users u ON d.user_id=u.id
    WHERE d.user_id=? LIMIT 1
");
$stmt->bind_param('i',$uid);
$stmt->execute();
$doctor = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();

$doc_id = $doctor['doctor_id'] ?? 0;

// ---------------------
// Fetch patients
// ---------------------
$patients = [];
if($doc_id){
    $stmt = $conn->prepare("
        SELECT DISTINCT u.id AS user_id, u.name, u.email, u.created_at
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE a.doctor_id=?
        ORDER BY u.name ASC
    ");
    $stmt->bind_param('i',$doc_id);
    $stmt->execute();
    $patients = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// ---------------------
// Stats
// ---------------------
$totalPatients = count($patients);
$totalAppointments = $conn->query("SELECT COUNT(*) AS c FROM appointments WHERE doctor_id={$doc_id}")->fetch_assoc()['c']??0;
$upcoming = $conn->query("SELECT * FROM appointments WHERE doctor_id={$doc_id} AND appointment_date>=NOW() ORDER BY appointment_date ASC LIMIT 1")->fetch_assoc();
$patientsSeen = $conn->query("SELECT COUNT(DISTINCT patient_id) AS c FROM appointments WHERE doctor_id={$doc_id} AND status='completed'")->fetch_assoc()['c']??0;

// ---------------------
// Profile pic
// ---------------------
$profilePic = !empty($doctor['profile_pic']) ? $doctor['profile_pic'] : '../assets/default-avatar.png';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>My Patients — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root {--brand:#10b981; --brand-dark:#059669; --ink:#1e293b; --surface:#fff; --radius-lg:14px; --shadow:0 2px 12px rgba(0,0,0,0.08);}
body{background:#f9fafb;font-family:'Segoe UI',sans-serif;color:var(--ink);}
.sidebar{min-height:100vh;padding:1.25rem;background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a{color:var(--ink);display:block;padding:0.5rem 0.25rem;border-radius:8px;font-weight:500;}
.sidebar a:hover{background:rgba(16,185,129,0.08);color:var(--brand-dark);text-decoration:none;}
.avatar-sm{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid #fff;box-shadow:var(--shadow);}
.profile-pic-lg{width:120px;height:120px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);}
.card-quiet{border-radius:var(--radius-lg);padding:1.25rem;background:var(--surface);box-shadow:var(--shadow);transition:all .3s ease;height:100%;display:flex;flex-direction:column;justify-content:space-between;}
.card-quiet:hover{transform:translateY(-3px);box-shadow:0 4px 18px rgba(0,0,0,0.12);}
.btn-primary{background:var(--brand);border:none;}
.btn-primary:hover{background:var(--brand-dark);}
.btn-outline-primary{border-color:var(--brand);color:var(--brand);}
.btn-outline-primary:hover{background:var(--brand);color:#fff;}
.table-card{border-radius:var(--radius-lg);padding:1.25rem;background:var(--surface);box-shadow:var(--shadow);}
</style>
</head>
<body>

<div class="container-fluid">
<div class="row g-0">

<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?php echo $profilePic; ?>" class="profile-pic-lg mb-3">
<h4><?php echo htmlspecialchars($doctor['name']??'Doctor'); ?></h4>
<div class="text-muted"><?php echo htmlspecialchars($doctor['specialization']??''); ?></div>
<div class="mt-2 mb-4">
<a href="profile.php" class="btn btn-outline-primary btn-sm me-1">Edit Profile</a>
</div>
<nav class="text-start">
<a href="doctor_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="records.php" class="mb-2 d-block"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="messages.php" class="mb-2 d-block"><i class="bi bi-chat-left-text me-2"></i>Messages</a>
<a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 p-4">
<h2 class="mb-3">My Patients</h2>

<div class="row g-4 mb-4">
<div class="col-md-4"><div class="card-quiet text-center"><h3><?php echo $totalPatients; ?></h3><div class="text-muted">Total Patients</div></div></div>
<div class="col-md-4"><div class="card-quiet text-center"><h3><?php echo $totalAppointments; ?></h3><div class="text-muted">Total Appointments</div></div></div>
<div class="col-md-4"><div class="card-quiet text-center"><h3><?php echo $patientsSeen; ?></h3><div class="text-muted">Patients Seen</div></div></div>
</div>

<div class="card table-card p-3">
<?php if(!empty($patients)): ?>
<div class="table-responsive">
<table class="table table-hover align-middle">
<thead class="table-light">
<tr>
<th>Name</th>
<th>Email</th>
<th>First Visit</th>
<th class="text-end">Actions</th>
</tr>
</thead>
<tbody>
<?php foreach($patients as $p): ?>
<tr>
<td><?= htmlspecialchars($p['name']); ?></td>
<td><?= htmlspecialchars($p['email']); ?></td>
<td><?= date("M j, Y", strtotime($p['created_at'])); ?></td>
<td class="text-end">
<a href="records.php?patient_id=<?= $p['user_id']; ?>" class="btn btn-sm btn-outline-primary me-2"><i class="bi bi-file-medical me-1"></i>Records</a>
<a href="messages.php?patient_id=<?= $p['user_id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-chat-dots me-1"></i>Message</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="text-muted">No patients found.</div>
<?php endif; ?>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
