<?php
session_start();
require "../db.php"; // DB connection

// Role check
if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? "") !== "admin") {
    header("Location: ../login.php");
    exit();
}

// --- Fetch Appointments per weekday ---
$stmt = $conn->prepare("
    SELECT WEEKDAY(appointment_date) AS wday, COUNT(*) AS total
    FROM appointments
    WHERE YEARWEEK(appointment_date, 1) = YEARWEEK(CURDATE(),1)
    GROUP BY WEEKDAY(appointment_date)
");
if (!$stmt) {
    die("SQL Error (Appointments): " . $conn->error);
}
$stmt->execute();
$appointments_result = $stmt->get_result();
$appointments_data = [];
while ($row = $appointments_result->fetch_assoc()) {
    $appointments_data[$row['wday']] = $row['total'];
}

// --- Fetch Messages per weekday ---
$stmt = $conn->prepare("
    SELECT WEEKDAY(created_at) AS wday, COUNT(*) AS total
    FROM messages
    WHERE YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(),1)
    GROUP BY WEEKDAY(created_at)
");
if (!$stmt) {
    die("SQL Error (Messages): " . $conn->error);
}
$stmt->execute();
$messages_result = $stmt->get_result();
$messages_data = [];
while ($row = $messages_result->fetch_assoc()) {
    $messages_data[$row['wday']] = $row['total'];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Reports</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f9f9f9;
    }
    .sidebar {
      height: 100vh;
      width: 240px;
      position: fixed;
      left: 0;
      top: 0;
      background: #198754;
      color: white;
      padding-top: 20px;
    }
    .sidebar h4 {
      text-align: center;
      margin-bottom: 30px;
    }
    .sidebar a {
      display: block;
      color: white;
      padding: 12px 20px;
      text-decoration: none;
      font-weight: 500;
    }
    .sidebar a:hover {
      background: rgba(255,255,255,0.15);
    }
    .content {
      margin-left: 260px;
      padding: 20px;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.05);
      margin-bottom: 20px;
    }
    canvas {
      max-height: 350px;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h4>Admin Panel</h4>
    <a href="admin_dashboard.php">📊 Dashboard</a>
    <a href="manage_patients.php">🧑‍🤝‍🧑 Manage Patients</a>
    <a href="manage_doctors.php">👨‍⚕️ Manage Doctors</a>
    <a href="manage_cities.php">🌆 Manage Cities</a>
    <a href="view_reports.php" class="bg-success">📈 Reports</a>
    <a href="../logout.php">🚪 Logout</a>
  </div>

  <!-- Content -->
  <div class="content">
    <h2 class="mb-4">📊 Weekly Reports</h2>
    
    <div class="row">
      <!-- Appointments Chart -->
      <div class="col-md-6">
        <div class="card p-3">
          <h5 class="mb-3">Appointments This Week</h5>
          <canvas id="appointmentsChart"></canvas>
        </div>
      </div>
      <!-- Messages Chart -->
      <div class="col-md-6">
        <div class="card p-3">
          <h5 class="mb-3">Messages This Week</h5>
          <canvas id="messagesChart"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- Charts Script -->
  <script>
    const weekdays = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

    // Appointments Data
    const appointmentsData = Array(7).fill(0);
    <?php foreach ($appointments_data as $day => $total): ?>
      appointmentsData[<?= $day ?>] = <?= $total ?>;
    <?php endforeach; ?>

    // Messages Data
    const messagesData = Array(7).fill(0);
    <?php foreach ($messages_data as $day => $total): ?>
      messagesData[<?= $day ?>] = <?= $total ?>;
    <?php endforeach; ?>

    new Chart(document.getElementById("appointmentsChart"), {
      type: "bar",
      data: {
        labels: weekdays,
        datasets: [{
          label: "Appointments",
          data: appointmentsData,
          backgroundColor: "#198754"
        }]
      }
    });

    new Chart(document.getElementById("messagesChart"), {
      type: "line",
      data: {
        labels: weekdays,
        datasets: [{
          label: "Messages",
          data: messagesData,
          borderColor: "#0d6efd",
          backgroundColor: "rgba(13,110,253,0.2)",
          fill: true,
          tension: 0.3
        }]
      }
    });
  </script>
</body>
</html>
