<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Fetch doctor’s patient records
$sql = "SELECT p.name AS patient_name, p.email, p.phone, r.diagnosis, r.treatment, r.date_created
        FROM records r
        JOIN patients p ON r.patient_id = p.id
        WHERE r.doctor_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=patient_records.csv');

$output = fopen('php://output', 'w');

// Add CSV headers
fputcsv($output, ['Patient Name', 'Email', 'Phone', 'Diagnosis', 'Treatment', 'Date']);

// Add rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['patient_name'],
        $row['email'],
        $row['phone'],
        $row['diagnosis'],
        $row['treatment'],
        date("d M Y", strtotime($row['date_created']))
    ]);
}

fclose($output);
exit();
