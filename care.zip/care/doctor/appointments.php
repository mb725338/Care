<?php
session_start();
require __DIR__ . '/../db.php';

// ---------------------
// Auth check (doctor)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ---------------------
// Fetch doctor info
// ---------------------
$stmt = $conn->prepare("
    SELECT d.id AS doctor_id, u.name, u.profile_pic
    FROM doctors d
    JOIN users u ON d.user_id = u.id
    WHERE d.user_id=? LIMIT 1
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc() ?: [];
$stmt->close();

$doc_id = $doctor['doctor_id'] ?? 0;
$profilePic = !empty($doctor['profile_pic']) ? "../uploads/" . $doctor['profile_pic'] : '../assets/default-avatar.png';

// ---------------------
// Fetch appointments
// ---------------------
$appointments = [];
$sql = "
    SELECT a.id, a.patient_id, a.appointment_date, a.status,
           u.name AS patient_name
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u ON p.user_id = u.id
    WHERE a.doctor_id = ?
    ORDER BY a.appointment_date DESC
";
if ($doc_id) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $doc_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $appointments = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// ---------------------
// Handle status update
// ---------------------
$status_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $app_id = (int)$_POST['appointment_id'];
    $new_status = $_POST['status'];

    $upd = $conn->prepare("UPDATE appointments SET status=? WHERE id=? AND doctor_id=?");
    if ($upd) {
        $upd->bind_param('sii', $new_status, $app_id, $doc_id);
        if ($upd->execute()) {
            $status_msg = 'Appointment status updated.';
        } else {
            error_log("DB Error (update_status): " . $upd->error);
            $status_msg = 'Update failed. Please try again later.';
        }
        $upd->close();
    }

    // Refresh appointments
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $doc_id);
    $stmt->execute();
    $appointments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Appointments — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root {--brand:#10b981; --brand-dark:#059669; --ink:#1e293b; --surface:#fff; --radius-lg:14px; --shadow:0 2px 12px rgba(0,0,0,0.08);}
body {background:#f9fafb; font-family:'Segoe UI',sans-serif; color:var(--ink);}
.sidebar {min-height:100vh; padding:1.25rem; background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a {color:var(--brand); display:block; padding:0.5rem 0.25rem; border-radius:8px; font-weight:500;}
.sidebar a:hover {background:rgba(16,185,129,0.08); color:var(--brand-dark); text-decoration:none;}
.avatar-sm {width:44px; height:44px; border-radius:50%; object-fit:cover; border:2px solid #fff; box-shadow:var(--shadow);}
.profile-pic-lg {width:120px; height:120px; border-radius:50%; object-fit:cover; border:6px solid var(--brand); box-shadow:var(--shadow);}
.card-quiet {border-radius:var(--radius-lg); padding:1.25rem; background:var(--surface); box-shadow:var(--shadow);}
.navbar .navbar-brand, .navbar .nav-link, .navbar i {color:var(--brand);}
footer.site-footer {background:#f8f9fa; padding:1.25rem; margin-top:2rem; border-top:1px solid rgba(2,8,23,0.08); font-size:0.9rem;}
footer.site-footer a {text-decoration:none; color:#6c757d; margin:0 0.5rem;}
footer.site-footer a:hover {color:var(--brand-dark);}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm">
<div class="container-fluid">
<a class="navbar-brand d-flex align-items-center" href="doctor_dashboard.php">
<i class="bi bi-heart-pulse-fill me-2"></i>
<span>CARE</span></a>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">

<!-- Sidebar -->
<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?php echo htmlspecialchars($profilePic); ?>" alt="profile" class="profile-pic-lg mb-3">
<h4><?php echo htmlspecialchars($doctor['name'] ?? 'Doctor'); ?></h4>
<div class="mt-2 mb-4">
<a href="profile.php" class="btn btn-outline-primary btn-sm me-1">Edit Profile</a>
</div>
<nav class="text-start">
<a href="doctor_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="patients.php" class="mb-2 d-block"><i class="bi bi-people me-2"></i>Patients</a>
<a href="availability.php" class="mb-2 d-block"><i class="bi bi-calendar-range me-2"></i>Availability</a>
<a href="records.php" class="mb-2 d-block"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<!-- Main Content -->
<main class="col-12 col-md-8 col-lg-9 p-4">
<h2 class="mb-3">Appointments</h2>

<?php if($status_msg): ?>
<div class="alert alert-info"><?php echo htmlspecialchars($status_msg); ?></div>
<?php endif; ?>

<div class="card-quiet">
<div class="table-responsive">
<table class="table align-middle">
<thead>
<tr>
<th>Patient</th>
<th>Date & Time</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php if(empty($appointments)): ?>
<tr><td colspan="4" class="text-center text-muted">No appointments found.</td></tr>
<?php else: foreach($appointments as $app): ?>
<tr>
<td><?php echo htmlspecialchars($app['patient_name']); ?></td>
<td><?php echo date('M d, Y H:i', strtotime($app['appointment_date'])); ?></td>
<td><?php echo ucfirst($app['status']); ?></td>
<td>
<button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#statusModal" 
data-id="<?php echo $app['id']; ?>" data-status="<?php echo $app['status']; ?>">Update</button>
</td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>
</div>
</div>

<footer class="site-footer mt-4">
<div class="container d-flex justify-content-between align-items-center">
<div>&copy; <?php echo date('Y'); ?> CARE</div>
<div>
<a href="profile.php">Profile</a>
<a href="appointments.php">Appointments</a>
<a href="records.php">Records</a>
</div>
</div>
</footer>

</main>
</div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="statusModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<form class="modal-content" method="post">
<div class="modal-header">
<h5 class="modal-title">Update Appointment Status</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="action" value="update_status">
<input type="hidden" name="appointment_id" id="appointment_id">
<div class="mb-3">
<label>Status</label>
<select name="status" id="appointment_status" class="form-select" required>
<option value="pending">Pending</option>
<option value="completed">Completed</option>
<option value="cancelled">Cancelled</option>
</select>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Update</button>
</div>
</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
var statusModal = document.getElementById('statusModal');
statusModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var id = button.getAttribute('data-id');
    var status = button.getAttribute('data-status');
    document.getElementById('appointment_id').value = id;
    document.getElementById('appointment_status').value = status;
});
</script>
</body>
</html>
