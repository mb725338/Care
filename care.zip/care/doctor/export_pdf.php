<?php
session_start();
require '../db.php';
require '../vendor/autoload.php'; // Dompdf

use Dompdf\Dompdf;

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Fetch doctor's patient records
$sql = "SELECT u.name AS patient_name, u.email, r.diagnosis, r.treatment, r.created_at
        FROM patient_records r
        JOIN users u ON r.patient_id = u.id
        WHERE r.doctor_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

// Build HTML for PDF
$html = "
<h2 style='text-align:center; margin-bottom:20px;'>Patient Records</h2>
<table border='1' cellspacing='0' cellpadding='8' width='100%' style='border-collapse: collapse; font-family: Arial; font-size: 12px;'>
  <thead>
    <tr style='background:#007bff; color:white; text-align:center;'>
      <th>Patient</th>
      <th>Email</th>
      <th>Diagnosis</th>
      <th>Treatment</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>";

while ($row = $result->fetch_assoc()) {
    $html .= "<tr>
                <td>".htmlspecialchars($row['patient_name'])."</td>
                <td>".htmlspecialchars($row['email'])."</td>
                <td>".htmlspecialchars($row['diagnosis'])."</td>
                <td>".htmlspecialchars($row['treatment'])."</td>
                <td>".date("d M Y", strtotime($row['created_at']))."</td>
              </tr>";
}
$html .= "</tbody></table>";

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("patient_records.pdf", ["Attachment" => true]);
exit();
