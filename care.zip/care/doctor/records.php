<?php
session_start();
require __DIR__ . '/../db.php';

// Auth check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// Fetch doctor info
$stmt = $conn->prepare("
    SELECT d.id AS doctor_id, d.specialization, u.name, u.email, u.profile_pic
    FROM doctors d
    JOIN users u ON d.user_id = u.id
    WHERE d.user_id=? LIMIT 1
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc() ?: [];
$stmt->close();
$doc_id = $doctor['doctor_id'] ?? 0;

// Handle add new record
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_record') {
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $diagnosis = trim($_POST['diagnosis'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $visit_date = $_POST['visit_date'] ?? date('Y-m-d H:i:s');

    $ins = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, diagnosis, prescription, notes, visit_date) VALUES (?, ?, ?, ?, ?, ?)");
    $ins->bind_param('iissss', $patient_id, $doc_id, $diagnosis, $prescription, $notes, $visit_date);
    if ($ins->execute()) {
        $msg = 'New record added successfully.';
    } else {
        $msg = 'Insert failed: ' . $ins->error;
    }
    $ins->close();
}

// Handle record update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_record') {
    $rec_id = (int)($_POST['record_id'] ?? 0);
    $diagnosis = trim($_POST['diagnosis'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    $upd = $conn->prepare("UPDATE medical_records SET diagnosis=?, prescription=?, notes=? WHERE id=? AND doctor_id=?");
    $upd->bind_param('sssii', $diagnosis, $prescription, $notes, $rec_id, $doc_id);
    if ($upd->execute()) {
        $msg = 'Record updated successfully.';
    } else {
        $msg = 'Update failed: ' . $upd->error;
    }
    $upd->close();
}

// Fetch patient records
$records = [];
if ($doc_id) {
    $sql = "
        SELECT mr.id, mr.patient_id, mr.diagnosis, mr.prescription, mr.visit_date, mr.notes,
               u.name AS patient_name, u.email AS patient_email
        FROM medical_records mr
        JOIN patients p ON mr.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE mr.doctor_id=?
        ORDER BY mr.visit_date DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $doc_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $records = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// Fetch patients for Add modal dropdown
$patients = [];
$r = $conn->query("SELECT p.id, u.name FROM patients p JOIN users u ON p.user_id = u.id ORDER BY u.name ASC");
while ($row = $r->fetch_assoc()) {
    $patients[] = $row;
}

// Profile picture
$profilePic = !empty($doctor['profile_pic']) ? $doctor['profile_pic'] : '../assets/default-avatar.png';
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Patient Records — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand-dark:#059669;--ink:#1e293b;--surface:#fff;--radius-lg:14px;--shadow:0 2px 12px rgba(0,0,0,0.08);}
body{background:#f9fafb;font-family:'Segoe UI',sans-serif;color:var(--ink);}
.sidebar{min-height:100vh;padding:1.25rem;background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a{color:var(--brand); display:block; padding:0.5rem 0.25rem; border-radius:8px; font-weight:500;}
.sidebar a:hover{background:rgba(16,185,129,0.08); text-decoration:none;}
.sidebar a.active{background:rgba(16,185,129,0.15); font-weight:600;}
.profile-pic-lg{width:120px;height:120px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);}
.card-quiet{border-radius:var(--radius-lg);padding:1.25rem;background:var(--surface);box-shadow:var(--shadow);}
textarea.form-control{resize:vertical;}
footer.site-footer{background:#f8f9fa;padding:1.25rem;margin-top:2rem;border-top:1px solid rgba(2,8,23,0.08);font-size:0.9rem;}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm">
<div class="container-fluid">
<a class="navbar-brand d-flex align-items-center" href="doctor_dashboard.php">
<i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i>
<span style="color:var(--ink)">CARE</span></a>
<div class="d-flex align-items-center ms-auto gap-3">
<div class="dropdown">
<a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
<img src="<?= $profilePic ?>" alt="avatar" class="avatar-sm me-2" style="width:44px;height:44px;border-radius:50%;object-fit:cover;">
<strong class="d-none d-md-inline"><?= htmlspecialchars($doctor['name'] ?? 'Doctor') ?></strong>
</a>
<ul class="dropdown-menu dropdown-menu-end">
<li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
<li><hr class="dropdown-divider"></li>
<li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
</ul>
</div>
</div>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<!-- Sidebar -->
<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?= $profilePic ?>" class="profile-pic-lg mb-2" alt="profile">
<h5><?= htmlspecialchars($doctor['name'] ?? 'Doctor') ?></h5>
<div class="text-muted mb-3"><?= htmlspecialchars($doctor['specialization'] ?? '') ?></div>
<nav>
<a href="doctor_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="availability.php" class="mb-2 d-block"><i class="bi bi-calendar-range me-2"></i>Availability</a>
<a href="records.php" class="mb-2 d-block active"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="messages.php" class="mb-2 d-block"><i class="bi bi-chat-left-text me-2"></i>Messages</a>
<a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 p-4">
<div class="d-flex justify-content-between align-items-center mb-3">
<h2>Patient Records</h2>
<button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addModal">+ Add New Record</button>
</div>

<?php if($msg): ?>
<div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="table-responsive card-quiet">
<table class="table align-middle">
<thead>
<tr>
<th>Patient</th>
<th>Date</th>
<th>Diagnosis</th>
<th>Prescription</th>
<th>Notes</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php if(empty($records)): ?>
<tr><td colspan="6" class="text-center text-muted">No records found.</td></tr>
<?php else: foreach($records as $rec): ?>
<tr>
<td><?= htmlspecialchars($rec['patient_name'] ?? '-') ?></td>
<td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($rec['visit_date']))) ?></td>
<td><?= htmlspecialchars($rec['diagnosis'] ?? '-') ?></td>
<td><?= htmlspecialchars($rec['prescription'] ?? '-') ?></td>
<td><?= htmlspecialchars($rec['notes'] ?? '-') ?></td>
<td>
<button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $rec['id'] ?>">Edit</button>
</td>
</tr>

<!-- Edit Modal -->
<div class="modal fade" id="editModal<?= $rec['id'] ?>" tabindex="-1">
<div class="modal-dialog">
<form class="modal-content" method="post">
<div class="modal-header"><h5>Edit Record</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<input type="hidden" name="action" value="update_record">
<input type="hidden" name="record_id" value="<?= $rec['id'] ?>">
<div class="mb-2"><label>Diagnosis</label><textarea class="form-control" name="diagnosis"><?= htmlspecialchars($rec['diagnosis']) ?></textarea></div>
<div class="mb-2"><label>Prescription</label><textarea class="form-control" name="prescription"><?= htmlspecialchars($rec['prescription']) ?></textarea></div>
<div class="mb-2"><label>Notes</label><textarea class="form-control" name="notes"><?= htmlspecialchars($rec['notes']) ?></textarea></div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-primary">Save</button>
</div>
</form>
</div>
</div>

<?php endforeach; endif; ?>
</tbody>
</table>
</div>

<!-- Add New Record Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
<div class="modal-dialog">
<form class="modal-content" method="post">
<div class="modal-header"><h5>Add New Record</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<input type="hidden" name="action" value="add_record">
<div class="mb-2">
<label>Patient</label>
<select name="patient_id" class="form-select" required>
<option value="">Select patient</option>
<?php foreach($patients as $p): ?>
<option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
<?php endforeach; ?>
</select>
</div>
<div class="mb-2"><label>Visit Date</label><input type="datetime-local" name="visit_date" class="form-control" value="<?= date('Y-m-d\TH:i') ?>" required></div>
<div class="mb-2"><label>Diagnosis</label><textarea name="diagnosis" class="form-control"></textarea></div>
<div class="mb-2"><label>Prescription</label><textarea name="prescription" class="form-control"></textarea></div>
<div class="mb-2"><label>Notes</label><textarea name="notes" class="form-control"></textarea></div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Add Record</button>
</div>
</form>
</div>
</div>

<footer class="site-footer">
<div class="d-flex justify-content-between">
<div>&copy; <?= date('Y') ?> CARE</div>
<div><a href="doctor_dashboard.php">Dashboard</a> · <a href="appointments.php">Appointments</a> · <a href="availability.php">Availability</a></div>
</div>
</footer>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
