<?php
session_start();

if (isset($_POST['confirm_logout'])) {
    // If user clicked "Yes, Logout"
    session_unset();
    session_destroy();
    header("Location: /care/index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout Confirmation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- ✅ Bootstrap Icons must be in the head -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #f8f9fa, #e9ecef);
      min-height: 100vh;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .logout-card {
      max-width: 420px;
      border-radius: 1rem;
      padding: 2rem;
      background: #fff;
    }
    .logout-icon {
      font-size: 3rem;
      color: #dc3545;
    }
  </style>
</head>
<body>

  <div class="card logout-card shadow text-center">
    <div class="logout-icon mb-3">
      <i class="bi bi-box-arrow-right"></i>
    </div>
    <h4 class="mb-3 fw-bold">Confirm Logout</h4>
    <p class="text-muted mb-4">Are you sure you want to log out of your account?</p>
    
    <form method="POST" class="d-flex flex-column flex-sm-row gap-2 justify-content-center">
      <button type="submit" name="confirm_logout" class="btn btn-danger px-4">Yes, Logout</button>
      <a href="javascript:history.back()" class="btn btn-outline-secondary px-4">Cancel</a>
    </form>
  </div>

</body>
</html>
