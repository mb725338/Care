Standalone Doctor Panel
Files:
- doctor_dashboard.php
- profile.php
- availability.php
- appointments.php
- records.php
- logout.php
- assets/style2.css

Notes:
- Each file is standalone and contains DB credentials at the top. Edit if needed.
- Session requirements:
    $_SESSION['user_id'] = users.id
    $_SESSION['role'] = 'doctor'
- doctor_availability.doctor_id uses users.id per DB dump; appointments.doctor_id uses doctors.id.
- For production, abstract DB credentials and add CSRF/security.

Place this folder in your webserver (e.g., htdocs/doctor/) and access doctor_dashboard.php after logging in as a doctor.
