<?php
session_start();
require __DIR__ . '/../db.php';

// ---------------------
// Auth check (doctor)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ---------------------
// Fetch doctor info
// ---------------------
$stmt = $conn->prepare("
    SELECT d.id AS doctor_id, d.specialization, u.name, u.profile_pic
    FROM doctors d
    JOIN users u ON d.user_id = u.id
    WHERE d.user_id=? LIMIT 1
");
if (!$stmt) die("DB error: " . $conn->error);
$stmt->bind_param('i', $uid);
$stmt->execute();
$doctor = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();

$doc_id = $doctor['doctor_id'] ?? 0;
$profilePic = !empty($doctor['profile_pic']) ? $doctor['profile_pic'] : '../assets/default-avatar.png';

// ---------------------
// Handle add/edit/delete
// ---------------------
$action_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['action'])) {
    $day = $_POST['day'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';
    $slot_id = $_POST['slot_id'] ?? null;

    if ($_POST['action'] === 'add') {
        $stmt = $conn->prepare("INSERT INTO doctor_availability (doctor_id, day, start_time, end_time) VALUES (?,?,?,?)");
        if ($stmt) {
            $stmt->bind_param('isss', $doc_id, $day, $start_time, $end_time);
            if ($stmt->execute()) {
                $action_msg = 'Slot added successfully.';
            } else {
                $action_msg = 'Add failed: ' . $stmt->error;
            }
            $stmt->close();
        }
    } elseif ($_POST['action'] === 'edit' && $slot_id) {
        $stmt = $conn->prepare("UPDATE doctor_availability SET day=?, start_time=?, end_time=? WHERE id=? AND doctor_id=?");
        if ($stmt) {
            $stmt->bind_param('sssii', $day, $start_time, $end_time, $slot_id, $doc_id);
            if ($stmt->execute()) {
                $action_msg = 'Slot updated successfully.';
            } else {
                $action_msg = 'Update failed: ' . $stmt->error;
            }
            $stmt->close();
        }
    } elseif ($_POST['action'] === 'delete' && $slot_id) {
        $stmt = $conn->prepare("DELETE FROM doctor_availability WHERE id=? AND doctor_id=?");
        if ($stmt) {
            $stmt->bind_param('ii', $slot_id, $doc_id);
            if ($stmt->execute()) {
                $action_msg = 'Slot deleted successfully.';
            } else {
                $action_msg = 'Delete failed: ' . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// ---------------------
// Fetch slots
// ---------------------
$slots = [];
if ($doc_id) {
    $stmt = $conn->prepare("SELECT * FROM doctor_availability WHERE doctor_id=? ORDER BY FIELD(day,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), start_time");
    $stmt->bind_param('i', $doc_id);
    $stmt->execute();
    $slots = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Manage Availability — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--brand:#10b981; --brand-dark:#059669; --ink:#1e293b; --surface:#fff; --radius-lg:14px; --shadow:0 2px 12px rgba(0,0,0,0.08);}
body{background:#f9fafb; font-family: 'Segoe UI',sans-serif; color:var(--ink);}
.sidebar{min-height:100vh; padding:1.25rem; background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a{color:var(--brand); display:block; padding:0.5rem 0.25rem; border-radius:8px; font-weight:500;}
.sidebar a:hover{background:rgba(16,185,129,0.15); text-decoration:none; color:var(--brand-dark);}
.profile-pic-lg{width:120px; height:120px; border-radius:50%; object-fit:cover; border:6px solid var(--brand); box-shadow:var(--shadow);}
.card-quiet{border-radius:var(--radius-lg); padding:1.25rem; background:var(--surface); box-shadow:var(--shadow);}
.btn-primary{background:var(--brand); border:none;}
.btn-primary:hover{background:var(--brand-dark);}
.btn-success{background:#16a34a; border:none;}
.btn-success:hover{background:#15803d;}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
<div class="container-fluid">
<a class="navbar-brand d-flex align-items-center" href="doctor_dashboard.php">
<i class="bi bi-heart-pulse-fill me-2" style="color:var(--brand)"></i>
<span style="color:var(--ink)">CARE</span>
</a>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?= $profilePic ?>" class="profile-pic-lg mb-3" alt="profile">
<h5><?= htmlspecialchars($doctor['name'] ?? 'Doctor') ?></h5>
<div class="text-muted mb-3"><?= htmlspecialchars($doctor['specialization'] ?? '') ?></div>
<nav class="text-start">
<a href="doctor_dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="availability.php"><i class="bi bi-calendar-range me-2"></i>Availability</a>
<a href="records.php"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="messages.php"><i class="bi bi-chat-left-text me-2"></i>Messages</a>
<a href="../logout.php" class="text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 p-4">
<h2>Manage Availability</h2>
<?php if($action_msg): ?>
<div class="alert alert-success"><?= htmlspecialchars($action_msg) ?></div>
<?php endif; ?>

<button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addModal">
<i class="bi bi-plus-circle"></i> Add Slot
</button>

<table class="table table-bordered table-striped">
<thead>
<tr><th>Day</th><th>Start</th><th>End</th><th>Actions</th></tr>
</thead>
<tbody>
<?php if(empty($slots)): ?>
<tr><td colspan="4" class="text-center">No availability slots found.</td></tr>
<?php else: foreach($slots as $s): ?>
<tr>
<td><?= htmlspecialchars($s['day']) ?></td>
<td><?= htmlspecialchars($s['start_time']) ?></td>
<td><?= htmlspecialchars($s['end_time']) ?></td>
<td>
<button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editModal<?= $s['id'] ?>"><i class="bi bi-pencil"></i></button>
<form method="post" style="display:inline">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="slot_id" value="<?= $s['id'] ?>">
<button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
</form>
</td>
</tr>

<!-- Edit Modal -->
<div class="modal fade" id="editModal<?= $s['id'] ?>" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-sm">
<form class="modal-content" method="post">
<div class="modal-header"><h5>Edit Slot</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<input type="hidden" name="action" value="edit">
<input type="hidden" name="slot_id" value="<?= $s['id'] ?>">
<div class="mb-2">
<label>Day</label>
<select class="form-control" name="day" required>
<option <?= $s['day']=='Monday'?'selected':'' ?>>Monday</option>
<option <?= $s['day']=='Tuesday'?'selected':'' ?>>Tuesday</option>
<option <?= $s['day']=='Wednesday'?'selected':'' ?>>Wednesday</option>
<option <?= $s['day']=='Thursday'?'selected':'' ?>>Thursday</option>
<option <?= $s['day']=='Friday'?'selected':'' ?>>Friday</option>
<option <?= $s['day']=='Saturday'?'selected':'' ?>>Saturday</option>
<option <?= $s['day']=='Sunday'?'selected':'' ?>>Sunday</option>
</select>
</div>
<div class="mb-2"><label>Start Time</label><input type="time" class="form-control" name="start_time" value="<?= $s['start_time'] ?>" required></div>
<div class="mb-2"><label>End Time</label><input type="time" class="form-control" name="end_time" value="<?= $s['end_time'] ?>" required></div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>

<?php endforeach; endif; ?>
</tbody>
</table>
</main>
</div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-sm">
<form class="modal-content" method="post">
<div class="modal-header"><h5>Add Slot</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<input type="hidden" name="action" value="add">
<div class="mb-2"><label>Day</label>
<select class="form-control" name="day" required>
<option>Monday</option><option>Tuesday</option><option>Wednesday</option>
<option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option>
</select></div>
<div class="mb-2"><label>Start Time</label><input type="time" class="form-control" name="start_time" required></div>
<div class="mb-2"><label>End Time</label><input type="time" class="form-control" name="end_time" required></div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-primary">Add</button>
</div>
</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
