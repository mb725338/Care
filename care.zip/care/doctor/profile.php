<?php
session_start();
require __DIR__ . '/../db.php';

// ---------------------
// Auth check (doctor)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ---------------------
// Fetch doctor info
// ---------------------
$sql = "SELECT u.name, u.email, u.profile_pic, 
               d.id AS doctor_id, d.specialization, d.license_no, 
               d.phone, d.address, d.bio, d.fees
        FROM users u 
        JOIN doctors d ON u.id = d.user_id 
        WHERE u.id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc() ?: [];
$stmt->close();

// ---------------------
// Handle profile update (name, email, etc.)
// ---------------------
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $spec    = trim($_POST['specialization']);
    $phone   = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $bio     = trim($_POST['bio']);
    $fees    = floatval($_POST['fees'] ?? 0);

    $stmt = $conn->prepare("UPDATE users u 
                            JOIN doctors d ON u.id = d.user_id 
                            SET u.name=?, u.email=?, d.specialization=?, 
                                d.phone=?, d.address=?, d.bio=?, d.fees=? 
                            WHERE u.id=?");
    $stmt->bind_param('ssssssdi', $name, $email, $spec, $phone, $address, $bio, $fees, $uid);
    if ($stmt->execute()) {
        $msg = 'Profile updated successfully.';
        $_SESSION['name'] = $name; // update session
    } else {
        $msg = 'Update failed: ' . $stmt->error;
    }
    $stmt->close();
}

// ---------------------
// Handle profile pic AJAX upload
// ---------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_pic') {
    header('Content-Type: application/json');
    $response = ['success'=>false,'error'=>'','path'=>''];

    if (!isset($_FILES['profile_pic'])) {
        $response['error'] = 'No file uploaded.';
    } else {
        $file = $_FILES['profile_pic'];
        if ($file['error'] !== UPLOAD_ERR_OK) $response['error'] = 'Upload error code: '.$file['error'];
        elseif ($file['size'] > 2*1024*1024) $response['error'] = 'File too large. Max 2MB.';
        elseif (!@getimagesize($file['tmp_name'])) $response['error'] = 'Invalid image.';
        else {
            $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            $mime = mime_content_type($file['tmp_name']);
            if(!isset($allowed[$mime])) $response['error']='Only JPG, PNG, WEBP allowed.';
            else {
                $ext = $allowed[$mime];
                $upload_dir = __DIR__.'/../assets/uploads/';
                if(!is_dir($upload_dir)) mkdir($upload_dir,0755,true);
                $filename = 'doctor_'.$uid.'_'.uniqid().'.'.$ext;
                $dest = $upload_dir.$filename;
                if(move_uploaded_file($file['tmp_name'],$dest)){
                    $db_path = 'assets/uploads/'.$filename; // relative path
                    $upd = $conn->prepare("UPDATE users SET profile_pic=? WHERE id=?");
                    $upd->bind_param('si', $db_path, $uid);
                    if($upd->execute()){
                        $_SESSION['pic'] = $db_path; // update session for navbar/logout
                        $response['success']=true;
                        $response['path']=$db_path . '?t=' . time(); // cache busting
                    } else {
                        @unlink($dest);
                        $response['error']='DB update failed: '.$upd->error;
                    }
                } else $response['error']='Could not move file.';
            }
        }
    }
    echo json_encode($response);
    exit;
}

// ---------------------
// Profile picture display
// ---------------------
$profilePic = ($_SESSION['pic'] ?? ($doctor['profile_pic'] ?? '../assets/default-avatar.png')) . '?t=' . time();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Doctor Profile — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root {--brand:#10b981; --brand-dark:#059669; --ink:#1e293b; --surface:#fff; --radius-lg:14px; --shadow:0 2px 12px rgba(0,0,0,0.08);}
body{background:#f9fafb;font-family:'Segoe UI',sans-serif;color:var(--ink);}
.sidebar{min-height:100vh;padding:1.25rem;background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a{color:var(--ink);display:block;padding:0.5rem 0.25rem;border-radius:8px;font-weight:500;}
.sidebar a:hover{background:rgba(16,185,129,0.08);color:var(--brand-dark);text-decoration:none;}
.avatar-sm{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid #fff;box-shadow:var(--shadow);}
.profile-pic-lg{width:120px;height:120px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);}
.card-quiet{border-radius:var(--radius-lg);padding:1.25rem;background:var(--surface);box-shadow:var(--shadow);}
.navbar .navbar-brand, .navbar .nav-link, .navbar i{color:var(--brand)!important;}
.btn-primary{background:var(--brand);border:none;}
.btn-primary:hover{background:var(--brand-dark);}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm">
<div class="container-fluid">
<a class="navbar-brand d-flex align-items-center" href="doctor_dashboard.php">
<i class="bi bi-heart-pulse-fill me-2"></i><span style="color:var(--ink)">CARE</span></a>
<div class="d-flex align-items-center ms-auto gap-3">
<div class="dropdown">
<a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
<img src="<?php echo $profilePic; ?>" alt="avatar" class="avatar-sm me-2">
<strong class="d-none d-md-inline"><?php echo htmlspecialchars($doctor['name']??'Doctor'); ?></strong>
</a>
<ul class="dropdown-menu dropdown-menu-end">
<li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
<li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
</ul>
</div>
</div>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<!-- Sidebar -->
<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?php echo $profilePic; ?>" class="profile-pic-lg mb-3">
<h4><?php echo htmlspecialchars($doctor['name']??'Doctor'); ?></h4>
<div class="text-muted"><?php echo htmlspecialchars($doctor['specialization']??''); ?></div>
<nav class="text-start mt-4">
<a href="doctor_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="patients.php" class="mb-2 d-block"><i class="bi bi-people me-2"></i>Patients</a>
<a href="availability.php" class="mb-2 d-block"><i class="bi bi-calendar-range me-2"></i>Availability</a>
<a href="records.php" class="mb-2 d-block"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="messages.php" class="mb-2 d-block"><i class="bi bi-chat-left-text me-2"></i>Messages</a>
<a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<!-- Main -->
<main class="col-12 col-md-8 col-lg-9 p-4">
<h2 class="mb-3">Edit Profile</h2>
<?php if($msg): ?><div class="alert alert-info"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

<div class="card-quiet text-center mb-4">
    <img id="profile-preview" src="<?php echo $profilePic; ?>" class="profile-pic-lg mb-2">
    <input type="file" id="profile_pic" class="form-control mt-2" accept="image/*">
    <button id="uploadBtn" class="btn btn-sm btn-primary mt-2">Upload Picture</button>
</div>

<div class="card-quiet">
<form method="POST" class="row g-3">
  <div class="col-md-6"><label class="form-label">Name</label>
    <input name="name" value="<?php echo htmlspecialchars($doctor['name']); ?>" class="form-control" required></div>
  <div class="col-md-6"><label class="form-label">Email</label>
    <input name="email" value="<?php echo htmlspecialchars($doctor['email']); ?>" class="form-control" required></div>
  <div class="col-md-4"><label class="form-label">Specialization</label>
    <input name="specialization" value="<?php echo htmlspecialchars($doctor['specialization']); ?>" class="form-control"></div>
  <div class="col-md-4"><label class="form-label">Phone</label>
    <input name="phone" value="<?php echo htmlspecialchars($doctor['phone']); ?>" class="form-control"></div>
  <div class="col-md-4"><label class="form-label">License No</label>
    <input name="license_no" value="<?php echo htmlspecialchars($doctor['license_no']); ?>" class="form-control" readonly></div>
  <div class="col-12"><label class="form-label">Address</label>
    <textarea name="address" class="form-control"><?php echo htmlspecialchars($doctor['address']); ?></textarea></div>
  <div class="col-md-4"><label class="form-label">Consultation Fees (PKR)</label>
    <input type="number" step="0.01" name="fees" value="<?php echo htmlspecialchars($doctor['fees'] ?? '0.00'); ?>" class="form-control"></div>
  <div class="col-12"><label class="form-label">Bio</label>
    <textarea name="bio" class="form-control"><?php echo htmlspecialchars($doctor['bio']); ?></textarea></div>
  <div class="col-12">
    <button name="save" class="btn btn-primary">Save Changes</button>
  </div>
</form>
</div>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// AJAX profile picture upload with cache-busting
document.getElementById('uploadBtn').addEventListener('click', function(e){
    e.preventDefault();
    var fileInput = document.getElementById('profile_pic');
    if(fileInput.files.length===0){ alert('Select a file'); return; }
    var formData = new FormData();
    formData.append('profile_pic', fileInput.files[0]);
    formData.append('action','upload_pic');

    fetch('profile.php',{method:'POST', body: formData})
    .then(res=>res.json())
    .then(data=>{
       if(data.success){ 
            // Cache-busting by adding a timestamp query
            var newSrc = data.path + '?t=' + new Date().getTime();

            // Update main profile pic
            document.getElementById('profile-preview').src = newSrc;

            // Update all navbar images
            document.querySelectorAll('.avatar-sm').forEach(img=>{
                img.src = newSrc;
            });

            alert('Profile picture updated!');
       } else {
            alert(data.error);
       }
    })
    .catch(err=>alert('Upload failed'));
});

</script>
</body>
</html>
