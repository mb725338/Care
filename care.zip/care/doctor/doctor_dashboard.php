<?php
session_start();
require __DIR__ . '/../db.php';

// ---------------------
// Auth check (doctor)
// ---------------------
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'doctor') {
    header('Location: ../login.php');
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ---------------------
// Handle profile picture upload (AJAX)
// ---------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_pic') {
    header('Content-Type: application/json');
    $response = ['success'=>false,'error'=>'','path'=>''];

    if (!isset($_FILES['profile_pic'])) {
        $response['error'] = 'No file uploaded.';
    } else {
        $file = $_FILES['profile_pic'];
        if ($file['error'] !== UPLOAD_ERR_OK) $response['error'] = 'Upload error code: ' . $file['error'];
        elseif ($file['size'] > 2*1024*1024) $response['error'] = 'File too large. Max 2MB.';
        elseif (!@getimagesize($file['tmp_name'])) $response['error'] = 'Not a valid image.';
        else {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!array_key_exists($mime,$allowed)) $response['error']='Only JPG/PNG/WEBP allowed.';
            else {
                $ext = $allowed[$mime];
                $upload_dir = __DIR__ . '/../assets/uploads/';
                if(!is_dir($upload_dir)) mkdir($upload_dir,0755,true);
                $filename = 'doctor_'.$uid.'_'.uniqid().'.'.$ext;
                $dest = $upload_dir.$filename;
                if(!move_uploaded_file($file['tmp_name'],$dest)) $response['error']='Could not move file.';
                else {
                    $db_path = '../assets/uploads/'.$filename;
                    $upd = $conn->prepare("UPDATE users SET profile_pic=? WHERE id=?");
                    if(!$upd) { @unlink($dest); $response['error']='DB prepare error: '.$conn->error; }
                    else {
                        $upd->bind_param('si',$db_path,$uid);
                        if($upd->execute()){
                            $_SESSION['pic'] = $db_path; // update session for future use
                            $response['success']=true;
                            $response['path']=$db_path;
                        } else { @unlink($dest); $response['error']='DB update failed: '.$upd->error; }
                        $upd->close();
                    }
                }
            }
        }
    }
    echo json_encode($response);
    exit;
}

// ---------------------
// Fetch doctor info
// ---------------------
$stmt = $conn->prepare("
    SELECT d.id AS doctor_id, d.specialization, d.phone, d.address, d.bio,
           u.id AS uid, u.name, u.email, u.profile_pic
    FROM doctors d
    JOIN users u ON d.user_id=u.id
    WHERE d.user_id=? LIMIT 1
");
$stmt->bind_param('i',$uid);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc() ?: [];
$stmt->close();

// ---------------------
// Stats
// ---------------------
$doc_id = $doctor['doctor_id'] ?? 0;
$totalAppointments = $upcoming = $patientsSeen = 0;

if($doc_id){
    $r=$conn->query("SELECT COUNT(*) AS c FROM appointments WHERE doctor_id={$doc_id}");
    $totalAppointments=(int)($r->fetch_assoc()['c']??0);

    $r2=$conn->query("SELECT * FROM appointments WHERE doctor_id={$doc_id} AND appointment_date>=NOW() ORDER BY appointment_date ASC LIMIT 1");
    $upcoming=$r2->fetch_assoc();

    $r3=$conn->query("SELECT COUNT(DISTINCT patient_id) AS c FROM appointments WHERE doctor_id={$doc_id} AND status='completed'");
    $patientsSeen=(int)($r3->fetch_assoc()['c']??0);
}

// ---------------------
// Unread messages
// ---------------------
$msgCount = 0;
$q = $conn->prepare("SELECT COUNT(*) AS c FROM messages WHERE doctor_id=? AND status='unread'");
if($q){
    $q->bind_param('i',$doc_id);
    $q->execute();
    $r=$q->get_result()->fetch_assoc();
    $msgCount=(int)($r['c']??0);
    $q->close();
}

// ---------------------
// Profile pic
// ---------------------
$profilePic = $_SESSION['pic'] ?? (!empty($doctor['profile_pic']) ? $doctor['profile_pic'] : '../assets/default-avatar.png');
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Doctor Dashboard — CARE</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root {--brand:#10b981; --brand-dark:#059669; --ink:#1e293b; --surface:#fff; --radius-lg:14px; --shadow:0 2px 12px rgba(0,0,0,0.08);}
body{background:#f9fafb;font-family:'Segoe UI',sans-serif;color:var(--ink);}
.sidebar{min-height:100vh;padding:1.25rem;background:linear-gradient(180deg, rgba(16,185,129,0.08), rgba(14,165,233,0.03));}
.sidebar a{color:var(--ink);display:block;padding:0.5rem 0.25rem;border-radius:8px;font-weight:500;}
.sidebar a:hover{background:rgba(16,185,129,0.08);color:var(--brand-dark);text-decoration:none;}
.avatar-sm{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid #fff;box-shadow:var(--shadow);}
.profile-pic-lg{width:120px;height:120px;border-radius:50%;object-fit:cover;border:6px solid var(--brand);box-shadow:var(--shadow);}
.card-quiet{border-radius:var(--radius-lg);padding:1.25rem;background:var(--surface);box-shadow:var(--shadow);transition:all .3s ease;height:100%;display:flex;flex-direction:column;justify-content:space-between;}
.card-quiet:hover{transform:translateY(-3px);box-shadow:0 4px 18px rgba(0,0,0,0.12);}
.navbar .navbar-brand, .navbar .nav-link, .navbar i{color:var(--brand)!important;}
.navbar .nav-link:hover, .navbar .dropdown-item:hover{color:var(--brand-dark)!important;}
.navbar-brand span{font-weight:800;font-size:1.25rem;}
.btn-primary{background:var(--brand);border:none;}
.btn-primary:hover{background:var(--brand-dark);}
.btn-outline-primary{border-color:var(--brand);color:var(--brand);}
.btn-outline-primary:hover{background:var(--brand);color:#fff;}
footer.site-footer{background:#f8f9fa;padding:1.25rem;margin-top:2rem;border-top:1px solid rgba(2,8,23,0.08);font-size:0.9rem;}
footer.site-footer a{text-decoration:none;color:#6c757d;margin:0 0.5rem;}
footer.site-footer a:hover{color:var(--brand-dark);}
.modal-content.glass{border-radius:var(--radius-lg);backdrop-filter:blur(8px);box-shadow:var(--shadow);}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm">
<div class="container-fluid">
<a class="navbar-brand d-flex align-items-center" href="doctor_dashboard.php">
<i class="bi bi-heart-pulse-fill me-2"></i><span style="color:var(--ink)">CARE</span></a>
<div class="d-flex align-items-center ms-auto gap-3">
<a href="messages.php" class="position-relative me-2">
<i class="bi bi-chat-dots" style="font-size:1.25rem;"></i>
<?php if($msgCount>0) echo "<span class='badge rounded-pill bg-danger position-absolute' style='transform:translate(6px,-10px);'>$msgCount</span>"; ?>
</a>
<div class="dropdown">
<a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
<img src="<?php echo $profilePic; ?>" alt="avatar" class="avatar-sm profile-img">
<strong class="d-none d-md-inline"><?php echo htmlspecialchars($doctor['name']??'Doctor'); ?></strong>
</a>
<ul class="dropdown-menu dropdown-menu-end">
<li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
<li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#uploadModal"><i class="bi bi-image me-2"></i>Change avatar</a></li>
<li><hr class="dropdown-divider"></li>
<li><a class="dropdown-item text-danger" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
</ul>
</div>
</div>
</div>
</nav>

<div class="container-fluid">
<div class="row g-0">
<aside class="col-12 col-md-4 col-lg-3 sidebar text-center">
<img src="<?php echo $profilePic; ?>" class="profile-pic-lg profile-img mb-3">
<h4><?php echo htmlspecialchars($doctor['name']??'Doctor'); ?></h4>
<div class="text-muted"><?php echo htmlspecialchars($doctor['specialization']??''); ?></div>
<div class="mt-2 mb-4">
<a href="profile.php" class="btn btn-outline-primary btn-sm me-1">Edit Profile</a>
<a href="#" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">Change Photo</a>
</div>
<nav class="text-start">
<a href="doctor_dashboard.php" class="mb-2 d-block"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
<a href="appointments.php" class="mb-2 d-block"><i class="bi bi-calendar-check me-2"></i>Appointments</a>
<a href="patients.php" class="mb-2 d-block"><i class="bi bi-people me-2"></i>Patients</a>
<a href="availability.php" class="mb-2 d-block"><i class="bi bi-calendar-range me-2"></i>Availability</a>
<a href="records.php" class="mb-2 d-block"><i class="bi bi-folder2-open me-2"></i>Patient Records</a>
<a href="messages.php" class="mb-2 d-block"><i class="bi bi-chat-left-text me-2"></i>Messages</a>
<a href="../logout.php" class="mb-2 d-block text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
</nav>
</aside>

<main class="col-12 col-md-8 col-lg-9 p-4">
<h2 class="mb-2">Welcome back, Dr. <?php echo htmlspecialchars($doctor['name']??'Doctor'); ?> 👋</h2>
<p class="sub mb-4">Manage appointments, availability and patient records.</p>

<div class="row g-4">
<!-- Your cards for stats -->
<div class="col-md-6 col-lg-4"><div class="card-quiet text-center"><h3><?php echo $totalAppointments; ?></h3><div class="text-muted">Total Appointments</div></div></div>
<div class="col-md-6 col-lg-4"><div class="card-quiet text-center"><h5><?php echo $upcoming?date('M d, Y H:i',strtotime($upcoming['appointment_date'])):'No upcoming'; ?></h5><div class="text-muted">Next Appointment</div></div></div>
<div class="col-md-6 col-lg-4"><div class="card-quiet text-center"><h3><?php echo $patientsSeen; ?></h3><div class="text-muted">Patients Seen</div></div></div>
</div>

<footer class="site-footer mt-4">
<div class="container d-flex justify-content-between align-items-center">
<div>&copy; <?php echo date('Y'); ?> CARE</div>
<div>
<a href="profile.php">Profile</a>
<a href="appointments.php">Appointments</a>
<a href="records.php">Records</a>
</div>
</div>
</footer>
</main>
</div>
</div>

<!-- Change Profile Photo Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <form id="uploadForm" class="modal-content glass" enctype="multipart/form-data" method="POST">
      <div class="modal-header">
        <h5 class="modal-title">Change Profile Photo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="action" value="upload_pic">
        <div class="mb-3">
          <label class="form-label">Choose image (JPG/PNG/WEBP, max 2MB)</label>
          <input required class="form-control" type="file" name="profile_pic" accept="image/*">
        </div>
        <div id="uploadMsg" class="small text-danger"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// AJAX upload for profile picture
document.getElementById('uploadForm').addEventListener('submit', function(e){
    e.preventDefault();
    let formData = new FormData(this);
    let msgDiv = document.getElementById('uploadMsg');

    fetch('doctor_dashboard.php', { // self-submit
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            // update all profile pics dynamically
            document.querySelectorAll('.profile-img').forEach(img=>{
                img.src = data.path + '?t=' + new Date().getTime();
            });
            msgDiv.classList.remove('text-danger'); 
            msgDiv.classList.add('text-success');
            msgDiv.textContent = 'Profile picture updated!';
            setTimeout(()=>{
                bootstrap.Modal.getInstance(document.getElementById('uploadModal')).hide();
                msgDiv.textContent = '';
            }, 1500);
        } else {
            msgDiv.classList.remove('text-success'); 
            msgDiv.classList.add('text-danger'); 
            msgDiv.textContent = data.error;
        }
    })
    .catch(err => { msgDiv.textContent = 'Upload failed.'; console.error(err); });
});
</script>
</body>
</html>
