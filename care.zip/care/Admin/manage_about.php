<?php
session_start();
require 'db.php';

// Security: only admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$msg = "";

// Get admin info
$user_id = $_SESSION['user_id'];
$adminRes = $conn->query("SELECT name, profile_pic FROM users WHERE id=$user_id");
if($adminRes && $adminRes->num_rows > 0){
    $adminRow = $adminRes->fetch_assoc();
    $pname = $adminRow['name'];
    $pic = $adminRow['profile_pic'] ?: 'default.png';
} else {
    $pname = "Admin";
    $pic = "default.png";
}

$current_page = basename($_SERVER['PHP_SELF']);

// ================== HANDLE CRUD FOR EACH SECTION ==================
// WHO WE ARE
if (isset($_POST['add_who'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("INSERT INTO who_we_are (title, description, icon) VALUES ('$title','$description','$icon')");
    $msg = "Who We Are item added!";
}
if (isset($_POST['edit_who'])) {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("UPDATE who_we_are SET title='$title', description='$description', icon='$icon' WHERE id=$id");
    $msg = "Who We Are item updated!";
}
if (isset($_GET['delete_who'])) {
    $id = intval($_GET['delete_who']);
    $conn->query("DELETE FROM who_we_are WHERE id=$id");
    $msg = "Who We Are item deleted!";
}
$whoRes = $conn->query("SELECT * FROM who_we_are");

// MISSION & VISION
if (isset($_POST['add_mv'])) {
    $type = $conn->real_escape_string($_POST['type']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("INSERT INTO mission_vision (type,title,description,icon) VALUES ('$type','$title','$description','$icon')");
    $msg = "Mission/Vision item added!";
}
if (isset($_POST['edit_mv'])) {
    $id = intval($_POST['id']);
    $type = $conn->real_escape_string($_POST['type']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("UPDATE mission_vision SET type='$type', title='$title', description='$description', icon='$icon' WHERE id=$id");
    $msg = "Mission/Vision item updated!";
}
if (isset($_GET['delete_mv'])) {
    $id = intval($_GET['delete_mv']);
    $conn->query("DELETE FROM mission_vision WHERE id=$id");
    $msg = "Mission/Vision item deleted!";
}
$mvRes = $conn->query("SELECT * FROM mission_vision");

// VALUES
if (isset($_POST['add_value'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("INSERT INTO values_section (title,description,icon) VALUES ('$title','$description','$icon')");
    $msg = "Value added!";
}
if (isset($_POST['edit_value'])) {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $icon = $conn->real_escape_string($_POST['icon']);
    $conn->query("UPDATE values_section SET title='$title', description='$description', icon='$icon' WHERE id=$id");
    $msg = "Value updated!";
}
if (isset($_GET['delete_value'])) {
    $id = intval($_GET['delete_value']);
    $conn->query("DELETE FROM values_section WHERE id=$id");
    $msg = "Value deleted!";
}
$valuesRes = $conn->query("SELECT * FROM values_section");

// JOURNEY
if (isset($_POST['add_journey'])) {
    $year = $conn->real_escape_string($_POST['year']);
    $description = $conn->real_escape_string($_POST['description']);
    $conn->query("INSERT INTO journey (year,description) VALUES ('$year','$description')");
    $msg = "Journey added!";
}
if (isset($_POST['edit_journey'])) {
    $id = intval($_POST['id']);
    $year = $conn->real_escape_string($_POST['year']);
    $description = $conn->real_escape_string($_POST['description']);
    $conn->query("UPDATE journey SET year='$year', description='$description' WHERE id=$id");
    $msg = "Journey updated!";
}
if (isset($_GET['delete_journey'])) {
    $id = intval($_GET['delete_journey']);
    $conn->query("DELETE FROM journey WHERE id=$id");
    $msg = "Journey deleted!";
}
$journeyRes = $conn->query("SELECT * FROM journey ORDER BY year ASC");

// STATS
if (isset($_POST['add_stat'])) {
    $label = $conn->real_escape_string($_POST['label']);
    $value = $conn->real_escape_string($_POST['value']);
    $conn->query("INSERT INTO stats (label,value) VALUES ('$label','$value')");
    $msg = "Stat added!";
}
if (isset($_POST['edit_stat'])) {
    $id = intval($_POST['id']);
    $label = $conn->real_escape_string($_POST['label']);
    $value = $conn->real_escape_string($_POST['value']);
    $conn->query("UPDATE stats SET label='$label', value='$value' WHERE id=$id");
    $msg = "Stat updated!";
}
if (isset($_GET['delete_stat'])) {
    $id = intval($_GET['delete_stat']);
    $conn->query("DELETE FROM stats WHERE id=$id");
    $msg = "Stat deleted!";
}
$statsRes = $conn->query("SELECT * FROM stats");

// LEADERSHIP
if (isset($_POST['add_leader'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $role = $conn->real_escape_string($_POST['role']);
    $description = $conn->real_escape_string($_POST['description']);
    $image = $conn->real_escape_string($_POST['image']);
    $conn->query("INSERT INTO leadership (name,role,description,image) VALUES ('$name','$role','$description','$image')");
    $msg = "Leader added!";
}
if (isset($_POST['edit_leader'])) {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $role = $conn->real_escape_string($_POST['role']);
    $description = $conn->real_escape_string($_POST['description']);
    $image = $conn->real_escape_string($_POST['image']);
    $conn->query("UPDATE leadership SET name='$name', role='$role', description='$description', image='$image' WHERE id=$id");
    $msg = "Leader updated!";
}
if (isset($_GET['delete_leader'])) {
    $id = intval($_GET['delete_leader']);
    $conn->query("DELETE FROM leadership WHERE id=$id");
    $msg = "Leader deleted!";
}
$leaderRes = $conn->query("SELECT * FROM leadership");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage About Us | CARE Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06);}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);background:transparent;}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06);}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:28px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;margin-bottom:20px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;}
.profile-pic{width:44px;height:44px;border-radius:50%;object-fit:cover;margin-right:10px;}
</style>
</head>
<body>

<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <div class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?= $pic ?>" class="profile-pic">
      <div>
        <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
    <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </div>

  <!-- Main content -->
  <main class="content">
    <h2 class="mb-3">Manage About Us</h2>
    <?php if($msg): ?><div class="alert alert-info"><?= $msg ?></div><?php endif; ?>

    <!-- WHO WE ARE -->
    <div class="card-soft">
      <h3>Who We Are</h3>
      <form method="post" class="mb-3">
        <input type="text" name="title" placeholder="Title" required class="form-control mb-2">
        <textarea name="description" placeholder="Description" required class="form-control mb-2"></textarea>
        <input type="text" name="icon" placeholder="Bootstrap Icon (e.g., bi-heart)" class="form-control mb-2">
        <button type="submit" name="add_who" class="btn btn-brand">Add</button>
      </form>
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead>
            <tr><th>ID</th><th>Title</th><th>Description</th><th>Icon</th><th>Action</th></tr>
          </thead>
          <tbody>
          <?php while($row=$whoRes->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= $row['title'] ?></td>
              <td><?= $row['description'] ?></td>
              <td><?= $row['icon'] ?></td>
              <td>
                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editWhoModal<?= $row['id'] ?>">Edit</button>
                <a href="?delete_who=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
              </td>
            </tr>

            <!-- Edit Modal -->
            <div class="modal fade" id="editWhoModal<?= $row['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <form method="post">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Who We Are</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                      <input type="hidden" name="id" value="<?= $row['id'] ?>">
                      <input type="text" name="title" value="<?= $row['title'] ?>" class="form-control mb-2">
                      <textarea name="description" class="form-control mb-2"><?= $row['description'] ?></textarea>
                      <input type="text" name="icon" value="<?= $row['icon'] ?>" class="form-control mb-2">
                    </div>
                    <div class="modal-footer">
                      <button type="submit" name="edit_who" class="btn btn-brand">Save Changes</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>

          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- MISSION & VISION -->
<div class="card-soft">
  <h3>Mission & Vision</h3>
  <form method="post" class="mb-3">
    <select name="type" class="form-control mb-2" required>
      <option value="mission">Mission</option>
      <option value="vision">Vision</option>
    </select>
    <input type="text" name="title" placeholder="Title" required class="form-control mb-2">
    <textarea name="description" placeholder="Description" required class="form-control mb-2"></textarea>
    <input type="text" name="icon" placeholder="Bootstrap Icon" class="form-control mb-2">
    <button type="submit" name="add_mv" class="btn btn-brand">Add</button>
  </form>
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr><th>ID</th><th>Type</th><th>Title</th><th>Description</th><th>Icon</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php while($row=$mvRes->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['type'] ?></td>
          <td><?= $row['title'] ?></td>
          <td><?= $row['description'] ?></td>
          <td><?= $row['icon'] ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editMvModal<?= $row['id'] ?>">Edit</button>
            <a href="?delete_mv=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
          </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editMvModal<?= $row['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post">
                <div class="modal-header">
                  <h5 class="modal-title">Edit Mission/Vision</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <select name="type" class="form-control mb-2">
                    <option value="mission" <?= $row['type']=='mission'?'selected':'' ?>>Mission</option>
                    <option value="vision" <?= $row['type']=='vision'?'selected':'' ?>>Vision</option>
                  </select>
                  <input type="text" name="title" value="<?= $row['title'] ?>" class="form-control mb-2">
                  <textarea name="description" class="form-control mb-2"><?= $row['description'] ?></textarea>
                  <input type="text" name="icon" value="<?= $row['icon'] ?>" class="form-control mb-2">
                </div>
                <div class="modal-footer">
                  <button type="submit" name="edit_mv" class="btn btn-brand">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- VALUES -->
<div class="card-soft">
  <h3>Our Values</h3>
  <form method="post" class="mb-3">
    <input type="text" name="title" placeholder="Title" required class="form-control mb-2">
    <textarea name="description" placeholder="Description" required class="form-control mb-2"></textarea>
    <input type="text" name="icon" placeholder="Bootstrap Icon" class="form-control mb-2">
    <button type="submit" name="add_value" class="btn btn-brand">Add</button>
  </form>
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr><th>ID</th><th>Title</th><th>Description</th><th>Icon</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php while($row=$valuesRes->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['title'] ?></td>
          <td><?= $row['description'] ?></td>
          <td><?= $row['icon'] ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editValueModal<?= $row['id'] ?>">Edit</button>
            <a href="?delete_value=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
          </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editValueModal<?= $row['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post">
                <div class="modal-header">
                  <h5 class="modal-title">Edit Value</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <input type="text" name="title" value="<?= $row['title'] ?>" class="form-control mb-2">
                  <textarea name="description" class="form-control mb-2"><?= $row['description'] ?></textarea>
                  <input type="text" name="icon" value="<?= $row['icon'] ?>" class="form-control mb-2">
                </div>
                <div class="modal-footer">
                  <button type="submit" name="edit_value" class="btn btn-brand">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- JOURNEY -->
<div class="card-soft">
  <h3>Our Journey</h3>
  <form method="post" class="mb-3">
    <input type="text" name="year" placeholder="Year" required class="form-control mb-2">
    <textarea name="description" placeholder="Description" required class="form-control mb-2"></textarea>
    <button type="submit" name="add_journey" class="btn btn-brand">Add</button>
  </form>
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr><th>ID</th><th>Year</th><th>Description</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php while($row=$journeyRes->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['year'] ?></td>
          <td><?= $row['description'] ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editJourneyModal<?= $row['id'] ?>">Edit</button>
            <a href="?delete_journey=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
          </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editJourneyModal<?= $row['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post">
                <div class="modal-header">
                  <h5 class="modal-title">Edit Journey</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <input type="text" name="year" value="<?= $row['year'] ?>" class="form-control mb-2">
                  <textarea name="description" class="form-control mb-2"><?= $row['description'] ?></textarea>
                </div>
                <div class="modal-footer">
                  <button type="submit" name="edit_journey" class="btn btn-brand">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- STATS -->
<div class="card-soft">
  <h3>Our Stats</h3>
  <form method="post" class="mb-3">
    <input type="text" name="label" placeholder="Label" required class="form-control mb-2">
    <input type="text" name="value" placeholder="Value (e.g., 500+)" required class="form-control mb-2">
    <button type="submit" name="add_stat" class="btn btn-brand">Add</button>
  </form>
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr><th>ID</th><th>Label</th><th>Value</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php while($row=$statsRes->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['label'] ?></td>
          <td><?= $row['value'] ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editStatModal<?= $row['id'] ?>">Edit</button>
            <a href="?delete_stat=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
          </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editStatModal<?= $row['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post">
                <div class="modal-header">
                  <h5 class="modal-title">Edit Stat</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <input type="text" name="label" value="<?= $row['label'] ?>" class="form-control mb-2">
                  <input type="text" name="value" value="<?= $row['value'] ?>" class="form-control mb-2">
                </div>
                <div class="modal-footer">
                  <button type="submit" name="edit_stat" class="btn btn-brand">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- LEADERSHIP -->
<div class="card-soft">
  <h3>Leadership</h3>
  <form method="post" class="mb-3">
    <input type="text" name="name" placeholder="Name" required class="form-control mb-2">
    <input type="text" name="role" placeholder="Role" required class="form-control mb-2">
    <textarea name="description" placeholder="Description" class="form-control mb-2"></textarea>
    <input type="text" name="image" placeholder="Image URL" class="form-control mb-2">
    <button type="submit" name="add_leader" class="btn btn-brand">Add</button>
  </form>
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr><th>ID</th><th>Name</th><th>Role</th><th>Description</th><th>Image</th><th>Action</th></tr>
      </thead>
      <tbody>
      <?php while($row=$leaderRes->fetch_assoc()): ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= $row['name'] ?></td>
          <td><?= $row['role'] ?></td>
          <td><?= $row['description'] ?></td>
          <td><img src="<?= $row['image'] ?>" width="50"></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editLeaderModal<?= $row['id'] ?>">Edit</button>
            <a href="?delete_leader=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
          </td>
        </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editLeaderModal<?= $row['id'] ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <form method="post">
                <div class="modal-header">
                  <h5 class="modal-title">Edit Leader</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <input type="text" name="name" value="<?= $row['name'] ?>" class="form-control mb-2">
                  <input type="text" name="role" value="<?= $row['role'] ?>" class="form-control mb-2">
                  <textarea name="description" class="form-control mb-2"><?= $row['description'] ?></textarea>
                  <input type="text" name="image" value="<?= $row['image'] ?>" class="form-control mb-2">
                </div>
                <div class="modal-footer">
                  <button type="submit" name="edit_leader" class="btn btn-brand">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
