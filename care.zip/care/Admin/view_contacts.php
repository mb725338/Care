<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../db.php';
require __DIR__ . '/../vendor/autoload.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Handle delete / mark as read
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM contacts WHERE id = $id");
    header("Location: view_contacts.php");
    exit;
}
if (isset($_GET['read'])) {
    $id = intval($_GET['read']);
    $conn->query("UPDATE contacts SET status='read' WHERE id = $id");
    header("Location: view_contacts.php");
    exit;
}

// Handle reply form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_id'])) {
    $contact_id = intval($_POST['contact_id']);
    $to_email = trim($_POST['reply_email']);
    $to_name = trim($_POST['reply_name']);
    $message_body = trim($_POST['reply_message']);

    if (!empty($to_email) && !empty($message_body)) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
             $mail->Username = 'uroobasaleem572@gmail.com';
            $mail->Password = 'fmuf dnnk totu mlse'; // Gmail App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('your_email@gmail.com', 'CARE Support');
            $mail->addAddress($to_email, $to_name);
            $mail->isHTML(true);
            $mail->Subject = "Reply from CARE Support";
            $mail->Body = "<p>Hi {$to_name},</p><p>{$message_body}</p><p>Best regards,<br>CARE Support Team</p>";

            $mail->send();

            // Mark message as read
            $conn->query("UPDATE contacts SET status='read' WHERE id=$contact_id");

            $_SESSION['success'] = "Reply sent successfully to {$to_name}!";
            header("Location: view_contacts.php");
            exit;
        } catch (Exception $e) {
            $_SESSION['error'] = "Mailer Error: {$mail->ErrorInfo}";
            header("Location: view_contacts.php");
            exit;
        }
    }
}

// Get logged-in admin info
$user_id = $_SESSION['user_id'];
$userRes = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id LIMIT 1");
if ($userRes && $userRes->num_rows > 0) {
    $udata = $userRes->fetch_assoc();
    $pname = $udata['name'];
    $pic = !empty($udata['profile_pic']) ? $udata['profile_pic'] : '../assets/default-avatar.svg';
} else {
    $pname = "Admin";
    $pic = "../assets/default-avatar.svg";
}

// Fetch messages
$result = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Messages | CARE Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:28px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none}
.profile-pic{width:50px;height:50px;border-radius:50%;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08)}
@media(max-width:991px){.sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}.sidebar.show{left:0}.content{padding:20px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
/* Mobile message cards */
@media(max-width:768px){
  .table{display:none}
  .message-card{border:1px solid rgba(0,0,0,0.05);border-radius:10px;padding:12px;margin-bottom:12px;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,0.05)}
  .message-card .actions{margin-top:8px}
}
</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>
</head>
<body>
<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <aside id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic me-2">
      <div>
        <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
    <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </aside>

  <!-- Main content -->
  <main class="content">
    <h2>Messages</h2>

    <?php if (!empty($_SESSION['success'])): ?>
      <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="card-soft">
      <!-- Desktop Table -->
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Type</th>
              <th>Message</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?= $row['id'] ?></td>
                  <td><?= htmlspecialchars($row['name']) ?></td>
                  <td><?= htmlspecialchars($row['email']) ?></td>
                  <td><?= htmlspecialchars($row['phone']) ?></td>
                  <td><span class="badge bg-success"><?= htmlspecialchars($row['request_type']) ?></span></td>
                  <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
                  <td><?= $row['created_at'] ?></td>
                  <td>
                    <a href="?read=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-check"></i></a>
                    <a href="#" class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#replyModal" data-email="<?= htmlspecialchars($row['email']) ?>" data-name="<?= htmlspecialchars($row['name']) ?>" data-id="<?= $row['id'] ?>"><i class="fa fa-reply"></i></a>
                    <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this message?')"><i class="fa fa-trash"></i></a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="8" class="text-center">No messages found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Mobile Card View -->
      <?php if ($result && $result->num_rows > 0): ?>
        <?php $result->data_seek(0); while($row = $result->fetch_assoc()): ?>
          <div class="message-card d-md-none">
            <strong><?= htmlspecialchars($row['name']) ?></strong> (<?= htmlspecialchars($row['email']) ?>)<br>
            <small><?= htmlspecialchars($row['phone']) ?> • <?= $row['created_at'] ?></small><br>
            <span class="badge bg-success"><?= htmlspecialchars($row['request_type']) ?></span>
            <p class="mt-2"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
            <div class="actions">
              <a href="?read=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-check"></i> Mark Read</a>
              <a href="#" class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#replyModal" data-email="<?= htmlspecialchars($row['email']) ?>" data-name="<?= htmlspecialchars($row['name']) ?>" data-id="<?= $row['id'] ?>"><i class="fa fa-reply"></i> Reply</a>
              <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this message?')"><i class="fa fa-trash"></i> Delete</a>
            </div>
          </div>
        <?php endwhile; ?>
      <?php endif; ?>
    </div>
  </main>
</div>

<!-- Reply Modal -->
<div class="modal fade" id="replyModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" id="replyForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Reply to User</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="contact_id" id="contact_id">
          <div class="mb-3">
            <label class="form-label">To</label>
            <input type="email" class="form-control" name="reply_email" id="reply_email" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="reply_name" id="reply_name" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label">Message</label>
            <textarea class="form-control" name="reply_message" rows="5" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Send Reply</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
var replyModal = document.getElementById('replyModal')
replyModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget
  var email = button.getAttribute('data-email')
  var name = button.getAttribute('data-name')
  var id = button.getAttribute('data-id')
  
  replyModal.querySelector('#reply_email').value = email
  replyModal.querySelector('#reply_name').value = name
  replyModal.querySelector('#contact_id').value = id
})
</script>
</body>
</html>
