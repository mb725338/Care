<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') { 
    header('Location: ../login.php'); 
    exit; 
}

$user_id = $_SESSION['user_id'];
$userRes = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id LIMIT 1");
if ($userRes && $userRes->num_rows > 0) {
    $udata = $userRes->fetch_assoc();
    $pname = $udata['name'];
    $pic = !empty($udata['profile_pic']) ? $udata['profile_pic'] : '../assets/img/default-avatar.png';
} else {
    $pname = "Admin";
    $pic = "../assets/img/default-avatar.png";
}

// ✅ Handle Website Info save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_settings') {
    $site_title = trim($_POST['site_title'] ?? '');
    $site_description = trim($_POST['site_description'] ?? '');
    $clinic_name = trim($_POST['clinic_name'] ?? '');
    $clinic_email = trim($_POST['clinic_email'] ?? '');
    $clinic_phone = trim($_POST['clinic_phone'] ?? '');

    $stmt = $conn->prepare("REPLACE INTO settings (id, clinic_name, clinic_email, clinic_phone, site_title, site_description) 
                            VALUES (1,?,?,?,?,?)");
    $stmt->bind_param("sssss", $clinic_name, $clinic_email, $clinic_phone, $site_title, $site_description);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_dashboard.php?updated=1");
    exit;
}

// counts
$cities = $conn->query("SELECT COUNT(*) AS cnt FROM cities")->fetch_assoc()['cnt'] ?? 0;
$doctors = $conn->query("SELECT COUNT(*) AS cnt FROM doctors")->fetch_assoc()['cnt'] ?? 0;
$patients = $conn->query("SELECT COUNT(*) AS cnt FROM patients")->fetch_assoc()['cnt'] ?? 0;
$users = $conn->query("SELECT COUNT(*) AS cnt FROM users")->fetch_assoc()['cnt'] ?? 0;
$appointments = $conn->query("SELECT COUNT(*) AS cnt FROM appointments")->fetch_assoc()['cnt'] ?? 0;

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!doctype html>
<html lang="en">
<head>
<title>Admin Dashboard</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:24px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px}
.stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06)}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none}
.profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08)}
@media(max-width:991px){
  .sidebar{position:fixed;left:-320px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000;width:280px}
  .sidebar.show{left:0}
  .content{padding:16px}
  .offcanvas-toggle{display:inline-flex}
}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
.overlay{display:none;position:fixed;top:64px;left:0;width:100%;height:calc(100% - 64px);background:rgba(0,0,0,0.4);z-index:1500}
.sidebar.show ~ .overlay{display:block}
</style>
<script>
function toggleSidebar(){
  document.getElementById('sidebar').classList.toggle('show');
  document.getElementById('overlay').classList.toggle('d-block');
}
</script>
</head>
<body>

<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <div id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?php echo htmlspecialchars($pic); ?>" class="profile-pic me-2">
      <div>
        <div class="fw-semibold"><?php echo htmlspecialchars($pname); ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
    <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </div>
  <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

  <!-- Main content -->
  <main class="content">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2>Dashboard</h2>
      <button class="btn btn-sm btn-outline-secondary d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars me-1"></i> Menu</button>
    </div>

    <!-- Stats -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Cities</small><div class="h3 mt-2"><?php echo $cities; ?></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Doctors</small><div class="h3 mt-2"><?php echo $doctors; ?></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Patients</small><div class="h3 mt-2"><?php echo $patients; ?></div></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><small class="text-muted">Users</small><div class="h3 mt-2"><?php echo $users; ?></div></div></div>
    </div>

    <!-- Website Info -->
<div class="card-soft mb-4">
  <h5 class="mb-2">Website Info</h5>
  <?php $info = $conn->query('SELECT * FROM settings WHERE id=1')->fetch_assoc() ?? []; ?>
  <div class="row">
    <div class="col-md-8">
      <p><strong>Site title:</strong> <?= htmlspecialchars($info['site_title'] ?? 'CARE - Your Health'); ?></p>
      <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($info['site_description'] ?? '')); ?></p>
      <p><strong>Clinic:</strong> <?= htmlspecialchars($info['clinic_name'] ?? ''); ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($info['clinic_email'] ?? ''); ?></p>
      <p><strong>Phone:</strong> <?= htmlspecialchars($info['clinic_phone'] ?? ''); ?></p>
    </div>
    <div class="col-md-4 text-md-end">
      <a href="manage_website_info.php" class="btn btn-brand">
        <i class="fa fa-edit me-1"></i> Edit Website Info
      </a>
    </div>
  </div>
</div>


    <!-- Recent Appointments -->
    <div class="card-soft">
      <h5 class="mb-3">Recent Appointments</h5>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>#</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Status</th></tr></thead>
          <tbody>
          <?php 
          $res = $conn->query("SELECT a.id,a.appointment_date,a.status,u1.name as patient_name,u2.name as doctor_name 
                               FROM appointments a 
                               JOIN patients p ON p.id=a.patient_id 
                               JOIN doctors d ON d.id=a.doctor_id 
                               JOIN users u1 ON u1.id=p.user_id 
                               JOIN users u2 ON u2.id=d.user_id 
                               ORDER BY a.appointment_date DESC LIMIT 8"); 
          if ($res) { 
              while($r=$res->fetch_assoc()){ 
                  echo '<tr><td>'.htmlspecialchars($r['id']).'</td>
                            <td>'.htmlspecialchars($r['patient_name']).'</td>
                            <td>'.htmlspecialchars($r['doctor_name']).'</td>
                            <td>'.htmlspecialchars($r['appointment_date']).'</td>
                            <td>'.htmlspecialchars($r['status']).'</td></tr>'; 
              } 
          } ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
