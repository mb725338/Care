<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$msg = "";

// Handle Add Story
if (isset($_POST['add_story'])) {
    $title = $conn->real_escape_string(trim($_POST['title']));
    $category = $conn->real_escape_string(trim($_POST['category']));
    $excerpt = $conn->real_escape_string(trim($_POST['excerpt']));

    // Image upload
    $imgDb = "";
    if (!empty($_FILES['image']['name'])) {
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        $imgTmp = $_FILES['image']['tmp_name'];
        $uploadDir = "../uploads/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $imgPath = $uploadDir . $imgName;
        if (move_uploaded_file($imgTmp, $imgPath)) {
            $imgDb = "uploads/" . $imgName;
        } else {
            $msg = "⚠️ Image upload failed!";
        }
    }

    if ($imgDb) {
        $sql = "INSERT INTO stories (title, category, excerpt, image) 
                VALUES ('$title', '$category', '$excerpt', '$imgDb')";
        if ($conn->query($sql)) {
            $msg = "✅ Story added successfully!";
        } else {
            $msg = "❌ DB Error: " . $conn->error;
        }
    }
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $imgRes = $conn->query("SELECT image FROM stories WHERE id=$id LIMIT 1");
    if ($imgRes && $imgRes->num_rows > 0) {
        $img = $imgRes->fetch_assoc()['image'];
        if (!empty($img) && file_exists("../" . $img)) unlink("../" . $img);
    }
    if ($conn->query("DELETE FROM stories WHERE id=$id")) {
        $msg = "✅ Story deleted successfully!";
    } else {
        $msg = "❌ Failed to delete story!";
    }
}

// Handle Edit / Update
if (isset($_POST['edit_story'])) {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string(trim($_POST['title']));
    $category = $conn->real_escape_string(trim($_POST['category']));
    $excerpt = $conn->real_escape_string(trim($_POST['excerpt']));

    if (!empty($_FILES['image']['name'])) {
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        $imgTmp = $_FILES['image']['tmp_name'];
        $uploadDir = "../uploads/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $imgPath = $uploadDir . $imgName;
        if (move_uploaded_file($imgTmp, $imgPath)) {
            $imgDb = "uploads/" . $imgName;
            $conn->query("UPDATE stories SET title='$title', category='$category', excerpt='$excerpt', image='$imgDb' WHERE id=$id");
        }
    } else {
        $conn->query("UPDATE stories SET title='$title', category='$category', excerpt='$excerpt' WHERE id=$id");
    }
    $msg = "✅ Story updated successfully!";
}

// Fetch stories
$res = $conn->query("SELECT * FROM stories ORDER BY created_at DESC");

// Get admin info
$user_id = $_SESSION['user_id'];
$userRes = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id LIMIT 1");
if ($userRes && $userRes->num_rows > 0) {
    $udata = $userRes->fetch_assoc();
    $pname = $udata['name'];
    $pic = !empty($udata['profile_pic']) ? $udata['profile_pic'] : '../assets/img/default-avatar.png';
} else {
    $pname = "Admin";
    $pic = "../assets/img/default-avatar.png";
}

$current_page = basename(__FILE__);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Stories | CARE Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06);}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06);}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:24px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;}
.profile-pic{width:50px;height:50px;border-radius:50%;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08);}
@media(max-width:991px){.sidebar{position:fixed;left:-320px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000;width:280px}.sidebar.show{left:0}.content{padding:16px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>
</head>
<body>

<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
  </div>
</header>

<div class="layout">
  <aside id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
        <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic me-2">
        <div>
            <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
            <small class="text-muted">Administrator</small>
        </div>
    </div>
    <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_stories.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </aside>

  <main class="content">
    <h2>📖 Manage Stories</h2>
    <?php if($msg) echo "<div class='alert alert-info'>$msg</div>"; ?>

    <!-- Add Story Form -->
    <div class="card-soft mb-4">
      <form method="post" enctype="multipart/form-data">
        <div class="mb-2"><label>Title</label><input type="text" name="title" class="form-control" required></div>
        <div class="mb-2"><label>Category</label>
          <select name="category" class="form-control" required>
            <option value="recovery">Recovery</option>
            <option value="surgery">Surgery</option>
            <option value="pediatrics">Pediatrics</option>
            <option value="cardiology">Cardiology</option>
          </select>
        </div>
        <div class="mb-2"><label>Excerpt</label><textarea name="excerpt" class="form-control" required></textarea></div>
        <div class="mb-2"><label>Image</label><input type="file" name="image" class="form-control" required></div>
        <button type="submit" name="add_story" class="btn btn-brand">➕ Add Story</button>
      </form>
    </div>

    <!-- Stories Table -->
    <div class="card-soft">
      <h5 class="mb-3">All Stories</h5>
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead>
            <tr><th>ID</th><th>Image</th><th>Title</th><th>Category</th><th>Excerpt</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php if($res && $res->num_rows > 0): ?>
              <?php while($row=$res->fetch_assoc()): ?>
                <tr>
                  <td><?= $row['id'] ?></td>
                  <td><img src="../<?= htmlspecialchars($row['image']) ?>" width="80"></td>
                  <td><?= htmlspecialchars($row['title']) ?></td>
                  <td><?= ucfirst(htmlspecialchars($row['category'])) ?></td>
                  <td><?= htmlspecialchars($row['excerpt']) ?></td>
                  <td>
                    <!-- Edit Button -->
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id'] ?>"><i class="fa fa-edit"></i> Edit</button>
                    <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this story?')"><i class="fa fa-trash"></i> Delete</a>
                  </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="edit_story" value="1">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Story - #<?= $row['id'] ?></h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <div class="mb-2"><label>Title</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($row['title']) ?>" required></div>
                          <div class="mb-2"><label>Category</label>
                            <select name="category" class="form-control" required>
                              <option value="recovery" <?= $row['category']=='recovery'?'selected':'' ?>>Recovery</option>
                              <option value="surgery" <?= $row['category']=='surgery'?'selected':'' ?>>Surgery</option>
                              <option value="pediatrics" <?= $row['category']=='pediatrics'?'selected':'' ?>>Pediatrics</option>
                              <option value="cardiology" <?= $row['category']=='cardiology'?'selected':'' ?>>Cardiology</option>
                            </select>
                          </div>
                          <div class="mb-2"><label>Excerpt</label><textarea name="excerpt" class="form-control" required><?= htmlspecialchars($row['excerpt']) ?></textarea></div>
                          <div class="mb-2"><label>Image (optional)</label><input type="file" name="image" class="form-control"><img src="../<?= htmlspecialchars($row['image']) ?>" width="100" class="mt-2"></div>
                        </div>
                        <div class="modal-footer">
                          <button class="btn btn-brand">Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="6" class="text-center">⚠️ No stories found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
