<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php'); 
    exit;
}

// Fetch admin info for profile pic and name
$pic = 'assets/images/default.png';
$pname = 'Admin';
$res_admin = $conn->query("SELECT name, profile_pic FROM users WHERE id=".$_SESSION['user_id']);
if($res_admin && $res_admin->num_rows){
    $row = $res_admin->fetch_assoc();
    $pname = $row['name'];
    if(!empty($row['profile_pic'])) $pic = $row['profile_pic'];
}

// Handle edit/save from modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_patient'])) {
    $id = (int)$_POST['id'];
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $city_id = (int)$_POST['city_id'];

    // Update patients table
    $stmt = $conn->prepare("UPDATE patients SET phone=?, city_id=? WHERE id=?");
    $stmt->bind_param("iii", $phone, $city_id, $id);
    $stmt->execute();
    $stmt->close();

    // Update users table
    $stmt2 = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=(SELECT user_id FROM patients WHERE id=?)");
    $stmt2->bind_param("ssi", $name, $email, $id);
    $stmt2->execute();
    $stmt2->close();

    $_SESSION['message'] = "Patient updated successfully!";
    header("Location: manage_patients.php");
    exit;
}

// Handle delete
if(isset($_GET['delete'])){
    $del_id = (int)$_GET['delete'];
    // Delete patient
    $conn->query("DELETE FROM patients WHERE id=$del_id");
    $_SESSION['message'] = "Patient deleted successfully!";
    header("Location: manage_patients.php");
    exit;
}

// Fetch patients
$res = $conn->query('SELECT p.*, u.email, u.name as uname FROM patients p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC');
if(!$res){
    die("Query failed: " . $conn->error);
}

// Current page for sidebar
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
    <title>Manage Patients</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root{
            --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
            --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
        }
        body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
        .topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
        .brand{display:flex;align-items:center;gap:10px;font-weight:700}
        .brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
        .layout{display:flex;min-height:calc(100vh - 64px);}
        .sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
        .sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
        .sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
        .content{flex:1;padding:28px;}
        .card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
        .btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
        .stat-card{border-radius:12px;padding:18px;background:#fff;box-shadow:0 8px 22px rgba(2,8,23,0.06);}
        .table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none}
        .profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;margin-right:10px;}
        @media(max-width:991px){
            .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}
            .sidebar.show{left:0}
            .content{padding:20px;}
            .offcanvas-toggle{display:inline-flex}
        }
        .offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
        .overlay{display:none;position:fixed;top:64px;left:0;width:100%;height:100%;background:rgba(0,0,0,0.2);z-index:1500;}
        .overlay.show{display:block;}
    </style>
    <script>
        function toggleSidebar(){ 
            document.getElementById('sidebar').classList.toggle('show');
            document.getElementById('overlay').classList.toggle('show');
        }
        function fillEditModal(id, name, email, phone, city_id) {
            document.getElementById('editPatientId').value = id;
            document.getElementById('editPatientName').value = name;
            document.getElementById('editPatientEmail').value = email;
            document.getElementById('editPatientPhone').value = phone;
            document.getElementById('editPatientCity').value = city_id;
        }
    </script>
</head>
<body>
<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <div id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic">
      <div>
        <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
     <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_stories.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="view_reports.php" class="nav-link <?= $current_page==='view_reports.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </div>
  <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

  <!-- Main content -->
  <main class="content">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Patients</h2>
        <button class="btn btn-sm btn-outline-secondary d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars me-1"></i> Menu</button>
    </div>

    <div class="card-soft">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($p = $res->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($p['id']) ?></td>
                        <td><?= htmlspecialchars($p['uname']) ?></td>
                        <td><?= htmlspecialchars($p['email']) ?></td>
                        <td><?= htmlspecialchars($p['phone']) ?></td>
                        <td><?= htmlspecialchars($p['city_id']) ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-secondary" 
                                data-bs-toggle="modal" data-bs-target="#editModal"
                                onclick="fillEditModal('<?= $p['id'] ?>','<?= htmlspecialchars($p['uname'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['email'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['phone'], ENT_QUOTES) ?>','<?= htmlspecialchars($p['city_id'], ENT_QUOTES) ?>')">
                                Edit
                            </button>
                            <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
  </main>
</div>

<?php if(isset($_SESSION['message'])): ?>
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1100">
  <div id="liveToast" class="toast align-items-center text-bg-success border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        <?= $_SESSION['message'] ?>
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  </div>
</div>
<?php unset($_SESSION['message']); endif; ?>

<!-- Edit Patient Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form action="" method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Patient</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="editPatientId">
          <div class="mb-3">
              <label>Name</label>
              <input type="text" name="name" id="editPatientName" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Email</label>
              <input type="email" name="email" id="editPatientEmail" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Phone</label>
              <input type="text" name="phone" id="editPatientPhone" class="form-control">
          </div>
          <div class="mb-3">
              <label>City ID</label>
              <input type="text" name="city_id" id="editPatientCity" class="form-control">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="update_patient" class="btn btn-primary">Save changes</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
    var toastEl = document.getElementById('liveToast');
    if(toastEl){
        var toast = new bootstrap.Toast(toastEl, { delay: 3000 });
        toast.show();
    }
});
</script>
</body>
</html>
