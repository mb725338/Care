<?php
session_start();
require "../db.php";

// --- Check admin session ---
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// --- Fetch Admin Profile ---
$user_id = $_SESSION['user_id'];
$admin_name = "Admin User";
$admin_pic = "../assets/profile.jpg";

$stmt = $conn->prepare("SELECT name, profile_pic FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($name, $pic);
if($stmt->fetch()){
    $admin_name = $name;
    if(!empty($pic)) $admin_pic = $pic;
}
$stmt->close();

// --- Fetch all users ---
$res = $conn->query('SELECT * FROM users ORDER BY id DESC');
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Users | Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{
  --brand:#10b981; --brand-2:#0ea5e9; --bg:#f8fafc; --surface:#ffffff; --muted:#64748b;
  --radius:12px; --shadow:0 10px 35px rgba(2,8,23,0.06);
}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:transparent;border-bottom:1px solid rgba(2,8,23,0.04);}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;}
.brand .logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06);}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:28px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;}
.profile-pic{width:40px;height:40px;border-radius:50%;object-fit:cover;margin-right:10px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand-2));color:#fff;border:none;}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow);}
@media(max-width:991px){
  .sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}
  .sidebar.show{left:0}
  .content{padding:20px;}
  .offcanvas-toggle{display:inline-flex}
}
</style>
<script>function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('show'); }</script>
</head>
<body>
<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <div id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?= htmlspecialchars($admin_pic) ?>" class="profile-pic">
      <div>
        <div class="fw-semibold"><?= htmlspecialchars($admin_name) ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
     <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </div>
  <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

  <!-- Main content -->
  <main class="content">
    <h2>Manage Users</h2>
    <div class="card-soft mt-3">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($u=$res->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($u['id']) ?></td>
              <td><?= htmlspecialchars($u['name']) ?></td>
              <td><?= htmlspecialchars($u['email']) ?></td>
              <td><?= htmlspecialchars($u['role']) ?></td>
              <td>
                <a href="edit_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                <a href="delete_user.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete user?')">Delete</a>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
