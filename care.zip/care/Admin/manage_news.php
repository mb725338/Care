<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$userRes = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id LIMIT 1");
$udata = $userRes->fetch_assoc() ?? [];
$pname = $udata['name'] ?? "Admin";
$pic = !empty($udata['profile_pic']) ? $udata['profile_pic'] : '../assets/img/default-avatar.png';

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $short_desc = $_POST['short_desc'] ?? '';
    $full_content = $_POST['full_content'] ?? '';
    $id = $_POST['id'] ?? null;

    // Image upload
    $imgName = '';
    if (!empty($_FILES['image']['name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imgName = 'news_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $imgName);
    }

    if ($id) {
        // Edit
        if ($imgName) {
            $stmt = $conn->prepare("UPDATE news_articles SET title=?, short_desc=?, full_content=?, image=? WHERE id=?");
            $stmt->bind_param('ssssi', $title, $short_desc, $full_content, $imgName, $id);
        } else {
            $stmt = $conn->prepare("UPDATE news_articles SET title=?, short_desc=?, full_content=? WHERE id=?");
            $stmt->bind_param('sssi', $title, $short_desc, $full_content, $id);
        }
        $stmt->execute();
        $stmt->close();
    } else {
        // Add new
        $stmt = $conn->prepare("INSERT INTO news_articles (title, short_desc, full_content, image, created_at) VALUES (?,?,?,?,NOW())");
        $stmt->bind_param('ssss', $title, $short_desc, $full_content, $imgName);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: manage_news.php');
    exit;
}

// Handle Delete
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    $conn->query("DELETE FROM news_articles WHERE id=$del_id");
    header('Location: manage_news.php');
    exit;
}

// Fetch all articles
$articles = [];
$res = $conn->query("SELECT * FROM news_articles ORDER BY created_at DESC");
if ($res) $articles = $res->fetch_all(MYSQLI_ASSOC);

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage News — Admin CARE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
<style>
:root{
    --brand:#10b981;
    --brand2:#0ea5e9;
    --bg:#f8fafc;
    --surface:#fff;
    --muted:#64748b;
    --radius:12px;
    --shadow:0 10px 35px rgba(2,8,23,0.06);
}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a;}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);gap:10px;background:transparent;}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06);}
.layout{display:flex;min-height:calc(100vh - 64px);}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow);position:fixed;top:64px;left:0;height:calc(100% - 64px);z-index:2000;transition:left 0.3s ease;}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px;}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand);}
.content{flex:1;padding:24px;margin-left:250px;}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;margin-bottom:20px;}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px;}
.table thead th{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;}
.profile-pic{width:40px;height:40px;border-radius:999px;object-fit:cover;border:2px solid #fff;box-shadow:0 4px 12px rgba(2,8,23,0.08);}
@media(max-width:991px){
    .sidebar{left:-280px;}
    .sidebar.show{left:0;}
    .content{margin-left:0;padding:16px;}
    .offcanvas-toggle{display:inline-flex;}
}
.overlay{display:none;position:fixed;top:64px;left:0;width:100%;height:calc(100% - 64px);background:rgba(0,0,0,0.4);z-index:1500;}
.sidebar.show ~ .overlay{display:block;}
</style>
<script>
function toggleSidebar(){
    document.getElementById('sidebar').classList.toggle('show');
    document.getElementById('overlay').classList.toggle('show');
}
function editArticle(id,title,short_desc,full_content){
    document.getElementById('articleId').value=id;
    document.getElementById('title').value=title;
    document.getElementById('short_desc').value=short_desc;
    document.getElementById('full_content').value=full_content;
    var modal = new bootstrap.Modal(document.getElementById('newsModal'));
    modal.show();
}
</script>
</head>
<body>

<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  </div>
</header>

<div class="layout">
  <aside id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
        <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic me-2">
        <div>
            <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
            <small class="text-muted">Administrator</small>
        </div>
    </div>
    <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </aside>
  <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

  <main class="content">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Manage News</h2>
        <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#newsModal"><i class="fa fa-plus me-1"></i> Add News</button>
    </div>

    <div class="card-soft">
      <table class="table table-striped align-middle">
        <thead>
          <tr><th>#</th><th>Title</th><th>Short Desc</th><th>Image</th><th>Created At</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach($articles as $a): ?>
          <tr>
            <td><?= $a['id'] ?></td>
            <td><?= htmlspecialchars($a['title']) ?></td>
            <td><?= htmlspecialchars($a['short_desc']) ?></td>
            <td><?php if($a['image']) echo '<img src="uploads/'.htmlspecialchars($a['image']).'" width="80">'; ?></td>
            <td><?= $a['created_at'] ?></td>
            <td>
              <button class="btn btn-sm btn-brand" onclick="editArticle('<?= $a['id'] ?>','<?= htmlspecialchars(addslashes($a['title'])) ?>','<?= htmlspecialchars(addslashes($a['short_desc'])) ?>','<?= htmlspecialchars(addslashes($a['full_content'])) ?>')"><i class="fa fa-edit"></i></button>
              <a href="?delete=<?= $a['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this article?')"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="newsModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
<form method="post" enctype="multipart/form-data">
<div class="modal-header"><h5 class="modal-title">Add/Edit News</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<input type="hidden" name="id" id="articleId">
<div class="mb-2"><label>Title</label><input name="title" id="title" class="form-control" required></div>
<div class="mb-2"><label>Short Description</label><input name="short_desc" id="short_desc" class="form-control" required></div>
<div class="mb-2"><label>Full Content</label><textarea name="full_content" id="full_content" class="form-control" rows="6" required></textarea></div>
<div class="mb-2"><label>Image</label><input type="file" name="image" class="form-control"></div>
</div>
<div class="modal-footer"><button class="btn btn-brand">Save</button></div>
</form>
</div></div></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
