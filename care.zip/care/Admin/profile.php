<?php
session_start();
require "../db.php";

// --- Check session ---
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$uid = intval($_SESSION['user_id']);

// --- Handle profile update ---
if ($_SERVER['REQUEST_METHOD'] === "POST" && ($_POST['action'] ?? '') === 'save_profile') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Upload profile picture
    if (!empty($_FILES['profile_pic']['name'])) {
        $uploaddir = __DIR__ . '/assets/uploads/';
        if (!is_dir($uploaddir)) mkdir($uploaddir, 0755, true);
        $ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        $fn = 'user_' . $uid . '_' . time() . '.' . $ext;
        $target = $uploaddir . $fn;
        if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target)) {
            $picpath = 'assets/uploads/' . $fn;
            $stmt = $conn->prepare('UPDATE users SET profile_pic=? WHERE id=?');
            $stmt->bind_param('si', $picpath, $uid);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Update other details
    if ($password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('UPDATE users SET name=?, email=?, password=? WHERE id=?');
        $stmt->bind_param('sssi', $name, $email, $hash, $uid);
    } else {
        $stmt = $conn->prepare('UPDATE users SET name=?, email=? WHERE id=?');
        $stmt->bind_param('ssi', $name, $email, $uid);
    }
    $stmt->execute();
    $stmt->close();
    header("Location: profile.php");
    exit;
}

// --- Fetch user details ---
$u = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc() ?? [];
$current_page = basename($_SERVER['PHP_SELF']);
$pic = $u['profile_pic'] ?? 'assets/default-avatar.svg';
if(!file_exists(__DIR__.'/'.$pic)) $pic='assets/default-avatar.svg';
$pname = $u['name'] ?? 'Administrator';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Profile | Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{--brand:#10b981;--brand2:#0ea5e9;--bg:#f8fafc;--surface:#fff;--muted:#64748b;--radius:12px;--shadow:0 10px 35px rgba(2,8,23,0.06)}
body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;background:var(--bg);margin:0;color:#0f172a}
.topbar{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(2,8,23,0.04);background:transparent;gap:10px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700}
.brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg, rgba(16,185,129,.12), rgba(14,165,233,.08));display:inline-flex;align-items:center;justify-content:center;border:1px solid rgba(2,8,23,.06)}
.layout{display:flex;min-height:calc(100vh - 64px)}
.sidebar{width:250px;background:var(--surface);border-right:1px solid rgba(2,8,23,0.04);padding:18px;box-shadow:var(--shadow)}
.sidebar .nav a{display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;color:var(--muted);text-decoration:none;margin-bottom:6px}
.sidebar .nav a:hover,.sidebar .nav a.active{background:linear-gradient(180deg, rgba(16,185,129,0.06), rgba(14,165,233,0.03));color:var(--brand)}
.content{flex:1;padding:28px}
.card-soft{background:var(--surface);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
.btn-brand{background:linear-gradient(90deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:999px;padding:8px 16px}
.profile-pic{width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid #fff;box-shadow:0 8px 20px rgba(2,8,23,0.06)}
@media(max-width:991px){.sidebar{position:fixed;left:-300px;top:64px;height:calc(100% - 64px);transition:left .28s ease;z-index:2000}.sidebar.show{left:0}.content{padding:20px}.offcanvas-toggle{display:inline-flex}}
.offcanvas-toggle{display:none;border-radius:8px;border:none;padding:8px 12px;background:var(--surface);box-shadow:var(--shadow)}
</style>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('show');}</script>
</head>
<body>

<header class="topbar">
  <div class="brand"><div class="logo"><i class="fa fa-heartbeat"></i></div>CARE Admin</div>
  <div>
    <a href="../" class="btn btn-sm">View Site</a>
    <a href="logout.php" class="btn btn-sm">Logout</a>
    <button class="offcanvas-toggle d-lg-none" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  </div>
</header>

<div class="layout">
  <!-- Sidebar -->
  <div id="sidebar" class="sidebar">
    <div class="d-flex align-items-center mb-4">
      <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic me-2">
      <div>
        <div class="fw-semibold"><?= htmlspecialchars($pname) ?></div>
        <small class="text-muted">Administrator</small>
      </div>
    </div>
     <nav class="nav flex-column">
      <a href="admin_dashboard.php" class="nav-link <?= $current_page==='admin_dashboard.php'?'active':'' ?>"><i class="fa fa-tachometer-alt me-2"></i> Dashboard</a>
      <a href="manage_cities.php" class="nav-link <?= $current_page==='manage_cities.php'?'active':'' ?>"><i class="fa fa-city me-2"></i> Cities</a>
      <a href="manage_doctors.php" class="nav-link <?= $current_page==='manage_doctors.php'?'active':'' ?>"><i class="fa fa-user-md me-2"></i> Doctors</a>
      <a href="manage_patients.php" class="nav-link <?= $current_page==='manage_patients.php'?'active':'' ?>"><i class="fa fa-user me-2"></i> Patients</a>
      <a href="manage_users.php" class="nav-link <?= $current_page==='manage_users.php'?'active':'' ?>"><i class="fa fa-users me-2"></i> Users</a>
      <a href="manage_news.php" class="nav-link <?= $current_page==='manage_news.php'?'active':'' ?>"><i class="fa fa-newspaper me-2"></i> News</a>
      <a href="manage_story.php" class="nav-link <?= $current_page==='manage_stories.php'?'active':'' ?>"><i class="fa fa-book me-2"></i> Stories</a>
      <a href="manage_about.php" class="nav-link <?= $current_page==='manage_about.php'?'active':'' ?>"><i class="fa fa-info-circle me-2"></i> About</a>
      <a href="manage_services.php" class="nav-link <?= $current_page==='manage_services.php'?'active':'' ?>"><i class="fa fa-tools me-2"></i> Services</a>
      <a href="appointments.php" class="nav-link <?= $current_page==='appointments.php'?'active':'' ?>"><i class="fa fa-calendar-check me-2"></i> Appointments</a>
      <a href="view_contacts.php" class="nav-link <?= $current_page==='view_contacts.php'?'active':'' ?>"><i class="fa fa-envelope me-2"></i> Messages</a>
      <a href="reports.php" class="nav-link <?= $current_page==='reports.php'?'active':'' ?>"><i class="fa fa-chart-line me-2"></i> Reports</a>
      <a href="settings.php" class="nav-link <?= $current_page==='settings.php'?'active':'' ?>"><i class="fa fa-cogs me-2"></i> Settings</a>
      <a href="manage_website_info.php" class="nav-link <?= $current_page==='website_info.php'?'active':'' ?>"><i class="fa fa-globe me-2"></i> Website Info</a>
      <a href="profile.php" class="nav-link <?= $current_page==='profile.php'?'active':'' ?>"><i class="fa fa-user-circle me-2"></i> Profile</a>
    </nav>
  </div>

  <!-- Main content -->
  <main class="content">
    <h2>Profile</h2>
    <div class="card-soft mb-3">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <img src="<?= htmlspecialchars($pic) ?>" class="profile-pic mb-2">
                <div class="fw-semibold"><?= htmlspecialchars($u['name'] ?? '') ?></div>
                <div class="text-muted small"><?= htmlspecialchars($u['email'] ?? '') ?></div>
            </div>
            <div class="col-md-9">
                <p><strong>Role:</strong> <?= htmlspecialchars($u['role'] ?? '') ?></p>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                    <i class="fa fa-edit me-1"></i> Edit Profile
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="save_profile">
            <div class="modal-header">
              <h5 class="modal-title">Edit Profile</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-2"><label>Name</label><input class="form-control" name="name" value="<?= htmlspecialchars($u['name'] ?? '') ?>" required></div>
              <div class="mb-2"><label>Email</label><input class="form-control" name="email" value="<?= htmlspecialchars($u['email'] ?? '') ?>" type="email" required></div>
              <div class="mb-2"><label>New Password (leave blank to keep)</label><input class="form-control" name="password" type="password"></div>
              <div class="mb-2"><label>Profile picture (optional)</label><input class="form-control" type="file" name="profile_pic" accept="image/*"></div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-brand">Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>

  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
