<?php
session_start();
$DB_HOST='127.0.0.1'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='care_db';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='doctor'){ header('Location: ../index.php'); exit; }
$conn = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
if($conn->connect_error) die('DB Error: '.$conn->connect_error);
$uid = (int)$_SESSION['user_id'];

// get doctor.id from doctors table
$docRow = $conn->query("SELECT id FROM doctors WHERE user_id=$uid")->fetch_assoc();
$doctor_id = (int)($docRow['id'] ?? 0);

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' and isset($_POST['add_record'])){
    $patient_id = (int)$_POST['patient_id']; // patients.id
    $diagnosis = trim($_POST['diagnosis']);
    $prescription = trim($_POST['prescription']);
    $notes = trim($_POST['notes'] ?? '');

    $stmt = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, diagnosis, prescription, notes) VALUES (?,?,?,?,?)");
    $stmt->bind_param('iisss',$patient_id,$doctor_id,$diagnosis,$prescription,$notes);
    if($stmt->execute()) $msg='Record saved.'; else $msg='Save failed: '.$stmt->error;
    $stmt->close();
}

// patients list for dropdown
$patients = $conn->query("SELECT p.id, u.name 
                          FROM patients p 
                          JOIN users u ON p.user_id=u.id 
                          ORDER BY u.name ASC");

// doctor’s created records
$sql = "SELECT mr.*, u.name as patient_name
        FROM medical_records mr
        JOIN patients p ON mr.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE mr.doctor_id=$doctor_id
        ORDER BY mr.visit_date DESC";
$res = $conn->query($sql);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctor Records</title>
<link rel="stylesheet" href="../assets/style2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-light bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="doctor_dashboard.php">CARE - Doctor</a>
    <div><a href="doctor_dashboard.php" class="btn btn-outline-secondary">Dashboard</a></div>
  </div>
</nav>

<div class="container py-4">
  <h3>Patient Records</h3>
  <?php if($msg): ?><div class="alert alert-info"><?=htmlspecialchars($msg)?></div><?php endif; ?>

  <div class="card mb-4 p-3">
    <h5>Add New Record</h5>
    <form method="POST" class="row g-3">
      <div class="col-md-6">
        <label>Patient</label>
        <select name="patient_id" class="form-select" required>
          <option value="">-- Select Patient --</option>
          <?php while($p=$patients->fetch_assoc()): ?>
            <option value="<?=$p['id']?>"><?=htmlspecialchars($p['name'])?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-12"><label>Diagnosis</label><textarea name="diagnosis" class="form-control" required></textarea></div>
      <div class="col-12"><label>Prescription</label><textarea name="prescription" class="form-control" required></textarea></div>
      <div class="col-12"><label>Notes</label><textarea name="notes" class="form-control"></textarea></div>
      <div class="col-12"><button name="add_record" class="btn btn-primary">Save Record</button></div>
    </form>
  </div>

  <h5>Your Created Records</h5>
  <?php if($res->num_rows==0): ?><div class="alert alert-warning">No records yet.</div>
  <?php else: while($row=$res->fetch_assoc()): ?>
    <div class="feature-card p-3 mb-3">
      <div><strong><?=htmlspecialchars($row['patient_name'])?></strong> 
        <small class="text-muted"><?=date('M d, Y', strtotime($row['visit_date']))?></small></div>
      <div class="mt-2"><strong>Diagnosis:</strong> <?=nl2br(htmlspecialchars($row['diagnosis']))?></div>
      <div class="mt-2"><strong>Prescription:</strong> <?=nl2br(htmlspecialchars($row['prescription']))?></div>
      <?php if($row['notes']): ?><div class="mt-2"><strong>Notes:</strong> <?=nl2br(htmlspecialchars($row['notes']))?></div><?php endif; ?>
    </div>
  <?php endwhile; endif; ?>
</div>
</body>
</html>
