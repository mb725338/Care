<?php
session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id'], $_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}

$current_user_id = (int)$_SESSION['user_id'];
$current_role = $_SESSION['role']; // doctor | patient

function safe_output($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
}

// -------------------- AJAX HANDLERS --------------------
if (isset($_GET['action']) && $_GET['action'] === 'fetch_contacts') {
    header("Content-Type: application/json");
    $contacts = [];

    if ($current_role === 'patient') {
        $pid = $conn->query("SELECT id FROM patients WHERE user_id=$current_user_id")->fetch_assoc()['id'] ?? 0;
        if ($pid) {
            $sql = "SELECT u.id as user_id, u.name, u.email, d.specialization
                    FROM appointments a
                    JOIN doctors d ON a.doctor_id=d.id
                    JOIN users u ON u.id=d.user_id
                    WHERE a.patient_id=$pid
                    GROUP BY u.id";
            $res = $conn->query($sql);
            while ($row = $res->fetch_assoc()) {
                $contacts[] = [
                    'id' => (int)$row['user_id'],
                    'name' => $row['name'],
                    'subtitle' => $row['specialization'],
                    'email' => $row['email']
                ];
            }
        }
    } elseif ($current_role === 'doctor') {
        $did = $conn->query("SELECT id FROM doctors WHERE user_id=$current_user_id")->fetch_assoc()['id'] ?? 0;
        if ($did) {
            $sql = "SELECT u.id as user_id, u.name, u.email, p.phone
                    FROM appointments a
                    JOIN patients p ON a.patient_id=p.id
                    JOIN users u ON u.id=p.user_id
                    WHERE a.doctor_id=$did
                    GROUP BY u.id";
            $res = $conn->query($sql);
            while ($row = $res->fetch_assoc()) {
                $contacts[] = [
                    'id' => (int)$row['user_id'],
                    'name' => $row['name'],
                    'subtitle' => $row['phone'],
                    'email' => $row['email']
                ];
            }
        }
    }

    echo json_encode(['contacts' => $contacts]);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'send' && $_SERVER['REQUEST_METHOD']==='POST') {
    header("Content-Type: application/json");
    $to = (int)$_POST['to_user_id'];
    $msg = trim($_POST['message'] ?? '');
    if ($to > 0 && $msg !== '') {
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, subject, message, status, created_at)
                                VALUES (?, ?, '', ?, 'unread', NOW())");
        $stmt->bind_param("iis", $current_user_id, $to, $msg);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['error'=>'Invalid data']);
    }
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'fetch_msgs') {
    header("Content-Type: application/json");
    $cid = (int)($_GET['contact_id'] ?? 0);
    $msgs = [];
    if ($cid) {
        $sql = "SELECT m.*, u.name as sender_name
                FROM messages m
                JOIN users u ON m.sender_id=u.id
                WHERE (m.sender_id=$current_user_id AND m.receiver_id=$cid)
                   OR (m.sender_id=$cid AND m.receiver_id=$current_user_id)
                ORDER BY m.created_at ASC";
        $res = $conn->query($sql);
        while ($row = $res->fetch_assoc()) {
            $msgs[] = [
                'id' => (int)$row['id'],
                'from' => (int)$row['sender_id'],
                'to' => (int)$row['receiver_id'],
                'text' => $row['message'],
                'created_at' => $row['created_at'],
                'sender_name' => $row['sender_name']
            ];
        }
        $conn->query("UPDATE messages SET status='read'
                      WHERE sender_id=$cid AND receiver_id=$current_user_id AND status='unread'");
    }
    echo json_encode(['messages'=>$msgs]);
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Messages | CARE</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/style2.css">
<style>
body {background:#f9fafb;}
#app {display:flex; height:100vh;}
.contacts {width:300px; border-right:1px solid #e5e7eb; background:#fff; overflow-y:auto;}
.contact {padding:12px 14px; border-bottom:1px solid #f3f4f6; cursor:pointer;}
.contact:hover {background:#f9fafb;}
.contact.active {background:#eef2ff;}
.chat {flex:1; display:flex; flex-direction:column;}
.msgs {flex:1; padding:20px; overflow:auto; background:#f3f4f6;}
.msg {max-width:75%; padding:10px 14px; border-radius:12px; margin-bottom:10px;}
.msg.me {background:#2563eb; color:#fff; margin-left:auto; border-bottom-right-radius:4px;}
.msg.them {background:#fff; border:1px solid #e5e7eb; color:#111; border-bottom-left-radius:4px;}
.chat-footer {padding:12px; border-top:1px solid #e5e7eb; background:#fff; display:flex; gap:10px;}
.chat-footer input {flex:1;}
@media(max-width:768px){
  .contacts{width:100%; height:250px; position:absolute; z-index:10; display:none;}
  .contacts.open{display:block;}
  .chat{margin-top:250px;}
}
</style>
</head>
<body class="chat-page">
  
<nav class="navbar navbar-light bg-white border-bottom shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">CARE Messages</a>
    <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
  </div>
</nav>
<div id="app">
  <div class="contacts" id="contactsPane">
    <h6 class="p-3 border-bottom">Contacts</h6>
    <div id="contactsList"></div>
  </div>
  <div class="chat">
    <div class="border-bottom p-3 d-flex justify-content-between align-items-center">
      <div>
        <button id="toggleContacts" class="btn btn-sm btn-outline-secondary d-md-none">☰</button>
        <strong id="chatHeader">Select a contact</strong>
      </div>
    </div>
    <div class="msgs" id="messagesPane"></div>
    <div class="chat-footer">
      <input id="msgInput" class="form-control" placeholder="Type a message..." disabled>
      <button id="sendBtn" class="btn btn-primary" disabled>Send</button>
    </div>
  </div>
</div>
<script>
const uid = <?=json_encode($current_user_id)?>;
let active=0;
async function loadContacts(){
  let r=await fetch("messages.php?action=fetch_contacts");
  let d=await r.json();
  let list=document.getElementById("contactsList"); list.innerHTML="";
  d.contacts.forEach(c=>{
    let div=document.createElement("div");
    div.className="contact";
    div.textContent=c.name + (c.subtitle ? " ("+c.subtitle+")" : "");
    div.onclick=()=>setContact(c.id,c.name);
    list.appendChild(div);
  });
}
async function setContact(id,name){
  active=id;
  document.getElementById("chatHeader").textContent=name;
  document.getElementById("msgInput").disabled=false;
  document.getElementById("sendBtn").disabled=false;
  fetchMessages();
  document.querySelectorAll(".contact").forEach(el=>el.classList.remove("active"));
  document.querySelectorAll(".contact").forEach(el=>{
    if(el.textContent.includes(name)) el.classList.add("active");
  });
  if(window.innerWidth<768){document.getElementById("contactsPane").classList.remove("open");}
}
async function fetchMessages(){
  if(!active) return;
  let r=await fetch("messages.php?action=fetch_msgs&contact_id="+active);
  let d=await r.json();
  let box=document.getElementById("messagesPane"); box.innerHTML="";
  d.messages.forEach(m=>{
    let div=document.createElement("div");
    div.className="msg "+(m.from===uid?"me":"them");
    div.innerHTML="<div>"+m.text+"</div><div class='small text-muted mt-1'>"+m.sender_name+" · "+new Date(m.created_at).toLocaleString()+"</div>";
    box.appendChild(div);
  });
  box.scrollTop=box.scrollHeight;
}
async function sendMsg(){
  let txt=document.getElementById("msgInput").value.trim();
  if(!txt||!active) return;
  let fd=new FormData(); fd.append("to_user_id",active); fd.append("message",txt);
  await fetch("messages.php?action=send",{method:"POST",body:fd});
  document.getElementById("msgInput").value="";
  fetchMessages();
}
document.getElementById("sendBtn").onclick=sendMsg;
document.getElementById("toggleContacts").onclick=()=>document.getElementById("contactsPane").classList.toggle("open");
setInterval(fetchMessages,3000);
loadContacts();
</script>
</body>
</html>
