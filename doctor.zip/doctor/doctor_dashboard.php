<?php
session_start();
$DB_HOST='127.0.0.1'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='care_db';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='doctor'){ header('Location: ../index.php'); exit; }
$conn = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
if($conn->connect_error) die('DB Error: '.$conn->connect_error);

$uid = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT d.id, d.specialization, d.phone, d.address, d.bio, u.name 
    FROM doctors d 
    JOIN users u ON d.user_id = u.id 
    WHERE d.user_id=? LIMIT 1
");
$stmt->bind_param('i',$uid);
$stmt->execute();
$dres = $stmt->get_result();
$doctor = $dres->fetch_assoc();
$stmt->close();


// stats
$doc_id = $doctor['id'] ?? 0;
$totalAppointments = 0; $upcoming = null; $patientsSeen = 0;
if($doc_id){
    $r = $conn->query("SELECT COUNT(*) as c FROM appointments WHERE doctor_id={$doc_id}");
    $totalAppointments = (int)($r->fetch_assoc()['c'] ?? 0);
    $r2 = $conn->query("SELECT * FROM appointments WHERE doctor_id={$doc_id} AND appointment_date>=NOW() ORDER BY appointment_date ASC LIMIT 1");
    $upcoming = $r2->fetch_assoc();
    $r3 = $conn->query("SELECT COUNT(DISTINCT patient_id) as c FROM appointments WHERE doctor_id={$doc_id} AND status='completed'");
    $patientsSeen = (int)($r3->fetch_assoc()['c'] ?? 0);
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctor Dashboard</title>
<link rel="stylesheet" href="assets/style2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="doctor_dashboard.php">CARE - Doctor</a>
    <div class="ms-auto">
      <a href="profile.php" class="btn btn-outline-primary me-2">Profile</a>
      <a href="availability.php" class="btn btn-primary me-2">Availability</a>
      <a href="appointments.php" class="btn btn-secondary me-2">Appointments</a>
      <a href="records.php" class="btn btn-ghost" style="border-color:#10b981">Records</a>
      <a href="logout.php" class="btn btn-danger ms-2">Logout</a>
    </div>
  </div>
</nav>

<div class="container py-4">
<h2>Welcome, Dr. <?php echo htmlspecialchars($doctor['name'] ?? ''); ?></h2>
<p class="text-muted"><?php echo htmlspecialchars($doctor['specialization'] ?? ''); ?></p>

  <div class="row g-4 my-4">
    <div class="col-md-4"><div class="feature-card p-3 text-center"><h3><?php echo $totalAppointments; ?></h3><div class="text-muted">Total Appointments</div></div></div>
    <div class="col-md-4"><div class="feature-card p-3 text-center"><h5><?php echo $upcoming ? date('M d, Y H:i', strtotime($upcoming['appointment_date'])) : 'No upcoming'; ?></h5><div class="text-muted">Next Appointment</div></div></div>
    <div class="col-md-4"><div class="feature-card p-3 text-center"><h3><?php echo $patientsSeen; ?></h3><div class="text-muted">Patients Seen</div></div></div>
  </div>

  <div class="row g-4">
    <div class="col-md-4"><div class="feature-card p-3"><h5>Manage Availability</h5><p>Set or edit your weekly availability.</p><a href="availability.php" class="btn btn-primary w-100">Manage</a></div></div>
    <div class="col-md-4"><div class="feature-card p-3"><h5>View Appointments</h5><p>Accept, cancel or complete appointments.</p><a href="appointments.php" class="btn btn-primary w-100">Open</a></div></div>
    <div class="col-md-4"><div class="feature-card p-3"><h5>Patient Records</h5><p>Add diagnoses & prescriptions.</p><a href="records.php" class="btn btn-primary w-100">Open</a></div></div>
  </div>
  <div class="col-md-4">
  <div class="feature-card p-3">
    <h5>Messages</h5>
    <p>Chat with your patients in real-time.</p>
    <a href="messages.php" class="btn btn-primary w-100">
      Open Chat
      <?php
        $msgCount = $conn->query("SELECT COUNT(*) AS c FROM messages WHERE receiver_id=$uid AND status='unread'")
                         ->fetch_assoc()['c'] ?? 0;
        if ($msgCount > 0) {
          echo "<span class='badge bg-danger ms-2'>$msgCount</span>";
        }
      ?>
    </a>
  </div>
</div>

</div>

<footer class="text-center py-3">&copy; <?php echo date('Y'); ?> CARE</footer>
</body>
</html>
