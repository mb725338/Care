<?php
session_start();
require "../db.php";

// Check doctor login
if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? "") !== "doctor") {
    header("Location: ../login.php");
    exit();
}

$doctor_user_id = $_SESSION["user_id"];

// Get doctor_id from doctors table (linked by user_id)
$stmt = $conn->prepare("SELECT id FROM doctors WHERE user_id = ?");
$stmt->bind_param("i", $doctor_user_id);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc();
$doctor_id = $doctor["id"] ?? 0;

// Fetch doctor’s appointments with patient details
$query = "
    SELECT a.id, a.appointment_date, a.status, a.notes,
           p.id AS patient_id, u.name AS patient_name, p.phone AS patient_phone
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u ON p.user_id = u.id
    WHERE a.doctor_id = ?
    ORDER BY a.appointment_date ASC
";

$stmt2 = $conn->prepare($query);
$stmt2->bind_param("i", $doctor_id);
$stmt2->execute();
$appointments = $stmt2->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Doctor - My Appointments</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f4f6f9;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .navbar {
      background: #0066cc;
    }
    .navbar-brand, .nav-link, .navbar-text {
      color: white !important;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .card h5 {
      color: #0066cc;
    }
    table {
      background: white;
      border-radius: 10px;
      overflow: hidden;
    }
    th {
      background: #0066cc;
      color: white;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg px-3">
    <a class="navbar-brand fw-bold" href="dashboard.php">Care - Doctor Panel</a>
    <div class="ms-auto">
      <span class="navbar-text me-3">Welcome, Dr.</span>
      <a href="../logout.php" class="btn btn-sm btn-light">Logout</a>
    </div>
  </nav>

  <div class="container py-4">
    <div class="card p-4">
      <h5 class="mb-3">My Appointments</h5>

      <?php if ($appointments->num_rows > 0): ?>
        <table class="table table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Patient Name</th>
              <th>Phone</th>
              <th>Date</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($row = $appointments->fetch_assoc()): ?>
              <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['patient_name']) ?></td>
                <td><?= htmlspecialchars($row['patient_phone']) ?></td>
                <td><?= date("d M Y, h:i A", strtotime($row['appointment_date'])) ?></td>
                <td>
                  <span class="badge bg-<?= $row['status']=='confirmed' ? 'success' : ($row['status']=='completed' ? 'primary' : ($row['status']=='cancelled' ? 'danger' : 'warning')) ?>">
                    <?= ucfirst($row['status']) ?>
                  </span>
                </td>
                <td><?= htmlspecialchars($row['notes'] ?? '-') ?></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p class="text-muted">No appointments found.</p>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
