<?php
session_start();
require "../db.php";  // Go up one folder to access db.php

if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? "") !== "doctor") {
    header("Location: ../login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

// Map doctor user → doctor.id
$stmt = $conn->prepare("SELECT id FROM doctors WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$doctor_row = $res->fetch_assoc();
$stmt->close();

if (!$doctor_row) {
    $_SESSION['flash'] = "Please complete your doctor profile.";
    header("Location: profile.php");
    exit();
}
$doctor_id = (int)$doctor_row['id'];

// Fetch unique patients who booked appointments with this doctor
$stmt = $conn->prepare(
    "SELECT DISTINCT u.id AS user_id, u.name, u.email, u.created_at
     FROM appointments a
     JOIN patients p ON a.patient_id = p.id
     JOIN users u ON p.user_id = u.id
     WHERE a.doctor_id = ?
     ORDER BY u.name ASC"
);
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$patients = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Patients | CARE Doctor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
body { background: linear-gradient(to right,#f5f6fa,#e4e9f7); font-family:'Segoe UI',sans-serif; }
.navbar { background:#00c6ff; }
.navbar-brand,.nav-link { color:#fff !important; }
.table-card { margin:40px auto; border-radius:15px; box-shadow:0 10px 30px rgba(0,0,0,0.1); }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand fw-bold" href="doctor_dashboard.php">CARE | Doctor</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="doctor_dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="appointments.php">Appointments</a></li>
        <li class="nav-item"><a class="nav-link active" href="patients.php">Patients</a></li>
        <li class="nav-item"><a class="nav-link" href="messages.php">Messages</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card table-card p-4">
    <h4 class="mb-3 text-primary"><i class="bi bi-people me-2"></i>My Patients</h4>

    <?php if (!empty($patients)): ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-primary">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>First Visit</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($patients as $p): ?>
              <tr>
                <td><?= htmlspecialchars($p['name']); ?></td>
                <td><?= htmlspecialchars($p['email']); ?></td>
                <td><?= date("M j, Y", strtotime($p['created_at'])); ?></td>
                <td class="text-end">
                  <a href="records.php?patient_id=<?= $p['user_id']; ?>" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-file-medical me-1"></i>Records
                  </a>
                  <a href="messages.php?patient_id=<?= $p['user_id']; ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-chat-dots me-1"></i>Message
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="text-muted">No patients found.</div>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
