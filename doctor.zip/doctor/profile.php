<?php
session_start();
$DB_HOST='127.0.0.1'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='care_db';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='doctor'){ header('Location: ../index.php'); exit; }
$conn = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
if($conn->connect_error) die('DB Error: '.$conn->connect_error);
$uid = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("SELECT u.name, u.email, d.id as doctor_id, d.specialization, d.license_no, d.phone, d.address, d.bio FROM users u JOIN doctors d ON u.id=d.user_id WHERE u.id=?");
$stmt->bind_param('i',$uid); $stmt->execute(); $res=$stmt->get_result(); $doc = $res->fetch_assoc(); $stmt->close();

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save'])){
    $name=$_POST['name']; $email=$_POST['email']; $spec=$_POST['specialization']; $phone=$_POST['phone']; $address=$_POST['address']; $bio=$_POST['bio'];
    $stmt=$conn->prepare("UPDATE users u JOIN doctors d ON u.id=d.user_id SET u.name=?, u.email=?, d.specialization=?, d.phone=?, d.address=?, d.bio=? WHERE u.id=?");
    $stmt->bind_param('ssssssi',$name,$email,$spec,$phone,$address,$bio,$uid);
    if($stmt->execute()) $msg='Profile updated.'; else $msg='Update failed: '.$stmt->error;
    $stmt->close();
    header('Location: profile.php'); exit;
}
?>
<!doctype html><html><head>
<meta charset="utf-8"><title>Doctor Profile</title>
<link rel="stylesheet" href="assets/style2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-light bg-white shadow-sm"><div class="container">
  <a class="navbar-brand" href="doctor_dashboard.php">CARE - Doctor</a>
  <div><a href="doctor_dashboard.php" class="btn btn-outline-secondary">Dashboard</a></div>
</div></nav>

<div class="container py-4">
  <h3>Your Profile</h3>
  <?php if($msg): ?><div class="alert alert-info"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  <form method="POST" class="row g-3">
    <div class="col-md-6"><label>Name</label><input name="name" value="<?php echo htmlspecialchars($doc['name']); ?>" class="form-control" required></div>
    <div class="col-md-6"><label>Email</label><input name="email" value="<?php echo htmlspecialchars($doc['email']); ?>" class="form-control" required></div>
    <div class="col-md-4"><label>Specialization</label><input name="specialization" value="<?php echo htmlspecialchars($doc['specialization']); ?>" class="form-control"></div>
    <div class="col-md-4"><label>Phone</label><input name="phone" value="<?php echo htmlspecialchars($doc['phone']); ?>" class="form-control"></div>
    <div class="col-md-4"><label>License No</label><input name="license_no" value="<?php echo htmlspecialchars($doc['license_no']); ?>" class="form-control"></div>
    <div class="col-12"><label>Address</label><textarea name="address" class="form-control"><?php echo htmlspecialchars($doc['address']); ?></textarea></div>
    <div class="col-12"><label>Bio</label><textarea name="bio" class="form-control"><?php echo htmlspecialchars($doc['bio']); ?></textarea></div>
    <div class="col-12"><button name="save" class="btn btn-primary">Save Changes</button></div>
  </form>
</div>
</body></html>
