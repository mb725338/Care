<?php
session_start();
$DB_HOST='127.0.0.1'; $DB_USER='root'; $DB_PASS=''; $DB_NAME='care_db';
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '')!=='doctor'){ header('Location: ../index.php'); exit; }
$conn = new mysqli($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
if($conn->connect_error) die('DB Error: '.$conn->connect_error);
$uid = (int)$_SESSION['user_id'];

$stmt=$conn->prepare("SELECT id FROM doctors WHERE user_id=? LIMIT 1"); $stmt->bind_param('i',$uid); $stmt->execute(); $r=$stmt->get_result(); $docrow=$r->fetch_assoc(); $stmt->close();
$doc_id = $docrow['id'] ?? 0;

if(isset($_GET['action']) && isset($_GET['aid'])){
    $aid = (int)$_GET['aid']; $action = $_GET['action'];
    if(in_array($action, ['confirmed','completed','cancelled','pending'])){
        $stmt=$conn->prepare("UPDATE appointments SET status=? WHERE id=? AND doctor_id=?");
        $stmt->bind_param('sii',$action,$aid,$doc_id); $stmt->execute(); $stmt->close();
    }
    header('Location: appointments.php'); exit;
}

$sql = "SELECT a.*, p.user_id as patient_user_id, u.name as patient_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE a.doctor_id = {$doc_id} ORDER BY a.appointment_date DESC";
$res = $conn->query($sql);
?>
<!doctype html><html><head>
<meta charset="utf-8"><title>Appointments</title>
<link rel="stylesheet" href="assets/style2.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-light bg-white shadow-sm"><div class="container">
  <a class="navbar-brand" href="doctor_dashboard.php">CARE - Doctor</a>
  <div><a href="doctor_dashboard.php" class="btn btn-outline-secondary">Dashboard</a></div>
</div></nav>

<div class="container py-4">
  <h3>Appointments</h3>
  <table class="table">
    <thead><tr><th>#</th><th>Patient</th><th>Date & Time</th><th>Status</th><th>Notes</th><th>Action</th></tr></thead>
    <tbody>
    <?php $i=1; while($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo htmlspecialchars($row['patient_name']); ?></td>
        <td><?php echo date('M d, Y H:i', strtotime($row['appointment_date'])); ?></td>
        <td><?php echo htmlspecialchars($row['status']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($row['notes'])); ?></td>
        <td>
          <div class="btn-group">
            <?php if($row['status'] !== 'confirmed'): ?><a class="btn btn-sm btn-success" href="appointments.php?action=confirmed&aid=<?php echo $row['id']; ?>">Confirm</a><?php endif; ?>
            <?php if($row['status'] !== 'completed'): ?><a class="btn btn-sm btn-primary" href="appointments.php?action=completed&aid=<?php echo $row['id']; ?>">Mark Done</a><?php endif; ?>
            <?php if($row['status'] !== 'cancelled'): ?><a class="btn btn-sm btn-danger" href="appointments.php?action=cancelled&aid=<?php echo $row['id']; ?>" onclick="return confirm('Cancel appointment?')">Cancel</a><?php endif; ?>
            <a class="btn btn-sm btn-outline-secondary" href="appointments.php?view=<?php echo $row['id']; ?>">View</a>
          </div>
        </td>
      </tr>
      <?php if(isset($_GET['view']) && (int)$_GET['view'] === (int)$row['id']): ?>
        <tr><td colspan="6">
          <strong>Patient Details</strong><br>
          <?php
            $pid = (int)$row['patient_id'];
            $pr = $conn->query("SELECT p.*, u.name, u.email FROM patients p JOIN users u ON p.user_id=u.id WHERE p.id={$pid}")->fetch_assoc();
            echo "Name: ".htmlspecialchars($pr['name'])."<br>";
            echo "Email: ".htmlspecialchars($pr['email'])."<br>";
            echo "Phone: ".htmlspecialchars($pr['phone'])."<br>";
            echo "Address: ".nl2br(htmlspecialchars($pr['address']))."<br>";
          ?>
        </td></tr>
      <?php endif; ?>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body></html>
